#pragma once

// Fortnite (1.11) SDK

// Generated with <3 by Jacobb626

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum FortniteGame.EFortAIDirectorEvent
enum class EFortAIDirectorEvent : uint8_t
{
	PlayerAIEnemies                = 0,
	PlayerTakeDamage               = 1,
	PlayerHealth                   = 2,
	PlayerDeath                    = 3,
	PlayerLookAtAIEnemy            = 4,
	PlayerDamageAIEnemy            = 5,
	PlayerKillAIEnemy              = 6,
	PlayerHealingPotential         = 7,
	PlayerAmmoLight                = 8,
	PlayerAmmoMedium               = 9,
	PlayerAmmoHeavy                = 10,
	PlayerAmmoShells               = 11,
	PlayerAmmoEnergy               = 12,
	PlayerAINear                   = 13,
	PlayerMovement                 = 14,
	ObjectiveTakeDamage            = 15,
	ObjectiveHealth                = 16,
	ObjectiveDestroyed             = 17,
	TrapFired                      = 18,
	TrapDamagedAIEnemy             = 19,
	ObjectivePathCost              = 20,
	PlayerPathCost                 = 21,
	ObjectiveNearbyBuildingDamaged = 22,
	Max_None                       = 23,
	EFortAIDirectorEvent_MAX       = 24
};


// Enum FortniteGame.EKeepDefenseState
enum class EKeepDefenseState : uint8_t
{
	Inactive                       = 0,
	Warmup                         = 1,
	Defense                        = 2,
	LastAlive                      = 3,
	Max                            = 4
};


// Enum FortniteGame.EFortDayPhase
enum class EFortDayPhase : uint8_t
{
	Morning                        = 0,
	Day                            = 1,
	Evening                        = 2,
	Night                          = 3,
	NumPhases                      = 4,
	EFortDayPhase_MAX              = 5
};


// Enum FortniteGame.EFortInventoryType
enum class EFortInventoryType : uint8_t
{
	World                          = 0,
	Account                        = 1,
	Outpost                        = 2,
	MAX                            = 3
};


// Enum FortniteGame.EOfferPurchaseError
enum class EOfferPurchaseError : uint8_t
{
	NoError                        = 0,
	PendingServerConfirmation      = 1,
	CannotAffordItem               = 2,
	InvalidOfferID                 = 3,
	InvalidPriceIndex              = 4,
	NoneLeft                       = 5,
	PurchaseAlreadyPending         = 6,
	NoConnection                   = 7,
	EOfferPurchaseError_MAX        = 8
};


// Enum FortniteGame.EFortAlteration
enum class EFortAlteration : uint8_t
{
	AttributeSlot                  = 0,
	GameplaySlot                   = 1,
	ComplexCosmeticSlot            = 2,
	ColorSlot                      = 3,
	HeroSpecializationTier1Slot    = 4,
	HeroSpecializationTier2Slot    = 5,
	HeroSpecializationTier3Slot    = 6,
	HeroSpecializationTier4Slot    = 7,
	HeroSpecializationTier5Slot    = 8,
	EFortAlteration_MAX            = 9
};


// Enum FortniteGame.EFortItemType
enum class EFortItemType : uint8_t
{
	WorldItem                      = 0,
	Ammo                           = 1,
	Badge                          = 2,
	BackpackPickup                 = 3,
	BuildingPiece                  = 4,
	CharacterPart                  = 5,
	Consumable                     = 6,
	Deco                           = 7,
	EditTool                       = 8,
	Ingredient                     = 9,
	Food                           = 10,
	Gadget                         = 11,
	HomebaseGadget                 = 12,
	HeroAbility                    = 13,
	MissionItem                    = 14,
	Trap                           = 15,
	Weapon                         = 16,
	WeaponMelee                    = 17,
	WeaponRanged                   = 18,
	WeaponHarvest                  = 19,
	WorldResource                  = 20,
	AccountItem                    = 21,
	AccountResource                = 22,
	CollectedResource              = 23,
	Alteration                     = 24,
	CardPack                       = 25,
	CharacterCosmetic              = 26,
	Currency                       = 27,
	Hero                           = 28,
	Schematic                      = 29,
	Worker                         = 30,
	Token                          = 31,
	DailyRewardScheduleToken       = 32,
	CodeToken                      = 33,
	Buff                           = 34,
	BuffCredit                     = 35,
	Quest                          = 36,
	Compendium                     = 37,
	CompendiumBundle               = 38,
	GameplayModifier               = 39,
	Outpost                        = 40,
	HomebaseNode                   = 41,
	Defender                       = 42,
	ConversionControl              = 43,
	DeployableBaseCloudSave        = 44,
	ConsumableAccountItem          = 45,
	Quota                          = 46,
	Expedition                     = 47,
	HomebaseBannerIcon             = 48,
	HomebaseBannerColor            = 49,
	AthenaGlider                   = 50,
	AthenaPickaxe                  = 51,
	AthenaHat                      = 52,
	AthenaBackpack                 = 53,
	AthenaCharacter                = 54,
	AthenaDance                    = 55,
	AthenaConsumableEmote          = 56,
	AthenaLoadingScreen            = 57,
	AthenaBattleBus                = 58,
	AthenaVictoryPose              = 59,
	AthenaSeasonTreasure           = 60,
	AthenaSeason                   = 61,
	EventDescription               = 62,
	AthenaMedal                    = 63,
	AthenaEventToken               = 64,
	EventPurchaseTracker           = 65,
	SpecialItem                    = 66,
	Emote                          = 67,
	Stack                          = 68,
	CollectionBookPage             = 69,
	Profile                        = 70,
	Max_None                       = 71,
	EFortItemType_MAX              = 72
};


// Enum FortniteGame.EFortTeam
enum class EFortTeam : uint8_t
{
	HumanCampaign                  = 0,
	Monster                        = 1,
	HumanPvP_Team1                 = 2,
	HumanPvP_Team2                 = 3,
	HumanPvP_Team3                 = 4,
	HumanPvP_Team4                 = 5,
	HumanPvP_Team5                 = 6,
	HumanPvP_Team6                 = 7,
	HumanPvP_Team7                 = 8,
	HumanPvP_Team8                 = 9,
	HumanPvP_Team9                 = 10,
	HumanPvP_Team10                = 11,
	HumanPvP_Team11                = 12,
	HumanPvP_Team12                = 13,
	HumanPvP_Team13                = 14,
	HumanPvP_Team14                = 15,
	HumanPvP_Team15                = 16,
	HumanPvP_Team16                = 17,
	HumanPvP_Team17                = 18,
	HumanPvP_Team18                = 19,
	HumanPvP_Team19                = 20,
	HumanPvP_Team20                = 21,
	HumanPvP_Team21                = 22,
	HumanPvP_Team22                = 23,
	HumanPvP_Team23                = 24,
	HumanPvP_Team24                = 25,
	HumanPvP_Team25                = 26,
	HumanPvP_Team26                = 27,
	HumanPvP_Team27                = 28,
	HumanPvP_Team28                = 29,
	HumanPvP_Team29                = 30,
	HumanPvP_Team30                = 31,
	HumanPvP_Team31                = 32,
	HumanPvP_Team32                = 33,
	HumanPvP_Team33                = 34,
	HumanPvP_Team34                = 35,
	HumanPvP_Team35                = 36,
	HumanPvP_Team36                = 37,
	HumanPvP_Team37                = 38,
	HumanPvP_Team38                = 39,
	HumanPvP_Team39                = 40,
	HumanPvP_Team40                = 41,
	HumanPvP_Team41                = 42,
	HumanPvP_Team42                = 43,
	HumanPvP_Team43                = 44,
	HumanPvP_Team44                = 45,
	HumanPvP_Team45                = 46,
	HumanPvP_Team46                = 47,
	HumanPvP_Team47                = 48,
	HumanPvP_Team48                = 49,
	HumanPvP_Team49                = 50,
	HumanPvP_Team50                = 51,
	HumanPvP_Team51                = 52,
	HumanPvP_Team52                = 53,
	HumanPvP_Team53                = 54,
	HumanPvP_Team54                = 55,
	HumanPvP_Team55                = 56,
	HumanPvP_Team56                = 57,
	HumanPvP_Team57                = 58,
	HumanPvP_Team58                = 59,
	HumanPvP_Team59                = 60,
	HumanPvP_Team60                = 61,
	HumanPvP_Team61                = 62,
	HumanPvP_Team62                = 63,
	HumanPvP_Team63                = 64,
	HumanPvP_Team64                = 65,
	HumanPvP_Team65                = 66,
	HumanPvP_Team66                = 67,
	HumanPvP_Team67                = 68,
	HumanPvP_Team68                = 69,
	HumanPvP_Team69                = 70,
	HumanPvP_Team70                = 71,
	HumanPvP_Team71                = 72,
	HumanPvP_Team72                = 73,
	HumanPvP_Team73                = 74,
	HumanPvP_Team74                = 75,
	HumanPvP_Team75                = 76,
	HumanPvP_Team76                = 77,
	HumanPvP_Team77                = 78,
	HumanPvP_Team78                = 79,
	HumanPvP_Team79                = 80,
	HumanPvP_Team80                = 81,
	HumanPvP_Team81                = 82,
	HumanPvP_Team82                = 83,
	HumanPvP_Team83                = 84,
	HumanPvP_Team84                = 85,
	HumanPvP_Team85                = 86,
	HumanPvP_Team86                = 87,
	HumanPvP_Team87                = 88,
	HumanPvP_Team88                = 89,
	HumanPvP_Team89                = 90,
	HumanPvP_Team90                = 91,
	HumanPvP_Team91                = 92,
	HumanPvP_Team92                = 93,
	HumanPvP_Team93                = 94,
	HumanPvP_Team94                = 95,
	HumanPvP_Team95                = 96,
	HumanPvP_Team96                = 97,
	HumanPvP_Team97                = 98,
	HumanPvP_Team98                = 99,
	HumanPvP_Team99                = 100,
	HumanPvP_Team100               = 101,
	HumanPvP_Team101               = 102,
	Spectator                      = 103,
	MAX                            = 104
};


// Enum FortniteGame.EFortCustomPartType
enum class EFortCustomPartType : uint8_t
{
	Head                           = 0,
	Body                           = 1,
	Hat                            = 2,
	Backpack                       = 3,
	Charm                          = 4,
	Face                           = 5,
	NumTypes                       = 6,
	EFortCustomPartType_MAX        = 7
};


// Enum FortniteGame.EFortReportDayPhase
enum class EFortReportDayPhase : uint8_t
{
	Dawn                           = 0,
	Dusk                           = 1,
	ZoneFinished                   = 2,
	PlayerLogout                   = 3,
	EFortReportDayPhase_MAX        = 4
};


// Enum FortniteGame.ERewardSource
enum class ERewardSource : uint8_t
{
	Invalid                        = 0,
	MinutesPlayed                  = 1,
	FirstKill                      = 2,
	TeamKills                      = 3,
	Placement                      = 4,
	Medals                         = 5,
	FirstWin                       = 6,
	SeasonLevelUp                  = 7,
	BookLevelUp                    = 8,
	MAX_COUNT                      = 9,
	ERewardSource_MAX              = 10
};


// Enum FortniteGame.EAthenaMatchXpMultiplierSource
enum class EAthenaMatchXpMultiplierSource : uint8_t
{
	Invalid                        = 0,
	BattlePassSelf                 = 1,
	BattlePassFriends              = 2,
	CosmeticSet                    = 3,
	MAX_COUNT                      = 4,
	EAthenaMatchXpMultiplierSource_MAX = 5
};


// Enum FortniteGame.EAthenaGamePhase
enum class EAthenaGamePhase : uint8_t
{
	None                           = 0,
	Setup                          = 1,
	Warmup                         = 2,
	Aircraft                       = 3,
	SafeZones                      = 4,
	EndGame                        = 5,
	EAthenaGamePhase_MAX           = 6
};


// Enum FortniteGame.EAthenaGamePhaseStep
enum class EAthenaGamePhaseStep : uint8_t
{
	None                           = 0,
	Setup                          = 1,
	Warmup                         = 2,
	GetReady                       = 3,
	BusLocked                      = 4,
	BusFlying                      = 5,
	StormForming                   = 6,
	StormHolding                   = 7,
	StormShrinking                 = 8,
	EndGame                        = 9,
	EAthenaGamePhaseStep_MAX       = 10
};


// Enum FortniteGame.ECaptureState
enum class ECaptureState : uint8_t
{
	CS_Idle                        = 0,
	CS_Capturing                   = 1,
	CS_Contested                   = 2,
	CS_Resetting                   = 3,
	CS_Captured                    = 4,
	CS_Reset                       = 5,
	CS_MAX                         = 6
};


// Enum FortniteGame.EFOBIOStatus
enum class EFOBIOStatus : uint8_t
{
	Saving                         = 0,
	Loading                        = 1,
	Free                           = 2,
	EFOBIOStatus_MAX               = 3
};


// Enum FortniteGame.ECollectionBookRewardType
enum class ECollectionBookRewardType : uint8_t
{
	Uninitialized                  = 0,
	Book                           = 1,
	Page                           = 2,
	Section                        = 3,
	ECollectionBookRewardType_MAX  = 4
};


// Enum FortniteGame.EFortObjectiveStatus
enum class EFortObjectiveStatus : uint8_t
{
	Created                        = 0,
	InProgress                     = 1,
	Succeeded                      = 2,
	Failed                         = 3,
	NeutralCompletion              = 4,
	Max_None                       = 5,
	EFortObjectiveStatus_MAX       = 6
};


// Enum FortniteGame.EFortMissionVisibilityOverride
enum class EFortMissionVisibilityOverride : uint8_t
{
	Visible                        = 0,
	Invisible                      = 1,
	Max_None                       = 2,
	EFortMissionVisibilityOverride_MAX = 3
};


// Enum FortniteGame.EFortPrototypingStatus
enum class EFortPrototypingStatus : uint8_t
{
	Unknown                        = 0,
	Disabled                       = 1,
	Enabled                        = 2,
	EFortPrototypingStatus_MAX     = 3
};


// Enum FortniteGame.EMatchmakingCompleteResult
enum class EMatchmakingCompleteResult : uint8_t
{
	NotStarted                     = 0,
	UpdateNeeded                   = 1,
	OutpostNotFound                = 2,
	Cancelled                      = 3,
	NoResults                      = 4,
	Failure                        = 5,
	CreateFailure                  = 6,
	Success                        = 7,
	EMatchmakingCompleteResult_MAX = 8
};


// Enum FortniteGame.EMatchmakingState
enum class EMatchmakingState : uint8_t
{
	NotMatchmaking                 = 0,
	CancelingMatchmaking           = 1,
	ReleasingLock                  = 2,
	AcquiringLock                  = 3,
	LockAcquistionFailure          = 4,
	FindingEmptyServer             = 5,
	FindingExistingSession         = 6,
	TestingEmptyServers            = 7,
	TestingExistingSessions        = 8,
	JoiningExistingSession         = 9,
	NoMatchesAvailable             = 10,
	CleaningUpExisting             = 11,
	HandlingFailure                = 12,
	JoinSuccess                    = 13,
	EMatchmakingState_MAX          = 14
};


// Enum FortniteGame.EFortPartyRestriction
enum class EFortPartyRestriction : uint8_t
{
	Invalid                        = 0,
	PartyCreatePending             = 1,
	AlreadyInParty                 = 2,
	PartyFull                      = 3,
	GameFull                       = 4,
	Private                        = 5,
	CurrentlyNotAvailable          = 6,
	NotPlayingThisGame             = 7,
	GameModeRestricted             = 8,
	Max                            = 9
};


// Enum FortniteGame.EFortFriendRequestStatus
enum class EFortFriendRequestStatus : uint8_t
{
	None                           = 0,
	Accepted                       = 1,
	PendingReceived                = 2,
	PendingSent                    = 3,
	EFortFriendRequestStatus_MAX   = 4
};


// Enum FortniteGame.EFortPartyMemberLocation
enum class EFortPartyMemberLocation : uint8_t
{
	PreLobby                       = 0,
	ConnectingToLobby              = 1,
	Lobby                          = 2,
	JoiningGame                    = 3,
	ProcessingRejoin               = 4,
	InGame                         = 5,
	ReturningToFrontEnd            = 6,
	EFortPartyMemberLocation_MAX   = 7
};


// Enum FortniteGame.EFortAthenaPlaylist
enum class EFortAthenaPlaylist : uint8_t
{
	AthenaSolo                     = 0,
	AthenaDuo                      = 1,
	AthenaSquad                    = 2,
	AthenaFiftyFifty               = 3,
	AthenaEvent1                   = 4,
	AthenaEvent2                   = 5,
	AthenaEvent3                   = 6,
	AthenaEvent4                   = 7,
	AthenaEvent5                   = 8,
	AthenaEvent6                   = 9,
	AthenaEvent7                   = 10,
	AthenaEvent8                   = 11,
	EFortAthenaPlaylist_MAX        = 12
};


// Enum FortniteGame.EFortPartyState
enum class EFortPartyState : uint8_t
{
	Undetermined                   = 0,
	WorldView                      = 1,
	TheaterView                    = 2,
	Matchmaking                    = 3,
	PostMatchmaking                = 4,
	ReturningToFrontEnd            = 5,
	BattleRoyaleView               = 6,
	BattleRoyalePreloading         = 7,
	BattleRoyaleMatchmaking        = 8,
	BattleRoyalePostMatchmaking    = 9,
	EFortPartyState_MAX            = 10
};


// Enum FortniteGame.EFortPartyMemberDisplayState
enum class EFortPartyMemberDisplayState : uint8_t
{
	Open                           = 0,
	Connecting                     = 1,
	Connected                      = 2,
	Max                            = 3
};


// Enum FortniteGame.EFortPartyTransition
enum class EFortPartyTransition : uint8_t
{
	Idle                           = 0,
	Joining                        = 1,
	Leaving                        = 2,
	Max                            = 3
};


// Enum FortniteGame.EFortSocialItemHeaderType
enum class EFortSocialItemHeaderType : uint8_t
{
	PartyInvites                   = 0,
	Friends                        = 1,
	None                           = 2,
	EFortSocialItemHeaderType_MAX  = 3
};


// Enum FortniteGame.EFortDialogFeedbackType
enum class EFortDialogFeedbackType : uint8_t
{
	FriendRequestSent              = 0,
	FriendRequestReceived          = 1,
	FriendRequestAccepted          = 2,
	Default                        = 3,
	EFortDialogFeedbackType_MAX    = 4
};


// Enum FortniteGame.EFortEncounterDirection
enum class EFortEncounterDirection : uint8_t
{
	North                          = 0,
	NorthEast                      = 1,
	East                           = 2,
	SouthEast                      = 3,
	South                          = 4,
	SouthWest                      = 5,
	West                           = 6,
	NorthWest                      = 7,
	Max_None                       = 8,
	EFortEncounterDirection_MAX    = 9
};


// Enum FortniteGame.EAIHotSpotAssignmentFilter
enum class EAIHotSpotAssignmentFilter : uint8_t
{
	All                            = 0,
	WithSlots                      = 1,
	WaitingList                    = 2,
	EAIHotSpotAssignmentFilter_MAX = 3
};


// Enum FortniteGame.EAIHotSpotSlotFilter
enum class EAIHotSpotSlotFilter : uint8_t
{
	All                            = 0,
	AvailableOnly                  = 1,
	UnavailableOnly                = 2,
	EAIHotSpotSlotFilter_MAX       = 3
};


// Enum FortniteGame.EAIHotSpotSlot
enum class EAIHotSpotSlot : uint8_t
{
	Free                           = 0,
	Claimed                        = 1,
	Occupied                       = 2,
	Blocked                        = 3,
	Disabled                       = 4,
	EAIHotSpotSlot_MAX             = 5
};


// Enum FortniteGame.EBoundingBoxSlotDirectionCalculation
enum class EBoundingBoxSlotDirectionCalculation : uint8_t
{
	Auto                           = 0,
	FaceWall                       = 1,
	FaceAwayFromWall               = 2,
	FaceCenter                     = 3,
	EBoundingBoxSlotDirectionCalculation_MAX = 4
};


// Enum FortniteGame.EAthenaPlaylistFillType
enum class EAthenaPlaylistFillType : uint8_t
{
	NoFill                         = 0,
	OptionalFill_DefaultOff        = 1,
	OptionalFill_DefaultOn         = 2,
	MandatoryFill                  = 3,
	EAthenaPlaylistFillType_MAX    = 4
};


// Enum FortniteGame.EEventTokenType
enum class EEventTokenType : uint8_t
{
	Invite                         = 0,
	Creation                       = 1,
	EEventTokenType_MAX            = 2
};


// Enum FortniteGame.EAthenaSeasonRewardTrack
enum class EAthenaSeasonRewardTrack : uint8_t
{
	Invalid                        = 0,
	SeasonProgressionTrack         = 1,
	CompendiumFreeTrack            = 2,
	CompendiumPaidTrack            = 3,
	EAthenaSeasonRewardTrack_MAX   = 4
};


// Enum FortniteGame.EAthenaSeasonShopVisibility
enum class EAthenaSeasonShopVisibility : uint8_t
{
	Hide                           = 0,
	ShowIfOffersAvailable          = 1,
	ShowAlways                     = 2,
	EAthenaSeasonShopVisibility_MAX = 3
};


// Enum FortniteGame.EAbilitySystemComponentCreationPolicy
enum class EAbilitySystemComponentCreationPolicy : uint8_t
{
	Never                          = 0,
	Lazy                           = 1,
	Always                         = 2,
	EAbilitySystemComponentCreationPolicy_MAX = 3
};


// Enum FortniteGame.EAttributeInitLevelSource
enum class EAttributeInitLevelSource : uint8_t
{
	WorldDifficulty                = 0,
	PlayerBuildingSkill            = 1,
	EAttributeInitLevelSource_MAX  = 2
};


// Enum FortniteGame.EDynamicBuildingPlacementType
enum class EDynamicBuildingPlacementType : uint8_t
{
	CountsTowardsBounds            = 0,
	DestroyIfColliding             = 1,
	DestroyAnythingThatCollides    = 2,
	EDynamicBuildingPlacementType_MAX = 3
};


// Enum FortniteGame.EUnlockRules
enum class EUnlockRules : uint8_t
{
	UR_Reset                       = 0,
	UR_MaintainState               = 1,
	UR_ResetDeactivate             = 2,
	UR_MAX                         = 3
};


// Enum FortniteGame.EContentionRules
enum class EContentionRules : uint8_t
{
	CR_MajorityWins                = 0,
	CR_OneTeamOnlyWins             = 1,
	CR_MAX                         = 2
};


// Enum FortniteGame.EBinaryToggleValues
enum class EBinaryToggleValues : uint8_t
{
	BTV_Active                     = 0,
	BTV_Inactive                   = 1,
	BTV_Either                     = 2,
	BTV_MAX                        = 3
};


// Enum FortniteGame.EAuxIndicatorStates
enum class EAuxIndicatorStates : uint8_t
{
	AIS_GuidingArrow               = 0,
	AIS_ConfirmedArrow             = 1,
	AIS_Inactive                   = 2,
	AIS_Active                     = 3,
	AIS_MAX                        = 4
};


// Enum FortniteGame.EFOBFileHeaderStatus
enum class EFOBFileHeaderStatus : uint8_t
{
	NoExistingFile                 = 0,
	HasExistingFile                = 1,
	UnableToDetermine              = 2,
	EFOBFileHeaderStatus_MAX       = 3
};


// Enum FortniteGame.EFOBInitStatus
enum class EFOBInitStatus : uint8_t
{
	Successful                     = 0,
	Failure_CloudStorageDisabled   = 1,
	Failure_PreviouslyInitialized  = 2,
	Failure_DataOwner              = 3,
	Failure_CloudStorageError      = 4,
	Failure_MissingFileName        = 5,
	Failure_Generic                = 6,
	EFOBInitStatus_MAX             = 7
};


// Enum FortniteGame.EFOBMode
enum class EFOBMode : uint8_t
{
	Uninitialized                  = 0,
	Creation                       = 1,
	Deployment                     = 2,
	EFOBMode_MAX                   = 3
};


// Enum FortniteGame.EBuildingFoundationType
enum class EBuildingFoundationType : uint8_t
{
	BFT_3x3                        = 0,
	BFT_5x5                        = 1,
	BFT_5x10                       = 2,
	BFT_None                       = 3,
	BFT_MAX                        = 4
};


// Enum FortniteGame.EFortItemCollectorBehavior
enum class EFortItemCollectorBehavior : uint8_t
{
	FirstToGoal                    = 0,
	FreeForAll                     = 1,
	TugOfWar                       = 2,
	EFortItemCollectorBehavior_MAX = 3
};


// Enum FortniteGame.EFortItemCollectorState
enum class EFortItemCollectorState : uint8_t
{
	CanInteract                    = 0,
	Active                         = 1,
	Inactive                       = 2,
	Captured                       = 3,
	Invalid                        = 4,
	EFortItemCollectorState_MAX    = 5
};


// Enum FortniteGame.ELayoutRequirementStatus
enum class ELayoutRequirementStatus : uint8_t
{
	Inactive_Invisible             = 0,
	Active_Invisible               = 1,
	Active_Visible                 = 2,
	ELayoutRequirementStatus_MAX   = 3
};


// Enum FortniteGame.EFortRiftSlotStatus
enum class EFortRiftSlotStatus : uint8_t
{
	Reserved                       = 0,
	Occupied                       = 1,
	Max_None                       = 2,
	EFortRiftSlotStatus_MAX        = 3
};


// Enum FortniteGame.EBuildingNavObstacleType
enum class EBuildingNavObstacleType : uint8_t
{
	UnwalkableAll                  = 0,
	UnwalkableHuskOnly             = 1,
	SmashWhenLowHeight             = 2,
	SmashOnlyLowHeight             = 3,
	SmashSmasherOnly               = 4,
	SmashAll                       = 5,
	EBuildingNavObstacleType_MAX   = 6
};


// Enum FortniteGame.EFortDamageVisualsState
enum class EFortDamageVisualsState : uint8_t
{
	UnDamaged                      = 0,
	DamagedAndAnimating            = 1,
	DamagedAndStatic               = 2,
	EFortDamageVisualsState_MAX    = 3
};


// Enum FortniteGame.EStructuralSupportCheck
enum class EStructuralSupportCheck : uint8_t
{
	Stable                         = 0,
	Unstable                       = 1,
	Max_None                       = 2,
	EStructuralSupportCheck_MAX    = 3
};


// Enum FortniteGame.EBuildingReplacementType
enum class EBuildingReplacementType : uint8_t
{
	BRT_None                       = 0,
	BRT_Edited                     = 1,
	BRT_Conversion                 = 2,
	BRT_MAX                        = 3
};


// Enum FortniteGame.EPlacementType
enum class EPlacementType : uint8_t
{
	Free                           = 0,
	Grid                           = 1,
	None                           = 2,
	EPlacementType_MAX             = 3
};


// Enum FortniteGame.EBuildingAttachmentSide
enum class EBuildingAttachmentSide : uint8_t
{
	Front                          = 0,
	Back                           = 1,
	Any                            = 2,
	EBuildingAttachmentSide_MAX    = 3
};


// Enum FortniteGame.EBuildingAttachmentSlot
enum class EBuildingAttachmentSlot : uint8_t
{
	SLOT_Floor                     = 0,
	SLOT_Wall                      = 1,
	SLOT_Ceiling                   = 2,
	SLOT_None                      = 3,
	SLOT_MAX                       = 4
};


// Enum FortniteGame.EBuildingAnim
enum class EBuildingAnim : uint8_t
{
	EBA_None                       = 0,
	EBA_Building                   = 1,
	EBA_Breaking                   = 2,
	EBA_Destruction                = 3,
	EBA_Placement                  = 4,
	EBA_DynamicLOD                 = 5,
	EBA_DynamicShrink              = 6,
	EBA_MAX                        = 7
};


// Enum FortniteGame.EFortDefenderInteractionError
enum class EFortDefenderInteractionError : uint8_t
{
	None                           = 0,
	Obstructed                     = 1,
	NoEditPermission               = 2,
	UsedByAnotherPlayer            = 3,
	EFortDefenderInteractionError_MAX = 4
};


// Enum FortniteGame.EFortBounceType
enum class EFortBounceType : uint8_t
{
	Hit                            = 0,
	Interact                       = 1,
	EditPlaced                     = 2,
	EFortBounceType_MAX            = 3
};


// Enum FortniteGame.EBuildingHighlightType
enum class EBuildingHighlightType : uint8_t
{
	Primary                        = 0,
	Interact                       = 1,
	WillBeDestroyed                = 2,
	MAX                            = 3
};


// Enum FortniteGame.EFortConnectivityCubeFace
enum class EFortConnectivityCubeFace : uint8_t
{
	Front                          = 0,
	Left                           = 1,
	Back                           = 2,
	Right                          = 3,
	Upper                          = 4,
	Lower                          = 5,
	MAX                            = 6
};


// Enum FortniteGame.EFortDecoPlacementQueryResults
enum class EFortDecoPlacementQueryResults : uint8_t
{
	CanAdd                         = 0,
	ExistingTrap                   = 1,
	ExistingObject                 = 2,
	Obstructed                     = 3,
	NoLocation                     = 4,
	WrongType                      = 5,
	WrongShape                     = 6,
	BeingModified                  = 7,
	WrongTeam                      = 8,
	BlueprintFailure               = 9,
	AbilityFailure                 = 10,
	RequiresPlayerBuildableActor   = 11,
	NoEditPermission               = 12,
	EFortDecoPlacementQueryResults_MAX = 13
};


// Enum FortniteGame.EFortStructuralGridQueryResults
enum class EFortStructuralGridQueryResults : uint8_t
{
	CanAdd                         = 0,
	ExistingActor                  = 1,
	Obstructed                     = 2,
	NoStructuralSupport            = 3,
	InvalidActor                   = 4,
	ReachedLimit                   = 5,
	NoEditPermission               = 6,
	PatternNotPermittedByLayoutRequirement = 7,
	ResourceTypeNotPermittedByLayoutRequirement = 8,
	BuildingAtRequirementsDisabled = 9,
	BuildingOtherThanRequirementsDisabled = 10,
	EFortStructuralGridQueryResults_MAX = 11
};


// Enum FortniteGame.EFortCostInfoTypes
enum class EFortCostInfoTypes : uint8_t
{
	Placement                      = 0,
	Repair                         = 1,
	Conversion                     = 2,
	Ability                        = 3,
	None                           = 4,
	EFortCostInfoTypes_MAX         = 5
};


// Enum FortniteGame.EFortBuildingInitializationReason
enum class EFortBuildingInitializationReason : uint8_t
{
	StaticallyPlaced               = 0,
	Spawned                        = 1,
	Replaced                       = 2,
	LoadedFromSave                 = 3,
	DynamicBuilderPlaced           = 4,
	PlacementTool                  = 5,
	TrapTool                       = 6,
	None                           = 7,
	EFortBuildingInitializationReason_MAX = 8
};


// Enum FortniteGame.EFortBuildingPersistentState
enum class EFortBuildingPersistentState : uint8_t
{
	Default                        = 0,
	New                            = 1,
	Constructed                    = 2,
	Destroyed                      = 3,
	Searched                       = 4,
	None                           = 5,
	EFortBuildingPersistentState_MAX = 6
};


// Enum FortniteGame.EFortBuildingState
enum class EFortBuildingState : uint8_t
{
	Placement                      = 0,
	EditMode                       = 1,
	None                           = 2,
	EFortBuildingState_MAX         = 3
};


// Enum FortniteGame.EFortResourceLevel
enum class EFortResourceLevel : uint8_t
{
	First                          = 0,
	Second                         = 1,
	Third                          = 2,
	Fourth                         = 3,
	Fifth                          = 4,
	Sixth                          = 5,
	NumLevels                      = 6,
	Invalid                        = 7,
	EFortResourceLevel_MAX         = 8
};


// Enum FortniteGame.EFortResourceType
enum class EFortResourceType : uint8_t
{
	Wood                           = 0,
	Stone                          = 1,
	Metal                          = 2,
	Permanite                      = 3,
	None                           = 4,
	EFortResourceType_MAX          = 5
};


// Enum FortniteGame.EFortTextureDataSlot
enum class EFortTextureDataSlot : uint8_t
{
	Primary                        = 0,
	Secondary                      = 1,
	Tertiary                       = 2,
	Fourth                         = 3,
	NumSlots                       = 4,
	EFortTextureDataSlot_MAX       = 5
};


// Enum FortniteGame.EFortTextureDataType
enum class EFortTextureDataType : uint8_t
{
	Any                            = 0,
	OuterWall                      = 1,
	InnerWall                      = 2,
	Corner                         = 3,
	Floor                          = 4,
	Ceiling                        = 5,
	Trim                           = 6,
	Roof                           = 7,
	Pillar                         = 8,
	Shingle                        = 9,
	None                           = 10,
	EFortTextureDataType_MAX       = 11
};


// Enum FortniteGame.EBuildingAttachmentType
enum class EBuildingAttachmentType : uint8_t
{
	ATTACH_Floor                   = 0,
	ATTACH_Wall                    = 1,
	ATTACH_Ceiling                 = 2,
	ATTACH_Corner                  = 3,
	ATTACH_All                     = 4,
	ATTACH_WallThenFloor           = 5,
	ATTACH_None                    = 6,
	ATTACH_MAX                     = 7
};


// Enum FortniteGame.EFortBuildingType
enum class EFortBuildingType : uint8_t
{
	Wall                           = 0,
	Floor                          = 1,
	Corner                         = 2,
	Deco                           = 3,
	Prop                           = 4,
	Stairs                         = 5,
	Roof                           = 6,
	Pillar                         = 7,
	SpawnedItem                    = 8,
	Container                      = 9,
	Trap                           = 10,
	GenericCenterCellActor         = 11,
	None                           = 12,
	EFortBuildingType_MAX          = 13
};


// Enum FortniteGame.EAccessoryColorName
enum class EAccessoryColorName : uint8_t
{
	EAccessoryColorName_AccessoryColor1 = 0,
	EAccessoryColorName_AccessoryColor2 = 1,
	EAccessoryColorName_AccessoryColor3 = 2,
	EAccessoryColorName_NumTypes   = 3,
	EAccessoryColorName_MAX        = 4
};


// Enum FortniteGame.ECustomHatType
enum class ECustomHatType : uint8_t
{
	ECustomHatType_None            = 0,
	ECustomHatType_Cap             = 1,
	ECustomHatType_Helmet          = 2,
	ECustomHatType_Mask            = 3,
	ECustomHatType_Hat             = 4,
	ECustomHatType_HeadReplacement = 5,
	ECustomHatType_MAX             = 6
};


// Enum FortniteGame.EClothingColorName
enum class EClothingColorName : uint8_t
{
	EClothingColorName_AccessoryColor1 = 0,
	EClothingColorName_AccessoryColor2 = 1,
	EClothingColorName_NumTypes    = 2,
	EClothingColorName_MAX         = 3
};


// Enum FortniteGame.EColorSwatchType
enum class EColorSwatchType : uint8_t
{
	EColorSwatchType_Skin          = 0,
	EColorSwatchType_Hair          = 1,
	EColorSwatchType_BodyAccessory = 2,
	EColorSwatchType_Accessory     = 3,
	EColorSwatchType_NumTypes      = 4,
	EColorSwatchType_MAX           = 5
};


// Enum FortniteGame.ECharacterColorSwatchType
enum class ECharacterColorSwatchType : uint8_t
{
	ECharacterColorSwatchType_Skin = 0,
	ECharacterColorSwatchType_Hair = 1,
	ECharacterColorSwatchType_NumTypes = 2,
	ECharacterColorSwatchType_MAX  = 3
};


// Enum FortniteGame.EDeployableBaseConstructionStatus
enum class EDeployableBaseConstructionStatus : uint8_t
{
	Constructing                   = 0,
	Destroying                     = 1,
	Finished                       = 2,
	EDeployableBaseConstructionStatus_MAX = 3
};


// Enum FortniteGame.EDeployableBaseBuildingState
enum class EDeployableBaseBuildingState : uint8_t
{
	Empty                          = 0,
	Built                          = 1,
	Unoccupied                     = 2,
	WaitingToBuild                 = 3,
	Building                       = 4,
	WaitingToDestroy               = 5,
	Destroying                     = 6,
	WaitingToReset                 = 7,
	Resetting                      = 8,
	EDeployableBaseBuildingState_MAX = 9
};


// Enum FortniteGame.EDeployableBaseBoxType
enum class EDeployableBaseBoxType : uint8_t
{
	BuildSpace                     = 0,
	SaveSpace                      = 1,
	PlotSpace                      = 2,
	NumSpaceTypes                  = 3,
	EDeployableBaseBoxType_MAX     = 4
};


// Enum FortniteGame.EFortStatDisplayType
enum class EFortStatDisplayType : uint8_t
{
	Category                       = 0,
	Buff                           = 1,
	Debuff                         = 2,
	Neutral                        = 3,
	DoNotDisplay                   = 4,
	EFortStatDisplayType_MAX       = 5
};


// Enum FortniteGame.EFortAbilityTargetSelectionUsage
enum class EFortAbilityTargetSelectionUsage : uint8_t
{
	BothTargetingAndCanHit         = 0,
	OnlyTargeting                  = 1,
	OnlyCanHit                     = 2,
	EFortAbilityTargetSelectionUsage_MAX = 3
};


// Enum FortniteGame.EFortDirectedMovementSpace
enum class EFortDirectedMovementSpace : uint8_t
{
	WorldSpace                     = 0,
	ActorLocRelative               = 1,
	ActorLocRotRelative            = 2,
	CameraRelative                 = 3,
	EFortDirectedMovementSpace_MAX = 4
};


// Enum FortniteGame.EFortProximityBasedGEApplicationType
enum class EFortProximityBasedGEApplicationType : uint8_t
{
	ApplyOnProximityPulse          = 0,
	ApplyOnProximityTouch          = 1,
	ApplyOnlyDuringProximityTouch  = 2,
	EFortProximityBasedGEApplicationType_MAX = 3
};


// Enum FortniteGame.EFortDeliveryInfoBuildingActorSpecification
enum class EFortDeliveryInfoBuildingActorSpecification : uint8_t
{
	All                            = 0,
	PlayerBuildable                = 1,
	NonPlayerBuildable             = 2,
	EFortDeliveryInfoBuildingActorSpecification_MAX = 3
};


// Enum FortniteGame.EFortEncounterUtilityDesire
enum class EFortEncounterUtilityDesire : uint8_t
{
	Low                            = 0,
	Medium                         = 1,
	High                           = 2,
	VeryHigh                       = 3,
	Max_None                       = 4,
	EFortEncounterUtilityDesire_MAX = 5
};


// Enum FortniteGame.EFortAIDirectorFactorContribution
enum class EFortAIDirectorFactorContribution : uint8_t
{
	Direct                         = 0,
	Inverse                        = 1,
	EFortAIDirectorFactorContribution_MAX = 2
};


// Enum FortniteGame.EFortAIDirectorEventContribution
enum class EFortAIDirectorEventContribution : uint8_t
{
	Increment                      = 0,
	Set                            = 1,
	EFortAIDirectorEventContribution_MAX = 2
};


// Enum FortniteGame.EFortAIWaveProgressSection
enum class EFortAIWaveProgressSection : uint8_t
{
	SectionOne                     = 0,
	SectionTwo                     = 1,
	Max_None                       = 2,
	EFortAIWaveProgressSection_MAX = 3
};


// Enum FortniteGame.EFortEncounterState
enum class EFortEncounterState : uint8_t
{
	Uninitialized                  = 0,
	InitializingProperties         = 1,
	InitializingRiftManager        = 2,
	AwaitingActivation             = 3,
	Active                         = 4,
	Max_None                       = 5,
	EFortEncounterState_MAX        = 6
};


// Enum FortniteGame.EFortEncounterPacingState
enum class EFortEncounterPacingState : uint8_t
{
	Ramp                           = 0,
	Peak                           = 1,
	Fade                           = 2,
	Rest                           = 3,
	Max_None                       = 4,
	EFortEncounterPacingState_MAX  = 5
};


// Enum FortniteGame.EFortEncounterSequenceResult
enum class EFortEncounterSequenceResult : uint8_t
{
	Success                        = 0,
	FailedEncounterInProgress      = 1,
	EFortEncounterSequenceResult_MAX = 2
};


// Enum FortniteGame.EAssignmentCreationResult
enum class EAssignmentCreationResult : uint8_t
{
	AssignmentNotFoundOrCreated    = 0,
	AssignmentCreated              = 1,
	AssignmentFound                = 2,
	EAssignmentCreationResult_MAX  = 3
};


// Enum FortniteGame.ETagGoalScoringCategory
enum class ETagGoalScoringCategory : uint8_t
{
	Ignore                         = 0,
	HighInterest                   = 1,
	NumCategories                  = 2,
	ETagGoalScoringCategory_MAX    = 3
};


// Enum FortniteGame.EFortAIPawnGender
enum class EFortAIPawnGender : uint8_t
{
	FAPG_Default                   = 0,
	FAPG_Female                    = 1,
	FAPG_Male                      = 2,
	FAPG_MAX                       = 3
};


// Enum FortniteGame.EFortAILevelRatingDisplayType
enum class EFortAILevelRatingDisplayType : uint8_t
{
	DisplayRatingBasedOnDifficulty = 0,
	DisplayAIDifficultyAsRating    = 1,
	DontDisplayRating              = 2,
	EFortAILevelRatingDisplayType_MAX = 3
};


// Enum FortniteGame.EFortressAIType
enum class EFortressAIType : uint8_t
{
	FAT_Dormant                    = 0,
	FAT_Cleaner                    = 1,
	FAT_DayWanderer                = 2,
	FAT_NightWanderer              = 3,
	FAT_DebugOnly                  = 4,
	FAT_Encounter                  = 5,
	FAT_MAX                        = 6
};


// Enum FortniteGame.ECorePerceptionTypes
enum class ECorePerceptionTypes : uint8_t
{
	Sight                          = 0,
	Hearing                        = 1,
	Damage                         = 2,
	Touch                          = 3,
	Team                           = 4,
	Prediction                     = 5,
	MAX                            = 6
};


// Enum FortniteGame.ENavigationObstacleOverride
enum class ENavigationObstacleOverride : uint8_t
{
	UseMeshSettings                = 0,
	ForceEnabled                   = 1,
	ForceDisabled                  = 2,
	ENavigationObstacleOverride_MAX = 3
};


// Enum FortniteGame.EFortPartialPathUsage
enum class EFortPartialPathUsage : uint8_t
{
	Always                         = 0,
	OnlyGoalsOnDestructible        = 1,
	Never                          = 2,
	EFortPartialPathUsage_MAX      = 3
};


// Enum FortniteGame.EHotspotTypeConfigMode
enum class EHotspotTypeConfigMode : uint8_t
{
	AlwaysAdd                      = 0,
	WhenNotDefined                 = 1,
	WhenNotValid                   = 2,
	EHotspotTypeConfigMode_MAX     = 3
};


// Enum FortniteGame.EFortHotSpotPreview
enum class EFortHotSpotPreview : uint8_t
{
	None                           = 0,
	Smashing                       = 1,
	Shooting                       = 2,
	EFortHotSpotPreview_MAX        = 3
};


// Enum FortniteGame.EFortHotSpotDirection
enum class EFortHotSpotDirection : uint8_t
{
	PositiveX                      = 0,
	NegativeX                      = 1,
	PositiveY                      = 2,
	NegativeY                      = 3,
	PositiveZ                      = 4,
	NegativeZ                      = 5,
	Any                            = 6,
	EFortHotSpotDirection_MAX      = 7
};


// Enum FortniteGame.EFortHotSpotSlot
enum class EFortHotSpotSlot : uint8_t
{
	Melee                          = 0,
	MeleeHuge                      = 1,
	Ranged                         = 2,
	None                           = 3,
	EFortHotSpotSlot_MAX           = 4
};


// Enum FortniteGame.EBuildingFloorRailing
enum class EBuildingFloorRailing : uint8_t
{
	None                           = 0,
	Balcony                        = 1,
	EBuildingFloorRailing_MAX      = 2
};


// Enum FortniteGame.EBuildingStairsRailing
enum class EBuildingStairsRailing : uint8_t
{
	None                           = 0,
	Partial                        = 1,
	Full                           = 2,
	EBuildingStairsRailing_MAX     = 3
};


// Enum FortniteGame.EBuildingWallArea
enum class EBuildingWallArea : uint8_t
{
	Regular                        = 0,
	Flat                           = 1,
	Special                        = 2,
	EBuildingWallArea_MAX          = 3
};


// Enum FortniteGame.EAssignmentType
enum class EAssignmentType : uint8_t
{
	Invalid                        = 0,
	Encounter                      = 1,
	World                          = 2,
	Enemy                          = 3,
	NumAssignmentTypes             = 4,
	EAssignmentType_MAX            = 5
};


// Enum FortniteGame.EFortAILODLevel
enum class EFortAILODLevel : uint8_t
{
	Invalid                        = 0,
	Lowest                         = 1,
	Lower                          = 2,
	BelowNormal                    = 3,
	Normal                         = 4,
	AboveNormal                    = 5,
	EFortAILODLevel_MAX            = 6
};


// Enum FortniteGame.ESpeedWarpingAxisMode
enum class ESpeedWarpingAxisMode : uint8_t
{
	IKFootRootLocalX               = 0,
	IKFootRootLocalY               = 1,
	IKFootRootLocalZ               = 2,
	WorldSpaceVectorInput          = 3,
	ComponentSpaceVectorInput      = 4,
	ActorSpaceVectorInput          = 5,
	ESpeedWarpingAxisMode_MAX      = 6
};


// Enum FortniteGame.EMontageInterrupt
enum class EMontageInterrupt : uint8_t
{
	Any                            = 0,
	RootMotionOnly                 = 1,
	None                           = 2,
	EMontageInterrupt_MAX          = 3
};


// Enum FortniteGame.EFortAttributeDisplay
enum class EFortAttributeDisplay : uint8_t
{
	BasicInt                       = 0,
	NegativeImpliesInfiniteInt     = 1,
	BasicFloat                     = 2,
	NegativeImpliesInfiniteFloat   = 3,
	BasicString                    = 4,
	NormalizedPercentage           = 5,
	StringArray                    = 6,
	SlateBrush                     = 7,
	DoNotDisplay                   = 8,
	None_Max                       = 9,
	EFortAttributeDisplay_MAX      = 10
};


// Enum FortniteGame.ETargetDistanceComparisonType
enum class ETargetDistanceComparisonType : uint8_t
{
	TwoDimensions                  = 0,
	ThreeDimensions                = 1,
	CollisionHalfHeightMultiplier  = 2,
	ETargetDistanceComparisonType_MAX = 3
};


// Enum FortniteGame.ECameraOrigin
enum class ECameraOrigin : uint8_t
{
	ViewTargetTransform            = 0,
	BoneTransform                  = 1,
	ECameraOrigin_MAX              = 2
};


// Enum FortniteGame.EFortCharacterCosmetic
enum class EFortCharacterCosmetic : uint8_t
{
	Head                           = 0,
	Texture                        = 1,
	Color                          = 2,
	Trinket                        = 3,
	Face                           = 4,
	Gadget                         = 5,
	Body                           = 6,
	ClassFlair                     = 7,
	Max_Invalid                    = 8,
	EFortCharacterCosmetic_MAX     = 9
};


// Enum FortniteGame.EFortAnnouncementDisplayPreference
enum class EFortAnnouncementDisplayPreference : uint8_t
{
	Default_HUD                    = 0,
	QuestIntroduction              = 1,
	QuestJournal                   = 2,
	EFortAnnouncementDisplayPreference_MAX = 3
};


// Enum FortniteGame.EFortAnnouncementChannel
enum class EFortAnnouncementChannel : uint8_t
{
	Primary                        = 0,
	Conversation                   = 1,
	Tutorial                       = 2,
	Max_None                       = 3,
	EFortAnnouncementChannel_MAX   = 4
};


// Enum FortniteGame.EFortAnnouncementDelivery
enum class EFortAnnouncementDelivery : uint8_t
{
	Created                        = 0,
	Received                       = 1,
	Ignored                        = 2,
	Active                         = 3,
	Stopped                        = 4,
	Max_None                       = 5,
	EFortAnnouncementDelivery_MAX  = 6
};


// Enum FortniteGame.ECodeTokenPlatform
enum class ECodeTokenPlatform : uint8_t
{
	PC                             = 0,
	PS4                            = 1,
	XBOX                           = 2,
	ECodeTokenPlatform_MAX         = 3
};


// Enum FortniteGame.EFortCollectionBookState
enum class EFortCollectionBookState : uint8_t
{
	Active                         = 0,
	Completed                      = 1,
	Claimed                        = 2,
	EFortCollectionBookState_MAX   = 3
};


// Enum FortniteGame.EFortPIDValueGraphElements
enum class EFortPIDValueGraphElements : uint8_t
{
	Proportional                   = 0,
	Integral                       = 1,
	Max_None                       = 2,
	EFortPIDValueGraphElements_MAX = 3
};


// Enum FortniteGame.EFortIntensityGraphElements
enum class EFortIntensityGraphElements : uint8_t
{
	ActualIntensity                = 0,
	DesiredIntensity               = 1,
	Max_None                       = 2,
	EFortIntensityGraphElements_MAX = 3
};


// Enum FortniteGame.EFortContributionGraphElements
enum class EFortContributionGraphElements : uint8_t
{
	ProportionalLine               = 0,
	IntegralLine                   = 1,
	TotalLine                      = 2,
	PendingLine                    = 3,
	ActionLine                     = 4,
	Max_None                       = 5,
	EFortContributionGraphElements_MAX = 6
};


// Enum FortniteGame.EFortFactorContributionType
enum class EFortFactorContributionType : uint8_t
{
	CurrentValue_Direct            = 0,
	CurrentValue_Inverse           = 1,
	AverageValue_Direct            = 2,
	AverageValue_Inverse           = 3,
	EFortFactorContributionType_MAX = 4
};


// Enum FortniteGame.EFortAIDirectorFactor
enum class EFortAIDirectorFactor : uint8_t
{
	PlayerDamageThreat             = 0,
	ObjectiveDamageThreat          = 1,
	ObjectivePathCost              = 2,
	PlayerPathCost                 = 3,
	PlayerMovement                 = 4,
	TrapsEffective                 = 5,
	PlayerWander                   = 6,
	NearbyEnemyPresence            = 7,
	OffensiveResources             = 8,
	DefensiveResources             = 9,
	Boredom                        = 10,
	ArtilleryVulnerability         = 11,
	Max_None                       = 12,
	EFortAIDirectorFactor_MAX      = 13
};


// Enum FortniteGame.EFortCombatFactors
enum class EFortCombatFactors : uint8_t
{
	PlayerDamageThreat             = 0,
	ObjectiveDamageThreat          = 1,
	ObjectivePathCost              = 2,
	PlayerPathCost                 = 3,
	PlayerMovement                 = 4,
	TrapsEffective                 = 5,
	PlayerWander                   = 6,
	NearbyEnemyPresence            = 7,
	OffensiveResources             = 8,
	DefensiveResources             = 9,
	Boredom                        = 10,
	ArtilleryVulnerability         = 11,
	Max_None                       = 12,
	EFortCombatFactors_MAX         = 13
};


// Enum FortniteGame.EFortCombatEvents
enum class EFortCombatEvents : uint8_t
{
	HuskFollowing                  = 0,
	SmasherFollowing               = 1,
	TrollFollowing                 = 2,
	TakerFollowing                 = 3,
	PlayerTakeDamage               = 4,
	PlayerHealth                   = 5,
	PlayerLookAtEnemy              = 6,
	PlayerDamageEnemy              = 7,
	PlayerKilledEnemy              = 8,
	AtlasTakeDamage                = 9,
	AtlasHealth                    = 10,
	AtlasDestroyed                 = 11,
	TrapFiring                     = 12,
	BuildingTakeDamage             = 13,
	FoodHealingPotential           = 14,
	PlayerAmmo                     = 15,
	EnemiesNear                    = 16,
	PlayerMovement                 = 17,
	BuildingDamagedNearObjective   = 18,
	TrapDamageEnemy                = 19,
	ObjectivePathCost              = 20,
	PlayerPathCost                 = 21,
	Max_None                       = 22,
	EFortCombatEvents_MAX          = 23
};


// Enum FortniteGame.EFortAIDirectorEventParticipant
enum class EFortAIDirectorEventParticipant : uint8_t
{
	Target                         = 0,
	Source                         = 1,
	Either                         = 2,
	Max_None                       = 3,
	EFortAIDirectorEventParticipant_MAX = 4
};


// Enum FortniteGame.EFortCombatThresholds
enum class EFortCombatThresholds : uint8_t
{
	Low                            = 0,
	Medium                         = 1,
	High                           = 2,
	Extreme                        = 3,
	Max_None                       = 4,
	EFortCombatThresholds_MAX      = 5
};


// Enum FortniteGame.EFortElementalDamageType
enum class EFortElementalDamageType : uint8_t
{
	None                           = 0,
	Fire                           = 1,
	Ice                            = 2,
	Lightning                      = 3,
	MAX                            = 4
};


// Enum FortniteGame.EFortDamageZone
enum class EFortDamageZone : uint8_t
{
	Light                          = 0,
	Normal                         = 1,
	Critical                       = 2,
	Vulnerability                  = 3,
	Max                            = 4
};


// Enum FortniteGame.EFortBaseWeaponDamage
enum class EFortBaseWeaponDamage : uint8_t
{
	Combat                         = 0,
	Environmental                  = 1,
	EFortBaseWeaponDamage_MAX      = 2
};


// Enum FortniteGame.EFortWeaponCoreAnimation
enum class EFortWeaponCoreAnimation : uint8_t
{
	Melee                          = 0,
	Pistol                         = 1,
	Shotgun                        = 2,
	PaperBlueprint                 = 3,
	Rifle                          = 4,
	MeleeOneHand                   = 5,
	MachinePistol                  = 6,
	RocketLauncher                 = 7,
	GrenadeLauncher                = 8,
	GoingCommando                  = 9,
	AssaultRifle                   = 10,
	TacticalShotgun                = 11,
	SniperRifle                    = 12,
	TrapPlacement                  = 13,
	ShoulderLauncher               = 14,
	AbilityDecoTool                = 15,
	EFortWeaponCoreAnimation_MAX   = 16
};


// Enum FortniteGame.EFortReloadFXState
enum class EFortReloadFXState : uint8_t
{
	ReloadStart                    = 0,
	ReloadCartridge                = 1,
	ReloadEnd                      = 2,
	Max_None                       = 3,
	EFortReloadFXState_MAX         = 4
};


// Enum FortniteGame.EFortWeaponSoundState
enum class EFortWeaponSoundState : uint8_t
{
	Normal                         = 0,
	LowAmmo                        = 1,
	Degraded                       = 2,
	Max_None                       = 3,
	EFortWeaponSoundState_MAX      = 4
};


// Enum FortniteGame.EFortMontageInputType
enum class EFortMontageInputType : uint8_t
{
	WindowClickOrHold              = 0,
	WindowHoldOnly                 = 1,
	InstantClick                   = 2,
	EFortMontageInputType_MAX      = 3
};


// Enum FortniteGame.EFortAbilityTargetingSource
enum class EFortAbilityTargetingSource : uint8_t
{
	Camera                         = 0,
	PawnForward                    = 1,
	PawnTowardsFocus               = 2,
	WeaponForward                  = 3,
	WeaponTowardsFocus             = 4,
	Custom                         = 5,
	Max_None                       = 6,
	EFortAbilityTargetingSource_MAX = 7
};


// Enum FortniteGame.EFortAmmoType
enum class EFortAmmoType : uint8_t
{
	Pistol                         = 0,
	Shotgun                        = 1,
	Assault                        = 2,
	Sniper                         = 3,
	Energy                         = 4,
	EFortAmmoType_MAX              = 5
};


// Enum FortniteGame.EFortSentenceAudioPreference
enum class EFortSentenceAudioPreference : uint8_t
{
	AudioAsset                     = 0,
	FeedbackBank                   = 1,
	EFortSentenceAudioPreference_MAX = 2
};


// Enum FortniteGame.EFortDamageNumberType
enum class EFortDamageNumberType : uint8_t
{
	None                           = 0,
	Pawn                           = 1,
	Building                       = 2,
	Player                         = 3,
	Shield                         = 4,
	Score                          = 5,
	DBNO                           = 6,
	EFortDamageNumberType_MAX      = 7
};


// Enum FortniteGame.ETimespanAsTextFormat
enum class ETimespanAsTextFormat : uint8_t
{
	DaysHoursMinutesSeconds        = 0,
	Colons                         = 1,
	ETimespanAsTextFormat_MAX      = 2
};


// Enum FortniteGame.EFortDefenderSubtype
enum class EFortDefenderSubtype : uint8_t
{
	AssaultRifle                   = 0,
	Pistol                         = 1,
	Melee                          = 2,
	Sniper                         = 3,
	Shotgun                        = 4,
	Invalid                        = 5,
	EFortDefenderSubtype_MAX       = 6
};


// Enum FortniteGame.EHordeTierStartStatus
enum class EHordeTierStartStatus : uint8_t
{
	ReadyToStart                   = 0,
	WaitingForPlayer               = 1,
	WaitingForDBM                  = 2,
	GenericNotReadyToStart         = 3,
	EHordeTierStartStatus_MAX      = 4
};


// Enum FortniteGame.EHordeWaveStingerType
enum class EHordeWaveStingerType : uint8_t
{
	WaveSuccess                    = 0,
	WaveFailure                    = 1,
	WaveIncoming                   = 2,
	WaveStarted                    = 3,
	EHordeWaveStingerType_MAX      = 4
};


// Enum FortniteGame.EQueueActionType
enum class EQueueActionType : uint8_t
{
	Plot                           = 0,
	ZoneCleanup                    = 1,
	EnvironmentActorRestoration    = 2,
	EQueueActionType_MAX           = 3
};


// Enum FortniteGame.EAthenaPIEStartupMode
enum class EAthenaPIEStartupMode : uint8_t
{
	UseDefaults                    = 0,
	Warmup                         = 1,
	WarmupPaused                   = 2,
	Aircraft                       = 3,
	AircraftPaused                 = 4,
	Gameplay                       = 5,
	EAthenaPIEStartupMode_MAX      = 6
};


// Enum FortniteGame.FDynamicBuildOrder
enum class EFDynamicBuildOrder : uint8_t
{
	X                              = 0,
	Y                              = 1,
	Z                              = 2,
	None                           = 3,
	FDynamicBuildOrder_MAX         = 4
};


// Enum FortniteGame.EFortFeedbackBroadcastFilter
enum class EFortFeedbackBroadcastFilter : uint8_t
{
	FFBF_Speaker                   = 0,
	FFBF_SpeakerTeam               = 1,
	FFBF_SpeakerAdressee           = 2,
	FFBF_HumanPvP_Team1            = 3,
	FFBF_HumanPvP_Team2            = 4,
	FFBF_None_Max                  = 5,
	FFBF_MAX                       = 6
};


// Enum FortniteGame.EFortFeedbackSelectionMethod
enum class EFortFeedbackSelectionMethod : uint8_t
{
	FFSM_Instigator                = 0,
	FFSM_Recipient                 = 1,
	FFSM_TeamWitness               = 2,
	FFSM_EnemyWitness              = 3,
	FFSM_Random                    = 4,
	FFSM_Priority_IRTE             = 5,
	FFSM_AllPawns                  = 6,
	FFSM_Announcer                 = 7,
	FFSM_MAX                       = 8
};


// Enum FortniteGame.EFortFeedbackAddressee
enum class EFortFeedbackAddressee : uint8_t
{
	FFA_Instigator                 = 0,
	FFA_Recipient                  = 1,
	FFA_All                        = 2,
	FFA_MAX                        = 3
};


// Enum FortniteGame.EFortFeedbackContext
enum class EFortFeedbackContext : uint8_t
{
	FFC_Instigator                 = 0,
	FFC_Recipient                  = 1,
	FFC_TeamWitness                = 2,
	FFC_EnemyWitness               = 3,
	FFC_AllPawns                   = 4,
	FFC_Announcer                  = 5,
	FFC_None_Max                   = 6,
	FFC_MAX                        = 7
};


// Enum FortniteGame.EFortFootstepSurfaceType
enum class EFortFootstepSurfaceType : uint8_t
{
	Default                        = 0,
	Wood                           = 1,
	Stone                          = 2,
	Metal                          = 3,
	Water                          = 4,
	Snow                           = 5,
	Max_None                       = 6,
	EFortFootstepSurfaceType_MAX   = 7
};


// Enum FortniteGame.EFortFootstepAudioType
enum class EFortFootstepAudioType : uint8_t
{
	Crouch                         = 0,
	CrouchSprint                   = 1,
	Walk                           = 2,
	Sprint                         = 3,
	Jump                           = 4,
	Land                           = 5,
	LandHard                       = 6,
	Max_None                       = 7,
	EFortFootstepAudioType_MAX     = 8
};


// Enum FortniteGame.EWaveRules
enum class EWaveRules : uint8_t
{
	KillAllEnemies                 = 0,
	Timed                          = 1,
	KillPoints                     = 2,
	EWaveRules_MAX                 = 3
};


// Enum FortniteGame.EFriendFeedbackType
enum class EFriendFeedbackType : uint8_t
{
	FriendRequestSent              = 0,
	FriendRequestReceived          = 1,
	FriendRequestAccepted          = 2,
	Default                        = 3,
	EFriendFeedbackType_MAX        = 4
};


// Enum FortniteGame.EClampType
enum class EClampType : uint8_t
{
	Minimum                        = 0,
	Maximum                        = 1,
	EClampType_MAX                 = 2
};


// Enum FortniteGame.EFortAbilityCostSource
enum class EFortAbilityCostSource : uint8_t
{
	Stamina                        = 0,
	Durability                     = 1,
	AmmoMagazine                   = 2,
	AmmoPrimary                    = 3,
	Item                           = 4,
	EFortAbilityCostSource_MAX     = 5
};


// Enum FortniteGame.EFortGameplayAbilityActivation
enum class EFortGameplayAbilityActivation : uint8_t
{
	Passive                        = 0,
	Triggered                      = 1,
	Active                         = 2,
	EFortGameplayAbilityActivation_MAX = 3
};


// Enum FortniteGame.EFortAIWeaponUsage
enum class EFortAIWeaponUsage : uint8_t
{
	NoWeaponUsage                  = 0,
	UsesRangedWeapon               = 1,
	UsesMeleeWeapon                = 2,
	EFortAIWeaponUsage_MAX         = 3
};


// Enum FortniteGame.EFortGameplayAbilityMontageSectionToPlay
enum class EFortGameplayAbilityMontageSectionToPlay : uint8_t
{
	FirstSection                   = 0,
	RandomSection                  = 1,
	TestedRandomSection            = 2,
	EFortGameplayAbilityMontageSectionToPlay_MAX = 3
};


// Enum FortniteGame.EPvPGameEndReasons
enum class EPvPGameEndReasons : uint8_t
{
	PVPGER_TeamScoreLimit          = 0,
	PVPGER_LastManStanding         = 1,
	PVPGER_TimeExpired             = 2,
	PVPGER_MissionCompletion       = 3,
	PVPGER_MAX                     = 4
};


// Enum FortniteGame.EFortServerGameMode
enum class EFortServerGameMode : uint8_t
{
	Idle                           = 0,
	LobbyPvE                       = 1,
	LobbyPvP                       = 2,
	ZonePvP                        = 3,
	ZonePvE                        = 4,
	EFortServerGameMode_MAX        = 5
};


// Enum FortniteGame.EFortBanHammerNotificationAction
enum class EFortBanHammerNotificationAction : uint8_t
{
	DelayedBanAndKick              = 0,
	ImmediateBanAndKick            = 1,
	ImmediateKick                  = 2,
	EFortBanHammerNotificationAction_MAX = 3
};


// Enum FortniteGame.ETeamChatRoomState
enum class ETeamChatRoomState : uint8_t
{
	NotCreated                     = 0,
	Creating                       = 1,
	Created                        = 2,
	Timeout                        = 3,
	ETeamChatRoomState_MAX         = 4
};


// Enum FortniteGame.EAthenaAerialPhase
enum class EAthenaAerialPhase : uint8_t
{
	None                           = 0,
	BusCantExit                    = 1,
	BusCanExit                     = 2,
	Skydiving                      = 3,
	Parachuting                    = 4,
	EAthenaAerialPhase_MAX         = 5
};


// Enum FortniteGame.EFortAccountLinkingUIConfig
enum class EFortAccountLinkingUIConfig : uint8_t
{
	Disabled                       = 0,
	Default                        = 1,
	ExternalViewerOnly             = 2,
	FullExternal                   = 3,
	EFortAccountLinkingUIConfig_MAX = 4
};


// Enum FortniteGame.ESpecializationType
enum class ESpecializationType : uint8_t
{
	Tier1                          = 0,
	Tier2                          = 1,
	Tier3                          = 2,
	Tier4                          = 3,
	NumTiers                       = 4,
	ESpecializationType_MAX        = 5
};


// Enum FortniteGame.EFortSupportBonusType
enum class EFortSupportBonusType : uint8_t
{
	Normal                         = 0,
	Tactical                       = 1,
	Max_None                       = 2,
	EFortSupportBonusType_MAX      = 3
};


// Enum FortniteGame.EFortHexTileAdjacency
enum class EFortHexTileAdjacency : uint8_t
{
	North                          = 0,
	NorthEast                      = 1,
	SouthEast                      = 2,
	South                          = 3,
	SouthWest                      = 4,
	NorthWest                      = 5,
	Max_None                       = 6,
	EFortHexTileAdjacency_MAX      = 7
};


// Enum FortniteGame.EPrereqNodeType
enum class EPrereqNodeType : uint8_t
{
	Invalid                        = 0,
	SkillPoint                     = 1,
	ResearchPoint                  = 2,
	All                            = 3,
	EPrereqNodeType_MAX            = 4
};


// Enum FortniteGame.EFortHomebaseNodeActionType
enum class EFortHomebaseNodeActionType : uint8_t
{
	None                           = 0,
	DrillDown                      = 1,
	CollectResources               = 2,
	Max_None                       = 3,
	EFortHomebaseNodeActionType_MAX = 4
};


// Enum FortniteGame.EFortHomebaseNodeMagnitude
enum class EFortHomebaseNodeMagnitude : uint8_t
{
	Small                          = 0,
	Medium                         = 1,
	Large                          = 2,
	Max_None                       = 3,
	EFortHomebaseNodeMagnitude_MAX = 4
};


// Enum FortniteGame.EFortHomebaseNodeDisplayType
enum class EFortHomebaseNodeDisplayType : uint8_t
{
	Stat                           = 0,
	SquadSlot                      = 1,
	Gadget                         = 2,
	Inventory                      = 3,
	Hero                           = 4,
	ExitNode                       = 5,
	Max_None                       = 6,
	EFortHomebaseNodeDisplayType_MAX = 7
};


// Enum FortniteGame.EFortHomebaseSquadSlotType
enum class EFortHomebaseSquadSlotType : uint8_t
{
	GroundSlot                     = 0,
	SupportSlot                    = 1,
	TacticalSlot                   = 2,
	Max_None                       = 3,
	EFortHomebaseSquadSlotType_MAX = 4
};


// Enum FortniteGame.EFortHomebaseSquadType
enum class EFortHomebaseSquadType : uint8_t
{
	AttributeSquad                 = 0,
	CombatSquad                    = 1,
	DefenderSquad                  = 2,
	ExpeditionSquad                = 3,
	Max_None                       = 4,
	EFortHomebaseSquadType_MAX     = 5
};


// Enum FortniteGame.EFortHuskAnimType
enum class EFortHuskAnimType : uint8_t
{
	Basic                          = 0,
	Dwarf                          = 1,
	BlasterBig                     = 2,
	Weak                           = 3,
	TinyHead                       = 4,
	Beehive                        = 5,
	Husky                          = 6,
	Sploder                        = 7,
	EFortHuskAnimType_MAX          = 8
};


// Enum FortniteGame.EFortIntensityCurveSequenceType
enum class EFortIntensityCurveSequenceType : uint8_t
{
	Sequence                       = 0,
	Loop                           = 1,
	Random                         = 2,
	Max_None                       = 3,
	EFortIntensityCurveSequenceType_MAX = 4
};


// Enum FortniteGame.TInteractionType
enum class ETInteractionType : uint8_t
{
	IT_NoInteraction               = 0,
	IT_Simple                      = 1,
	IT_LongPress                   = 2,
	IT_BuildingEdit                = 3,
	IT_BuildingImprovement         = 4,
	IT_TrapPlacement               = 5,
	IT_MAX                         = 6
};


// Enum FortniteGame.EItemEvolutionRestrictionReason
enum class EItemEvolutionRestrictionReason : uint8_t
{
	NoEvolutions                   = 0,
	BelowMaximumLevel              = 1,
	VaultOverflow                  = 2,
	MissingCatalyst                = 3,
	MissingCosts                   = 4,
	NoRarityUpgrade                = 5,
	EItemEvolutionRestrictionReason_MAX = 6
};


// Enum FortniteGame.EItemUpgradeRestrictionReason
enum class EItemUpgradeRestrictionReason : uint8_t
{
	NoAdditionalLevels             = 0,
	MaximumLevelAchieved           = 1,
	VaultOverflow                  = 2,
	EItemUpgradeRestrictionReason_MAX = 3
};


// Enum FortniteGame.EFortTemplateAccess
enum class EFortTemplateAccess : uint8_t
{
	Normal                         = 0,
	Trusted                        = 1,
	Private                        = 2,
	EFortTemplateAccess_MAX        = 3
};


// Enum FortniteGame.EFortItemEntryState
enum class EFortItemEntryState : uint8_t
{
	NoneState                      = 0,
	NewItemCount                   = 1,
	ShouldShowItemToast            = 2,
	DurabilityInitialized          = 3,
	DoNotShowSpawnParticles        = 4,
	FromRecoveredBackpack          = 5,
	FromGift                       = 6,
	PendingUpgradeCriteriaProgress = 7,
	OwnerBuildingHandle            = 8,
	FromDroppedPickup              = 9,
	CraftAndSlotTarget             = 10,
	EFortItemEntryState_MAX        = 11
};


// Enum FortniteGame.ELobbyMissionGeneratorDetailsRequirement
enum class ELobbyMissionGeneratorDetailsRequirement : uint8_t
{
	Unknown                        = 0,
	NotRequired                    = 1,
	Required                       = 2,
	ELobbyMissionGeneratorDetailsRequirement_MAX = 3
};


// Enum FortniteGame.ELootQuotaLevel
enum class ELootQuotaLevel : uint8_t
{
	Unlimited                      = 0,
	Level1                         = 1,
	Level2                         = 2,
	Level3                         = 3,
	Level4                         = 4,
	Level5                         = 5,
	Level6                         = 6,
	Level7                         = 7,
	Level8                         = 8,
	Level9                         = 9,
	Level10                        = 10,
	Level11                        = 11,
	Level12                        = 12,
	Level13                        = 13,
	Level14                        = 14,
	Level15                        = 15,
	Level16                        = 16,
	Level17                        = 17,
	NumLevels                      = 18,
	ELootQuotaLevel_MAX            = 19
};


// Enum FortniteGame.EFortMatchmakingType
enum class EFortMatchmakingType : uint8_t
{
	Gathering                      = 0,
	CriticalMission                = 1,
	QuickPlay                      = 2,
	Session                        = 3,
	EFortMatchmakingType_MAX       = 4
};


// Enum FortniteGame.EFortSessionHelperJoinResult
enum class EFortSessionHelperJoinResult : uint8_t
{
	NoResult                       = 0,
	ReservationSuccess             = 1,
	ReservationFailure_PartyLimitReached = 2,
	ReservationFailure_IncorrectPlayerCount = 3,
	ReservationFailure_RequestTimedOut = 4,
	ReservationFailure_ReservationNotFound = 5,
	ReservationFailure_ReservationDenied = 6,
	ReservationFailure_ReservationDenied_Banned = 7,
	ReservationFailure_ReservationRequestCanceled = 8,
	ReservationFailure_ReservationInvalid = 9,
	ReservationFailure_BadSessionId = 10,
	ReservationFailure_ReservationDenied_ContainsExistingPlayers = 11,
	ReservationFailure_GeneralError = 12,
	ReservationFailure_NoSubsystem = 13,
	ReservationFailure_NoIdentity  = 14,
	ReservationFailure_InvalidSession = 15,
	ReservationFailure_InvalidUser = 16,
	ReservationFailure_EncryptionKey = 17,
	ReservationFailure_RefreshAuth = 18,
	ReservationFailure_AlreadyJoiningDuringReserve = 19,
	ReservationFailure_AlreadyJoiningDuringSkip = 20,
	JoinSessionSuccess             = 21,
	JoinSessionFailure_SessionIsFull = 22,
	JoinSessionFailure_SessionDoesNotExist = 23,
	JoinSessionFailure_CouldNotRetrieveAddress = 24,
	JoinSessionFailure_AlreadyInSession = 25,
	JoinSessionFailure_UnknownError = 26,
	JoinSessionFailure_InvalidSession = 27,
	JoinSessionFailure_InvalidSearchResultIndex = 28,
	JoinSessionFailure_AlreadyJoiningDuringJoin = 29,
	SearchPassFailure_NoSessionHelper = 30,
	SearchPassFailure_InvalidUser  = 31,
	SearchPassFailure_NoIdentity   = 32,
	SearchPassFailure_InvalidSearchResult = 33,
	SearchPassFailure_InvalidSearchResultIndex = 34,
	JoinSessionCanceled            = 35,
	EFortSessionHelperJoinResult_MAX = 36
};


// Enum FortniteGame.EFortMatchmakingPool
enum class EFortMatchmakingPool : uint8_t
{
	Any                            = 0,
	Desktop                        = 1,
	PS4                            = 2,
	XboxOne                        = 3,
	Mobile                         = 4,
	EFortMatchmakingPool_MAX       = 5
};


// Enum FortniteGame.EFortMatchmakingPrivacyConfiguration
enum class EFortMatchmakingPrivacyConfiguration : uint8_t
{
	UserPartyConfigured            = 0,
	ForcePrivate                   = 1,
	ForcePublic                    = 2,
	EFortMatchmakingPrivacyConfiguration_MAX = 3
};


// Enum FortniteGame.EMatchmakingFlags
enum class EMatchmakingFlags : uint8_t
{
	None                           = 0,
	CreateNewOnly                  = 1,
	NoReservation                  = 2,
	Private                        = 3,
	UseWorldDataOwner              = 4,
	EMatchmakingFlags_MAX          = 5
};


// Enum FortniteGame.EMatchmakingStartLocation
enum class EMatchmakingStartLocation : uint8_t
{
	Lobby                          = 0,
	Game                           = 1,
	CreateNew                      = 2,
	FindSingle                     = 3,
	EMatchmakingStartLocation_MAX  = 4
};


// Enum FortniteGame.EFortMtxPlatform
enum class EFortMtxPlatform : uint8_t
{
	Epic                           = 0,
	PSN                            = 1,
	Live                           = 2,
	Shared                         = 3,
	EFortMtxPlatform_MAX           = 4
};


// Enum FortniteGame.EAthenaProgressiveCosmeticType
enum class EAthenaProgressiveCosmeticType : uint8_t
{
	None                           = 0,
	AllTimeWins                    = 1,
	EAthenaProgressiveCosmeticType_MAX = 2
};


// Enum FortniteGame.EAthenaCustomizationCategory
enum class EAthenaCustomizationCategory : uint8_t
{
	None                           = 0,
	Glider                         = 1,
	Pickaxe                        = 2,
	Hat                            = 3,
	Backpack                       = 4,
	Character                      = 5,
	LoadingScreen                  = 6,
	BattleBus                      = 7,
	Dance                          = 8,
	ConsumableEmote                = 9,
	VictoryPose                    = 10,
	EAthenaCustomizationCategory_MAX = 11
};


// Enum FortniteGame.ETwitchViewerStatusType
enum class ETwitchViewerStatusType : uint8_t
{
	TwitchViewerStatus_Unknown     = 0,
	TwitchViewerStatus_Nonsubscriber = 1,
	TwitchViewerStatus_Subscriber  = 2,
	TwitchViewerStatus_Broadcaster = 3,
	TwitchViewerStatus_Max         = 4
};


// Enum FortniteGame.EMcpLeaderboardTimeWindow
enum class EMcpLeaderboardTimeWindow : uint8_t
{
	Daily                          = 0,
	Weekly                         = 1,
	Monthly                        = 2,
	AllTime                        = 3,
	EMcpLeaderboardTimeWindow_MAX  = 4
};


// Enum FortniteGame.EFortMiniMapIconRotation
enum class EFortMiniMapIconRotation : uint8_t
{
	EFMMIR_None                    = 0,
	EFMMIR_Absolute                = 1,
	EFMMIR_Relative                = 2,
	EFMMIR_MAX                     = 3
};


// Enum FortniteGame.EFortMiniMapContext
enum class EFortMiniMapContext : uint8_t
{
	EFMC_MiniMap                   = 0,
	EFMC_FullScreenMap             = 1,
	EFMC_MAX                       = 2
};


// Enum FortniteGame.EFortMiniMapHeight
enum class EFortMiniMapHeight : uint8_t
{
	EFMH_Equal                     = 0,
	EFMH_Below                     = 1,
	EFMH_Above                     = 2,
	EFMH_MAX                       = 3
};


// Enum FortniteGame.EFortCheatMissionGenType
enum class EFortCheatMissionGenType : uint8_t
{
	NewGeneration                  = 0,
	OldGeneration                  = 1,
	Max_None                       = 2,
	EFortCheatMissionGenType_MAX   = 3
};


// Enum FortniteGame.EFortOptionGenerationResult
enum class EFortOptionGenerationResult : uint8_t
{
	NoOptionsGenerated             = 0,
	NewOptionsGenerated            = 1,
	ExistingOptionsGenerated       = 2,
	EFortOptionGenerationResult_MAX = 3
};


// Enum FortniteGame.EPollActorsInVolumeTypes
enum class EPollActorsInVolumeTypes : uint8_t
{
	DesignerPlacedOnly             = 0,
	PlayerBuiltOnly                = 1,
	All                            = 2,
	EPollActorsInVolumeTypes_MAX   = 3
};


// Enum FortniteGame.EMissionReplyTypes
enum class EMissionReplyTypes : uint8_t
{
	Handled                        = 0,
	NotHandled                     = 1,
	EMissionReplyTypes_MAX         = 2
};


// Enum FortniteGame.ETimerOverrideSetting
enum class ETimerOverrideSetting : uint8_t
{
	DefaultBehavior                = 0,
	ForceShow                      = 1,
	ForceHide                      = 2,
	ETimerOverrideSetting_MAX      = 3
};


// Enum FortniteGame.EMusicChannel
enum class EMusicChannel : uint8_t
{
	A                              = 0,
	B                              = 1,
	Stinger                        = 2,
	Max_None                       = 3,
	EMusicChannel_MAX              = 4
};


// Enum FortniteGame.EMusicFadeStyles
enum class EMusicFadeStyles : uint8_t
{
	CrossFade                      = 0,
	FadeOutThenIn                  = 1,
	Max_None                       = 2,
	EMusicFadeStyles_MAX           = 3
};


// Enum FortniteGame.EFortAreaFlag
enum class EFortAreaFlag : uint8_t
{
	Default                        = 0,
	Obstacle                       = 1,
	Smashable                      = 2,
	Unwalkable                     = 3,
	Interactable                   = 4,
	EFortAreaFlag_MAX              = 5
};


// Enum FortniteGame.EFortNavLinkPattern
enum class EFortNavLinkPattern : uint8_t
{
	Floor                          = 0,
	Stairs                         = 1,
	Roof                           = 2,
	Manual                         = 3,
	EFortNavLinkPattern_MAX        = 4
};


// Enum FortniteGame.EFortNamedNavmesh
enum class EFortNamedNavmesh : uint8_t
{
	Husk                           = 0,
	Smasher                        = 1,
	MAX                            = 2
};


// Enum FortniteGame.EPathUndermineEvent
enum class EPathUndermineEvent : uint8_t
{
	Predicted                      = 0,
	Started                        = 1,
	Finished                       = 2,
	EPathUndermineEvent_MAX        = 3
};


// Enum FortniteGame.EPathObstacleAction
enum class EPathObstacleAction : uint8_t
{
	Melee                          = 0,
	Ignore                         = 1,
	AbortMoveAsFailed              = 2,
	FinishMoveAsSucceeded          = 3,
	EPathObstacleAction_MAX        = 4
};


// Enum FortniteGame.EWardAffectType
enum class EWardAffectType : uint8_t
{
	AffectsBothStartAndEndPoints   = 0,
	AffectsOnlyStartPoints         = 1,
	AffectsOnlyEndPoints           = 2,
	EWardAffectType_MAX            = 3
};


// Enum FortniteGame.EFortControlRecoveryBehavior
enum class EFortControlRecoveryBehavior : uint8_t
{
	DefaultControl                 = 0,
	LimitedControl                 = 1,
	ChainControl                   = 2,
	EFortControlRecoveryBehavior_MAX = 3
};


// Enum FortniteGame.EFortPawnPushSize
enum class EFortPawnPushSize : uint8_t
{
	FFPS_Normal                    = 0,
	FPPS_Player                    = 1,
	FPPS_Large                     = 2,
	FPPS_SuperLarge                = 3,
	EFortPawnPushSize_MAX          = 4
};


// Enum FortniteGame.EFortAnnouncerTeamVocalChords
enum class EFortAnnouncerTeamVocalChords : uint8_t
{
	Team1                          = 0,
	Team2                          = 1,
	Max_None                       = 2,
	EFortAnnouncerTeamVocalChords_MAX = 3
};


// Enum FortniteGame.EFortIsFinalXpUpdate
enum class EFortIsFinalXpUpdate : uint8_t
{
	Uninitialized                  = 0,
	NotFinal                       = 1,
	Final                          = 2,
	EFortIsFinalXpUpdate_MAX       = 3
};


// Enum FortniteGame.EFortRewardType
enum class EFortRewardType : uint8_t
{
	Default                        = 0,
	Missed                         = 1,
	Max_None                       = 2,
	EFortRewardType_MAX            = 3
};


// Enum FortniteGame.EFortRewardActivityType
enum class EFortRewardActivityType : uint8_t
{
	General                        = 0,
	MissionPrimary                 = 1,
	MissionSecondary               = 2,
	AccountLevelUp                 = 3,
	Max_None                       = 4,
	EFortRewardActivityType_MAX    = 5
};


// Enum FortniteGame.EStatCategory
enum class EStatCategory : uint8_t
{
	Combat                         = 0,
	Building                       = 1,
	Utility                        = 2,
	Max_None                       = 3,
	EStatCategory_MAX              = 4
};


// Enum FortniteGame.EFortReplicatedStat
enum class EFortReplicatedStat : uint8_t
{
	MonsterKills                   = 0,
	MonsterDamagePoints            = 1,
	PlayerKills                    = 2,
	WoodGathered                   = 3,
	StoneGathered                  = 4,
	MetalGathered                  = 5,
	Deaths                         = 6,
	BuildingsBuilt                 = 7,
	BuildingsBuilt_Wood            = 8,
	BuildingsBuilt_Stone           = 9,
	BuildingsBuilt_Metal           = 10,
	BuildingsUpgraded_Wood2        = 11,
	BuildingsUpgraded_Wood3        = 12,
	BuildingsUpgraded_Stone2       = 13,
	BuildingsUpgraded_Stone3       = 14,
	BuildingsUpgraded_Metal2       = 15,
	BuildingsUpgraded_Metal3       = 16,
	BuildingsDestroyed             = 17,
	Repair_Wood                    = 18,
	Repair_Stone                   = 19,
	Repair_Metal                   = 20,
	FlagsCaptured                  = 21,
	FlagsReturned                  = 22,
	ContainersLooted               = 23,
	CraftingPoints                 = 24,
	TrapPlacementPoints            = 25,
	TrapActivationPoints           = 26,
	TotalScore                     = 27,
	OldTotalScore                  = 28,
	CombatScore                    = 29,
	BuildingScore                  = 30,
	UtilityScore                   = 31,
	BadgesScore                    = 32,
	None                           = 33,
	MAX                            = 34
};


// Enum FortniteGame.EFortReplenishmentType
enum class EFortReplenishmentType : uint8_t
{
	Restricted                     = 0,
	ClampMin                       = 1,
	Add                            = 2,
	Ability                        = 3,
	EFortReplenishmentType_MAX     = 4
};


// Enum FortniteGame.EFortPickupTossState
enum class EFortPickupTossState : uint8_t
{
	NotTossed                      = 0,
	InProgress                     = 1,
	AtRest                         = 2,
	EFortPickupTossState_MAX       = 3
};


// Enum FortniteGame.EFortCardinalDirection
enum class EFortCardinalDirection : uint8_t
{
	North                          = 0,
	East                           = 1,
	South                          = 2,
	West                           = 3,
	EFortCardinalDirection_MAX     = 4
};


// Enum FortniteGame.EFortPickerToDisplay
enum class EFortPickerToDisplay : uint8_t
{
	TrapPicker                     = 0,
	WeaponPicker                   = 1,
	SocialPicker                   = 2,
	ChatPicker                     = 3,
	NotePicker                     = 4,
	EmotePicker                    = 5,
	EFortPickerToDisplay_MAX       = 6
};


// Enum FortniteGame.EFortInputActionGroup
enum class EFortInputActionGroup : uint8_t
{
	AllModes                       = 0,
	Combat                         = 1,
	Building                       = 2,
	Edit                           = 3,
	Death                          = 4,
	Cinematic                      = 5,
	EFortInputActionGroup_MAX      = 6
};


// Enum FortniteGame.EFortInputActionType
enum class EFortInputActionType : uint8_t
{
	Press                          = 0,
	Click                          = 1,
	Hold                           = 2,
	Release                        = 3,
	EFortInputActionType_MAX       = 4
};


// Enum FortniteGame.EFortPawnStasisMode
enum class EFortPawnStasisMode : uint8_t
{
	None                           = 0,
	NoMovement                     = 1,
	NoMovementOrTurning            = 2,
	EFortPawnStasisMode_MAX        = 3
};


// Enum FortniteGame.ETrustedPlatformType
enum class ETrustedPlatformType : uint8_t
{
	Unknown                        = 0,
	Desktop                        = 1,
	PS4                            = 2,
	XboxOne                        = 3,
	ETrustedPlatformType_MAX       = 4
};


// Enum FortniteGame.EDeathCause
enum class EDeathCause : uint8_t
{
	OutsideSafeZone                = 0,
	FallDamage                     = 1,
	Pistol                         = 2,
	Shotgun                        = 3,
	Rifle                          = 4,
	SMG                            = 5,
	Sniper                         = 6,
	Melee                          = 7,
	Grenade                        = 8,
	GrenadeLauncher                = 9,
	RocketLauncher                 = 10,
	Trap                           = 11,
	DBNOTimeout                    = 12,
	Banhammer                      = 13,
	RemovedFromGame                = 14,
	Unspecified                    = 15,
	EDeathCause_MAX                = 16
};


// Enum FortniteGame.EFortPointsFromNavGraphGoalPathDistanceFilterOperator
enum class EFortPointsFromNavGraphGoalPathDistanceFilterOperator : uint8_t
{
	AllGoalsInRange                = 0,
	AnyGoalInRange                 = 1,
	EFortPointsFromNavGraphGoalPathDistanceFilterOperator_MAX = 2
};


// Enum FortniteGame.EFortTestGoalActorDot
enum class EFortTestGoalActorDot : uint8_t
{
	Dot3D                          = 0,
	Dot2D                          = 1,
	EFortTestGoalActorDot_MAX      = 2
};


// Enum FortniteGame.EDistanceMode
enum class EDistanceMode : uint8_t
{
	DistItemToContext              = 0,
	DistItemGoalActorToContext     = 1,
	DistItemToItemGoalActor        = 2,
	EDistanceMode_MAX              = 3
};


// Enum FortniteGame.ECountAIAssignedToType
enum class ECountAIAssignedToType : uint8_t
{
	Goal                           = 0,
	Actor                          = 1,
	Assignment                     = 2,
	ECountAIAssignedToType_MAX     = 3
};


// Enum FortniteGame.ETwoPointSolverRotationA
enum class ETwoPointSolverRotationA : uint8_t
{
	PointAToQuerier                = 0,
	QuerierToPointA                = 1,
	PointAToQuerierWithRandomOffset = 2,
	QuerierToPointAWithRandomOffset = 3,
	Custom                         = 4,
	ETwoPointSolverRotationA_MAX   = 5
};


// Enum FortniteGame.EFortQuestRewardType
enum class EFortQuestRewardType : uint8_t
{
	BasicRewards                   = 0,
	BasicPlusSingleChoice          = 1,
	EFortQuestRewardType_MAX       = 2
};


// Enum FortniteGame.EFortQuestType
enum class EFortQuestType : uint8_t
{
	Task                           = 0,
	Optional                       = 1,
	DailyQuest                     = 2,
	TransientQuest                 = 3,
	SurvivorQuest                  = 4,
	Achievement                    = 5,
	Onboarding                     = 6,
	StreamBroadcaster              = 7,
	StreamViewer                   = 8,
	StreamSubscriber               = 9,
	Athena                         = 10,
	AthenaDailyQuest               = 11,
	AthenaEvent                    = 12,
	AthenaBattlePassQuest          = 13,
	All                            = 14,
	EFortQuestType_MAX             = 15
};


// Enum FortniteGame.EFortQuestObjectiveItemEvent
enum class EFortQuestObjectiveItemEvent : uint8_t
{
	Craft                          = 0,
	Collect                        = 1,
	Acquire                        = 2,
	Consume                        = 3,
	OpenCardPack                   = 4,
	PurchaseCardPack               = 5,
	Convert                        = 6,
	Upgrade                        = 7,
	UpgradeRarity                  = 8,
	QuestComplete                  = 9,
	AssignWorker                   = 10,
	LevelUpCollectionBook          = 11,
	HasItem                        = 12,
	SlotInCollection               = 13,
	HasCompletedQuest              = 14,
	HasAssignedWorker              = 15,
	HasUpgraded                    = 16,
	HasConverted                   = 17,
	HasUpgradedRarity              = 18,
	HasLeveledUpCollectionBook     = 19,
	Max_None                       = 20,
	EFortQuestObjectiveItemEvent_MAX = 21
};


// Enum FortniteGame.EFortQuestObjectiveStatEvent
enum class EFortQuestObjectiveStatEvent : uint8_t
{
	Kill                           = 0,
	TeamKill                       = 1,
	KillContribution               = 2,
	Build                          = 3,
	BuildingEdit                   = 4,
	BuildingRepair                 = 5,
	BuildingUpgrade                = 6,
	Complete                       = 7,
	Craft                          = 8,
	Collect                        = 9,
	Win                            = 10,
	Interact                       = 11,
	Destroy                        = 12,
	Ability                        = 13,
	WaveComplete                   = 14,
	Custom                         = 15,
	Client                         = 16,
	AthenaRank                     = 17,
	AthenaOutlive                  = 18,
	RevivePlayer                   = 19,
	NumGameplayEvents              = 20,
	Acquire                        = 21,
	Consume                        = 22,
	OpenCardPack                   = 23,
	PurchaseCardPack               = 24,
	Convert                        = 25,
	Upgrade                        = 26,
	UpgradeRarity                  = 27,
	QuestComplete                  = 28,
	AssignWorker                   = 29,
	CollectExpedition              = 30,
	CollectSuccessfulExpedition    = 31,
	LevelUpCollectionBook          = 32,
	HasItem                        = 33,
	SlotInCollection               = 34,
	HasCompletedQuest              = 35,
	HasAssignedWorker              = 36,
	HasUpgraded                    = 37,
	HasConverted                   = 38,
	HasUpgradedRarity              = 39,
	HasLeveledUpCollectionBook     = 40,
	Max_None                       = 41,
	EFortQuestObjectiveStatEvent_MAX = 42
};


// Enum FortniteGame.EFortQuestState
enum class EFortQuestState : uint8_t
{
	Inactive                       = 0,
	Active                         = 1,
	Completed                      = 2,
	Claimed                        = 3,
	EFortQuestState_MAX            = 4
};


// Enum FortniteGame.EFortQuickBars
enum class EFortQuickBars : uint8_t
{
	Primary                        = 0,
	Secondary                      = 1,
	Max_None                       = 2,
	EFortQuickBars_MAX             = 3
};


// Enum FortniteGame.ERegisteredPlayerUnregistrationStatus
enum class ERegisteredPlayerUnregistrationStatus : uint8_t
{
	Registered                     = 0,
	UnregistrationStarting         = 1,
	UnregistrationWaitingForInitialLock = 2,
	UnregistrationWaitingForFinalSave = 3,
	UnregistrationWaitingForProfileUnlock = 4,
	UnregistrationComplete         = 5,
	ERegisteredPlayerUnregistrationStatus_MAX = 6
};


// Enum FortniteGame.ESpectatorCameraType
enum class ESpectatorCameraType : uint8_t
{
	Chase                          = 0,
	Drone                          = 1,
	MAX                            = 2
};


// Enum FortniteGame.EFocusMethod
enum class EFocusMethod : uint8_t
{
	NoFocus                        = 0,
	AutoFocus                      = 1,
	ManualFocus                    = 2,
	EFocusMethod_MAX               = 3
};


// Enum FortniteGame.EFortSafeZoneState
enum class EFortSafeZoneState : uint8_t
{
	None                           = 0,
	Starting                       = 1,
	Holding                        = 2,
	Shrinking                      = 3,
	EFortSafeZoneState_MAX         = 4
};


// Enum FortniteGame.EFortUIScoreType
enum class EFortUIScoreType : uint8_t
{
	Combat                         = 0,
	Building                       = 1,
	Utility                        = 2,
	Badges                         = 3,
	Bonus                          = 4,
	Total                          = 5,
	Max_None                       = 6,
	EFortUIScoreType_MAX           = 7
};


// Enum FortniteGame.EFortScriptedActionEnvironment
enum class EFortScriptedActionEnvironment : uint8_t
{
	FrontEnd                       = 0,
	GameServer                     = 1,
	GameClient                     = 2,
	Max_None                       = 3,
	EFortScriptedActionEnvironment_MAX = 4
};


// Enum FortniteGame.EFortScriptedActionSource
enum class EFortScriptedActionSource : uint8_t
{
	Quest                          = 0,
	Token                          = 1,
	Manual                         = 2,
	Max_None                       = 3,
	EFortScriptedActionSource_MAX  = 4
};


// Enum FortniteGame.EFortSessionHelperJoinState
enum class EFortSessionHelperJoinState : uint8_t
{
	NotJoining                     = 0,
	RequestingReservation          = 1,
	FailedReservation              = 2,
	WaitingOnGame                  = 3,
	AttemptingJoin                 = 4,
	JoiningSession                 = 5,
	FailedJoin                     = 6,
	CanceledJoin                   = 7,
	EFortSessionHelperJoinState_MAX = 8
};


// Enum FortniteGame.EFortSocialItemPresenceStatus
enum class EFortSocialItemPresenceStatus : uint8_t
{
	Offline                        = 0,
	InGame                         = 1,
	Away                           = 2,
	Unknown                        = 3,
	EFortSocialItemPresenceStatus_MAX = 4
};


// Enum FortniteGame.EFortSocialItemType
enum class EFortSocialItemType : uint8_t
{
	Header                         = 0,
	Friend                         = 1,
	PartyInvite                    = 2,
	RecentPlayer                   = 3,
	Max                            = 4
};


// Enum FortniteGame.EFortEventConditionType
enum class EFortEventConditionType : uint8_t
{
	EFEC_StatCompare               = 0,
	EFEC_CanCraft                  = 1,
	EFEC_MAX                       = 2
};


// Enum FortniteGame.EFortCompare
enum class EFortCompare : uint8_t
{
	EFC_LessThan                   = 0,
	EFC_LessThanOrEqual            = 1,
	EFC_GreaterThan                = 2,
	EFC_GreaterThanOrEqual         = 3,
	EFC_Equals                     = 4,
	EFC_MAX                        = 5
};


// Enum FortniteGame.EFortEventRepeat
enum class EFortEventRepeat : uint8_t
{
	EFER_Inactive                  = 0,
	EFER_Always                    = 1,
	EFER_OncePerPlayer             = 2,
	EFER_OncePerCampaign           = 3,
	EFER_OncePerMap                = 4,
	EFER_MAX                       = 5
};


// Enum FortniteGame.EFortAutoTestState
enum class EFortAutoTestState : uint8_t
{
	InitialLoad                    = 0,
	Login                          = 1,
	FrontendLoad                   = 2,
	FrontendPvELoad                = 3,
	FrontendPvETest                = 4,
	PvEMatchmaking                 = 5,
	ZoneLoad                       = 6,
	ZoneTest                       = 7,
	Finished                       = 8,
	MAX                            = 9
};


// Enum FortniteGame.EFortTheaterType
enum class EFortTheaterType : uint8_t
{
	Standard                       = 0,
	Elder                          = 1,
	PvP                            = 2,
	PvP2                           = 3,
	Tutorial                       = 4,
	TutorialGate                   = 5,
	Test                           = 6,
	Max_None                       = 7,
	EFortTheaterType_MAX           = 8
};


// Enum FortniteGame.EFortTheaterMapTileType
enum class EFortTheaterMapTileType : uint8_t
{
	Normal                         = 0,
	CriticalMission                = 1,
	AlwaysActive                   = 2,
	Outpost                        = 3,
	NonMission                     = 4,
	PvPFOB                         = 5,
	EFortTheaterMapTileType_MAX    = 6
};


// Enum FortniteGame.EFortMissionQuestValidityResult
enum class EFortMissionQuestValidityResult : uint8_t
{
	Invalid                        = 0,
	InvalidNotPlayable             = 1,
	ValidLinked                    = 2,
	ValidObjectiveCondition        = 3,
	ValidFallback                  = 4,
	EFortMissionQuestValidityResult_MAX = 5
};


// Enum FortniteGame.ECollectionSelectionMethod
enum class ECollectionSelectionMethod : uint8_t
{
	TierAsIndex                    = 0,
	TierAsIndexOverflowToLastValid = 1,
	Modulo                         = 2,
	Random                         = 3,
	None                           = 4,
	ECollectionSelectionMethod_MAX = 5
};


// Enum FortniteGame.ETrackVerticality
enum class ETrackVerticality : uint8_t
{
	Floor                          = 0,
	Ramp                           = 1,
	GradualRamp                    = 2,
	Max_None                       = 3,
	ETrackVerticality_MAX          = 4
};


// Enum FortniteGame.ETrackIncline
enum class ETrackIncline : uint8_t
{
	NoNeighbor                     = 0,
	Flat                           = 1,
	Up                             = 2,
	Down                           = 3,
	GradualUp                      = 4,
	GradualDown                    = 5,
	Max_None                       = 6,
	ETrackIncline_MAX              = 7
};


// Enum FortniteGame.ETrackPieceType
enum class ETrackPieceType : uint8_t
{
	None                           = 0,
	Straight                       = 1,
	Turn                           = 2,
	TShape                         = 3,
	Cross                          = 4,
	Max_None                       = 5,
	ETrackPieceType_MAX            = 6
};


// Enum FortniteGame.ETrackDirection
enum class ETrackDirection : uint8_t
{
	YNegative                      = 0,
	XPositive                      = 1,
	YPositive                      = 2,
	XNegative                      = 3,
	Max_None                       = 4,
	ETrackDirection_MAX            = 5
};


// Enum FortniteGame.EFortGliderType
enum class EFortGliderType : uint8_t
{
	Glider                         = 0,
	Umbrella                       = 1,
	EFortGliderType_MAX            = 2
};


// Enum FortniteGame.EFortMissionAlertCategory
enum class EFortMissionAlertCategory : uint8_t
{
	General                        = 0,
	Storm                          = 1,
	Horde                          = 2,
	StormLow                       = 3,
	Halloween                      = 4,
	MiniBoss                       = 5,
	Survival3Day                   = 6,
	Survival7Day                   = 7,
	Total                          = 8,
	EFortMissionAlertCategory_MAX  = 9
};


// Enum FortniteGame.EItemTileViewDisplayType
enum class EItemTileViewDisplayType : uint8_t
{
	World                          = 0,
	Outpost                        = 1,
	Account                        = 2,
	DeployableBase                 = 3,
	Max                            = 4
};


// Enum FortniteGame.EOutpostBuildings
enum class EOutpostBuildings : uint8_t
{
	StormShield                    = 0,
	CraftingTable                  = 1,
	Fabricator                     = 2,
	HarvestingOptimizer            = 3,
	StorageVault                   = 4,
	POST                           = 5,
	EOutpostBuildings_MAX          = 6
};


// Enum FortniteGame.EFortClientAnnouncementQueueType
enum class EFortClientAnnouncementQueueType : uint8_t
{
	Toasts                         = 0,
	Stickies                       = 1,
	Max                            = 2
};


// Enum FortniteGame.EFortNotificationQueueType
enum class EFortNotificationQueueType : uint8_t
{
	Toasts                         = 0,
	Stickies                       = 1,
	Messages                       = 2,
	Max                            = 3
};


// Enum FortniteGame.EFortDialogResult
enum class EFortDialogResult : uint8_t
{
	Confirmed                      = 0,
	Declined                       = 1,
	Ignored                        = 2,
	Killed                         = 3,
	TimedOut                       = 4,
	Unknown                        = 5,
	EFortDialogResult_MAX          = 6
};


// Enum FortniteGame.EFortBangType
enum class EFortBangType : uint8_t
{
	Invalid                        = 0,
	Custom                         = 1,
	PlayTab                        = 2,
	HeroesTab                      = 3,
	VaultTab                       = 4,
	StoreTab                       = 5,
	FriendsButton                  = 6,
	PartyInviteButton              = 7,
	SubGameAccessChanged           = 8,
	DailyRewardsButton             = 9,
	QuestsButton                   = 10,
	CompletedExpeditions           = 11,
	MainMenu                       = 12,
	VaultSchematics                = 13,
	VaultLeadSurvivors             = 14,
	VaultSurvivors                 = 15,
	VaultHeroes                    = 16,
	VaultDefenders                 = 17,
	VaultResources                 = 18,
	VaultMelee                     = 19,
	VaultRanged                    = 20,
	VaultConsumables               = 21,
	VaultIngredients               = 22,
	VaultTraps                     = 23,
	CosmeticsTab                   = 24,
	CosmeticsOutfit                = 25,
	CosmeticGlider                 = 26,
	CosmeticPickaxe                = 27,
	CosmeticDance                  = 28,
	PlayerBanners                  = 29,
	EFortBangType_MAX              = 30
};


// Enum FortniteGame.EFortEventNameType
enum class EFortEventNameType : uint8_t
{
	Mission                        = 0,
	Client                         = 1,
	EFortEventNameType_MAX         = 2
};


// Enum FortniteGame.EFortCraftFailCause
enum class EFortCraftFailCause : uint8_t
{
	Unknown                        = 0,
	NotEnoughResources             = 1,
	InventoryFull                  = 2,
	InsufficientTeamLevel          = 3,
	CraftingQueueFull              = 4,
	CurrentlyLocked                = 5,
	OverflowSchematic              = 6,
	EFortCraftFailCause_MAX        = 7
};


// Enum FortniteGame.EKeepContainerType
enum class EKeepContainerType : uint8_t
{
	Base                           = 0,
	Storeroom                      = 1,
	FirstAid                       = 2,
	Armory                         = 3,
	Workshop                       = 4,
	AmmoStash                      = 5,
	Max                            = 6
};


// Enum FortniteGame.EFortIndicatorState
enum class EFortIndicatorState : uint8_t
{
	Hidden                         = 0,
	OnlyFriendsVisible             = 1,
	Visible                        = 2,
	EFortIndicatorState_MAX        = 3
};


// Enum FortniteGame.EReadyCheckState
enum class EReadyCheckState : uint8_t
{
	CheckStarted                   = 0,
	Ready                          = 1,
	NotReady                       = 2,
	EReadyCheckState_MAX           = 3
};


// Enum FortniteGame.ERichPresenceStateChange
enum class ERichPresenceStateChange : uint8_t
{
	AutoUpdate                     = 0,
	Idle                           = 1,
	Active                         = 2,
	Busy                           = 3,
	NotBusy                        = 4,
	ERichPresenceStateChange_MAX   = 5
};


// Enum FortniteGame.EFortTeamAffiliation
enum class EFortTeamAffiliation : uint8_t
{
	Friendly                       = 0,
	Neutral                        = 1,
	Hostile                        = 2,
	EFortTeamAffiliation_MAX       = 3
};


// Enum FortniteGame.EFortAIUtility
enum class EFortAIUtility : uint8_t
{
	KillPlayersMelee               = 0,
	KillPlayersRanged              = 1,
	KillPlayersArtillery           = 2,
	DestroyBuildingsMelee          = 3,
	DestroyBuildingsRanged         = 4,
	DestroyBuildingsArtillery      = 5,
	DestroyTraps                   = 6,
	Tank                           = 7,
	Infiltrate                     = 8,
	Mob                            = 9,
	Support                        = 10,
	Kiting                         = 11,
	AreaOfDenial                   = 12,
	DisableTraps                   = 13,
	Dormant                        = 14,
	Assassin                       = 15,
	MAX                            = 16
};


// Enum FortniteGame.EFortTileEdgeType
enum class EFortTileEdgeType : uint8_t
{
	Undefined                      = 0,
	Outer_1                        = 1,
	Transition_2                   = 2,
	Inner_3                        = 3,
	Border_4                       = 4,
	BorderTransitionSingle_5       = 5,
	BorderTransitionDouble_6       = 6,
	MAX                            = 7
};


// Enum FortniteGame.EFortRequestedGameplayAction
enum class EFortRequestedGameplayAction : uint8_t
{
	ContinuePlaying                = 0,
	StartPlaying                   = 1,
	StopPlaying                    = 2,
	EnterZone                      = 3,
	LeaveZone                      = 4,
	ReturnToMainMenu               = 5,
	QuitGame                       = 6,
	Invalid                        = 7,
	EFortRequestedGameplayAction_MAX = 8
};


// Enum FortniteGame.EFortGameplayState
enum class EFortGameplayState : uint8_t
{
	NormalGameplay                 = 0,
	WaitingToStart                 = 1,
	EndOfZone                      = 2,
	EnteringZone                   = 3,
	LeavingZone                    = 4,
	Invalid                        = 5,
	EFortGameplayState_MAX         = 6
};


// Enum FortniteGame.EFortMovementUrgency
enum class EFortMovementUrgency : uint8_t
{
	None                           = 0,
	Low                            = 1,
	Medium                         = 2,
	High                           = 3,
	NumLevels                      = 4,
	EFortMovementUrgency_MAX       = 5
};


// Enum FortniteGame.EFortMovementStyle
enum class EFortMovementStyle : uint8_t
{
	Running                        = 0,
	Walking                        = 1,
	Charging                       = 2,
	Sprinting                      = 3,
	Hoverboard                     = 4,
	EFortMovementStyle_MAX         = 5
};


// Enum FortniteGame.EFortWeaponReloadType
enum class EFortWeaponReloadType : uint8_t
{
	ReloadWholeClip                = 0,
	ReloadIndividualBullets        = 1,
	ReloadBasedOnAmmoCostPerFire   = 2,
	ReloadBasedOnCartridgePerFire  = 3,
	EFortWeaponReloadType_MAX      = 4
};


// Enum FortniteGame.EFortWeaponTriggerType
enum class EFortWeaponTriggerType : uint8_t
{
	OnPress                        = 0,
	Automatic                      = 1,
	OnRelease                      = 2,
	OnPressAndRelease              = 3,
	EFortWeaponTriggerType_MAX     = 4
};


// Enum FortniteGame.EFortJumpStaminaCost
enum class EFortJumpStaminaCost : uint8_t
{
	None                           = 0,
	Trigger                        = 1,
	SprintTrigger                  = 2,
	SprintAir                      = 3,
	EFortJumpStaminaCost_MAX       = 4
};


// Enum FortniteGame.EFortDayPhasePrio
enum class EFortDayPhasePrio : uint8_t
{
	Default                        = 0,
	DailySummary                   = 1,
	EFortDayPhasePrio_MAX          = 2
};


// Enum FortniteGame.EFortCustomBodyType
enum class EFortCustomBodyType : uint8_t
{
	Small                          = 0,
	Medium                         = 1,
	MediumAndSmall                 = 2,
	Large                          = 3,
	LargeAndSmall                  = 4,
	LargeAndMedium                 = 5,
	All                            = 6,
	Deprecated                     = 7,
	EFortCustomBodyType_MAX        = 8
};


// Enum FortniteGame.EFortDisplayGender
enum class EFortDisplayGender : uint8_t
{
	Unknown                        = 0,
	Male                           = 1,
	Female                         = 2,
	NumTypes                       = 3,
	EFortDisplayGender_MAX         = 4
};


// Enum FortniteGame.EFortCustomGender
enum class EFortCustomGender : uint8_t
{
	Invalid                        = 0,
	Male                           = 1,
	Female                         = 2,
	Both                           = 3,
	EFortCustomGender_MAX          = 4
};


// Enum FortniteGame.EFortCompletionResult
enum class EFortCompletionResult : uint8_t
{
	Win                            = 0,
	Loss                           = 1,
	Draw                           = 2,
	Undefined                      = 3,
	EFortCompletionResult_MAX      = 4
};


// Enum FortniteGame.EFortPvPGameResult
enum class EFortPvPGameResult : uint8_t
{
	Win                            = 0,
	Loss                           = 1,
	Draw                           = 2,
	EFortPvPGameResult_MAX         = 3
};


// Enum FortniteGame.EFortItemTier
enum class EFortItemTier : uint8_t
{
	No_Tier                        = 0,
	I                              = 1,
	II                             = 2,
	III                            = 3,
	IV                             = 4,
	V                              = 5,
	VI                             = 6,
	VII                            = 7,
	VIII                           = 8,
	IX                             = 9,
	X                              = 10,
	NumItemTierValues              = 11,
	EFortItemTier_MAX              = 12
};


// Enum FortniteGame.EFortQuality
enum class EFortQuality : uint8_t
{
	Common                         = 0,
	Uncommon                       = 1,
	Rare                           = 2,
	NumQualityValues               = 3,
	EFortQuality_MAX               = 4
};


// Enum FortniteGame.EFortRarity
enum class EFortRarity : uint8_t
{
	Handmade                       = 0,
	Ordinary                       = 1,
	Sturdy                         = 2,
	Quality                        = 3,
	Fine                           = 4,
	Elegant                        = 5,
	Masterwork                     = 6,
	Epic                           = 7,
	Badass                         = 8,
	Legendary                      = 9,
	NumRarityValues                = 10,
	EFortRarity_MAX                = 11
};


// Enum FortniteGame.EFortTargetSelectionFilter
enum class EFortTargetSelectionFilter : uint8_t
{
	Damageable                     = 0,
	Everything                     = 1,
	Pawns                          = 2,
	Buildings                      = 3,
	Walls                          = 4,
	Traps                          = 5,
	Players                        = 6,
	AIPawns                        = 7,
	Instigator                     = 8,
	WeakSpots                      = 9,
	World                          = 10,
	Max                            = 11
};


// Enum FortniteGame.EFortTargetSelectionTestType
enum class EFortTargetSelectionTestType : uint8_t
{
	Overlap                        = 0,
	Swept                          = 1,
	Ballistic                      = 2,
	EFortTargetSelectionTestType_MAX = 3
};


// Enum FortniteGame.EFortTargetSelectionShape
enum class EFortTargetSelectionShape : uint8_t
{
	Sphere                         = 0,
	Cone                           = 1,
	Box                            = 2,
	Capsule                        = 3,
	Line                           = 4,
	Custom                         = 5,
	EFortTargetSelectionShape_MAX  = 6
};


// Enum FortniteGame.EFortBrushSize
enum class EFortBrushSize : uint8_t
{
	VeryVerySmall                  = 0,
	VerySmall                      = 1,
	Small                          = 2,
	Medium                         = 3,
	Large                          = 4,
	VeryLarge                      = 5,
	EFortBrushSize_MAX             = 6
};


// Enum FortniteGame.EInventoryContentSortType
enum class EInventoryContentSortType : uint8_t
{
	ByName                         = 0,
	ByRating                       = 1,
	ByLevel                        = 2,
	ByCategory                     = 3,
	ByRarity                       = 4,
	ByLocation                     = 5,
	ByPersonality                  = 6,
	ByBonus                        = 7,
	BySubtype                      = 8,
	EInventoryContentSortType_MAX  = 9
};


// Enum FortniteGame.EFortFrontendInventoryFilter
enum class EFortFrontendInventoryFilter : uint8_t
{
	Schematics                     = 0,
	WorldItems                     = 1,
	WorldItemsInGame               = 2,
	WorldItemsStorage              = 3,
	WorldItemsTransfer             = 4,
	ConsumablesAndAccountResources = 5,
	Heroes                         = 6,
	Defenders                      = 7,
	Survivors                      = 8,
	Invisible                      = 9,
	Max_None                       = 10,
	EFortFrontendInventoryFilter_MAX = 11
};


// Enum FortniteGame.EFortInventoryFilter
enum class EFortInventoryFilter : uint8_t
{
	WeaponMelee                    = 0,
	WeaponRanged                   = 1,
	Ammo                           = 2,
	Traps                          = 3,
	Consumables                    = 4,
	Ingredients                    = 5,
	Gadget                         = 6,
	Decorations                    = 7,
	Badges                         = 8,
	Heroes                         = 9,
	LeadSurvivors                  = 10,
	Survivors                      = 11,
	Defenders                      = 12,
	Resources                      = 13,
	ConversionControl              = 14,
	AthenaCosmetics                = 15,
	Invisible                      = 16,
	Max_None                       = 17,
	EFortInventoryFilter_MAX       = 18
};


// Enum FortniteGame.EFortItemCategoryOrdinal
enum class EFortItemCategoryOrdinal : uint8_t
{
	Primary                        = 0,
	Secondary                      = 1,
	Tertiary                       = 2,
	EFortItemCategoryOrdinal_MAX   = 3
};


// Enum FortniteGame.ESubGameMatchmakingStatus
enum class ESubGameMatchmakingStatus : uint8_t
{
	Disabled                       = 0,
	Enabled                        = 1,
	ESubGameMatchmakingStatus_MAX  = 2
};


// Enum FortniteGame.ESubGameAccessStatus
enum class ESubGameAccessStatus : uint8_t
{
	Disabled                       = 0,
	LimitedAccess                  = 1,
	OpenAccess                     = 2,
	ESubGameAccessStatus_MAX       = 3
};


// Enum FortniteGame.ESubGame
enum class ESubGame : uint8_t
{
	Campaign                       = 0,
	Athena                         = 1,
	Invalid                        = 2,
	ESubGame_MAX                   = 3
};


// Enum FortniteGame.EFortUIFriendNotificationType
enum class EFortUIFriendNotificationType : uint8_t
{
	Default                        = 0,
	FriendRequest                  = 1,
	PartyInvite                    = 2,
	EFortUIFriendNotificationType_MAX = 3
};


// Enum FortniteGame.EFortNotificationPriority
enum class EFortNotificationPriority : uint8_t
{
	Friend                         = 0,
	BoostedXP                      = 1,
	TwitchHigh                     = 2,
	GeneralSendNotification        = 3,
	TwitchLow                      = 4,
	Max                            = 5
};


// Enum FortniteGame.EFortNotificationType
enum class EFortNotificationType : uint8_t
{
	Default                        = 0,
	Power                          = 1,
	HealthWarning                  = 2,
	Max                            = 3
};


// Enum FortniteGame.EFortContextualReticleTypes
enum class EFortContextualReticleTypes : uint8_t
{
	FCR_GenericFailure             = 0,
	FCR_Upgrade                    = 1,
	FCR_Repair                     = 2,
	FCR_Locked                     = 3,
	FCR_Placement                  = 4,
	FCR_Edit                       = 5,
	FCR_NoTarget                   = 6,
	FCR_InProgress                 = 7,
	FCR_None                       = 8,
	FCR_MAX                        = 9
};


// Enum FortniteGame.EFortUserCloudRequestResult
enum class EFortUserCloudRequestResult : uint8_t
{
	Success                        = 0,
	Failure_CloudStorageDisabled   = 1,
	Failure_CloudStorageError      = 2,
	Failure_FileNotFoundInUserFileList = 3,
	Failure_SavingNotAllowedForSpecifiedUser = 4,
	EFortUserCloudRequestResult_MAX = 5
};


// Enum FortniteGame.EFortUserCloudRequestType
enum class EFortUserCloudRequestType : uint8_t
{
	LoadCloudFile                  = 0,
	SaveCloudFile                  = 1,
	EFortUserCloudRequestType_MAX  = 2
};


// Enum FortniteGame.EFortVisibilityBehavior
enum class EFortVisibilityBehavior : uint8_t
{
	Proximity                      = 0,
	OnceSeenAlwaysSeen             = 1,
	AlwaysSeen                     = 2,
	Invalid                        = 3,
	EFortVisibilityBehavior_MAX    = 4
};


// Enum FortniteGame.EFortReloadMontageSection
enum class EFortReloadMontageSection : uint8_t
{
	Intro                          = 0,
	Loop                           = 1,
	Outro                          = 2,
	EFortReloadMontageSection_MAX  = 3
};


// Enum FortniteGame.EFortDisplayTier
enum class EFortDisplayTier : uint8_t
{
	Invalid                        = 0,
	Handmade                       = 1,
	Copper                         = 2,
	Silver                         = 3,
	Malachite                      = 4,
	Obsidian                       = 5,
	Brightcore                     = 6,
	Spectrolite                    = 7,
	Shadowshard                    = 8,
	Sunbeam                        = 9,
	Moonglow                       = 10,
	EFortDisplayTier_MAX           = 11
};


// Enum FortniteGame.EFortWorldManagerState
enum class EFortWorldManagerState : uint8_t
{
	WMS_Created                    = 0,
	WMS_QueryingWorld              = 1,
	WMS_WorldQueryComplete         = 2,
	WMS_CreatingNewWorld           = 3,
	WMS_LoadingExistingWorld       = 4,
	WMS_Running                    = 5,
	WMS_Failed                     = 6,
	WMS_MAX                        = 7
};


// Enum FortniteGame.EFortLevelStreamingState
enum class EFortLevelStreamingState : uint8_t
{
	LSS_Unloaded                   = 0,
	LSS_Loaded                     = 1,
	LSS_UnconditionalFoundationsUpdated = 2,
	LSS_AllFoundationsUpdated      = 3,
	LSS_NewActorsCreatedButNotUpdated = 4,
	LSS_AllUpdated                 = 5,
	LSS_Ready                      = 6,
	LSS_MAX                        = 7
};


// Enum FortniteGame.EFortQueuedActionUserStatus
enum class EFortQueuedActionUserStatus : uint8_t
{
	Succeeded                      = 0,
	Failed                         = 1,
	WaitingForCloudRequest         = 2,
	WaitingForProfileSave          = 3,
	EFortQueuedActionUserStatus_MAX = 4
};


// Enum FortniteGame.EFortWorldRecordState
enum class EFortWorldRecordState : uint8_t
{
	StartProcessing                = 0,
	WaitingForResponse             = 1,
	RetrievingTheaterInformation   = 2,
	RetrievingZoneInformation      = 3,
	LoadingWorldRecord             = 4,
	LoadingZoneRecord              = 5,
	SavingZoneRecord               = 6,
	SavingPlayerProfiles           = 7,
	SavingPlayerDeployableBases    = 8,
	Succeeded                      = 9,
	Failed                         = 10,
	Max_None                       = 11,
	EFortWorldRecordState_MAX      = 12
};


// Enum FortniteGame.EFortWorldRecordAction
enum class EFortWorldRecordAction : uint8_t
{
	LoadWorldOnly                  = 0,
	SaveWorldOnly                  = 1,
	SaveZoneAndWorld               = 2,
	LoadZoneAndWorld               = 3,
	SaveDeployableBasesAndWorld    = 4,
	Max_None                       = 5,
	EFortWorldRecordAction_MAX     = 6
};


// Enum FortniteGame.EDeployableBaseUseType
enum class EDeployableBaseUseType : uint8_t
{
	Neighborhood                   = 0,
	PvECombat                      = 1,
	EDeployableBaseUseType_MAX     = 2
};


// Enum FortniteGame.EFortZoneType
enum class EFortZoneType : uint8_t
{
	PVE                            = 0,
	PVP                            = 1,
	Keep                           = 2,
	SingleZone                     = 3,
	Max_None                       = 4,
	EFortZoneType_MAX              = 5
};


// Enum FortniteGame.EFrontEndCamera
enum class EFrontEndCamera : uint8_t
{
	Invalid                        = 0,
	HomeBase                       = 1,
	MissionControl                 = 2,
	Store                          = 3,
	Vault                          = 4,
	SkillTrees                     = 5,
	Heroes                         = 6,
	Login                          = 7,
	TutorialPhaseOne               = 8,
	TutorialPhaseTwo               = 9,
	TutorialPhaseThree             = 10,
	HeroSelect                     = 11,
	Party                          = 12,
	WorldMap                       = 13,
	Home                           = 14,
	StoreItemInspect               = 15,
	Cosmetics                      = 16,
	SmallCosmetics                 = 17,
	SpecialEvent                   = 18,
	EFrontEndCamera_MAX            = 19
};


// Enum FortniteGame.EFortEncounterSpawnLimitType
enum class EFortEncounterSpawnLimitType : uint8_t
{
	NoLimit                        = 0,
	NumPawnsLimit                  = 1,
	SpawnPointLimit                = 2,
	UserDefined                    = 3,
	MAX                            = 4
};


// Enum FortniteGame.EFortEncounterUtilitiesMode
enum class EFortEncounterUtilitiesMode : uint8_t
{
	LockedOnly                     = 0,
	LockedAndFree                  = 1,
	EFortEncounterUtilitiesMode_MAX = 2
};


// Enum FortniteGame.EFortEncounterSpawnLocationPlacementMode
enum class EFortEncounterSpawnLocationPlacementMode : uint8_t
{
	Directional                    = 0,
	Ring                           = 1,
	Volume                         = 2,
	Custom                         = 3,
	Max_None                       = 4,
	EFortEncounterSpawnLocationPlacementMode_MAX = 5
};


// Enum FortniteGame.EFortEncounterPacingMode
enum class EFortEncounterPacingMode : uint8_t
{
	SpawnPointsPercentageCurve     = 0,
	IntensityCurve                 = 1,
	Burst                          = 2,
	EFortEncounterPacingMode_MAX   = 3
};


// Enum FortniteGame.EFortMissionAudibility
enum class EFortMissionAudibility : uint8_t
{
	UseVisibility                  = 0,
	Audible                        = 1,
	Inaudible                      = 2,
	EFortMissionAudibility_MAX     = 3
};


// Enum FortniteGame.EFortMissionType
enum class EFortMissionType : uint8_t
{
	Primary                        = 0,
	Secondary                      = 1,
	Max_None                       = 2,
	EFortMissionType_MAX           = 3
};


// Enum FortniteGame.EFortObjectiveRequirement
enum class EFortObjectiveRequirement : uint8_t
{
	Optional                       = 0,
	Required                       = 1,
	RequiredButCanFail             = 2,
	EFortObjectiveRequirement_MAX  = 3
};


// Enum FortniteGame.EFortMissionStatus
enum class EFortMissionStatus : uint8_t
{
	Created                        = 0,
	InProgress                     = 1,
	Succeeded                      = 2,
	Failed                         = 3,
	NeutralCompletion              = 4,
	Quit                           = 5,
	Max_None                       = 6,
	EFortMissionStatus_MAX         = 7
};


// Enum FortniteGame.EMissionGenerationCategory
enum class EMissionGenerationCategory : uint8_t
{
	Primary                        = 0,
	Secondary                      = 1,
	Tertiary                       = 2,
	Survivor                       = 3,
	Max_None                       = 4,
	EMissionGenerationCategory_MAX = 5
};


// Enum FortniteGame.EStatRecordingPeriod
enum class EStatRecordingPeriod : uint8_t
{
	Minute                         = 0,
	Life                           = 1,
	Map                            = 2,
	Campaign                       = 3,
	Persistent                     = 4,
	Max                            = 5
};


// Enum FortniteGame.EStatMod
enum class EStatMod : uint8_t
{
	Delta                          = 0,
	Set                            = 1,
	Maximum                        = 2,
	EStatMod_MAX                   = 3
};


// Enum FortniteGame.EFortStrategicBuildingLevelCriteriaDisplayRepresentation
enum class EFortStrategicBuildingLevelCriteriaDisplayRepresentation : uint8_t
{
	Integer                        = 0,
	Float                          = 1,
	EFortStrategicBuildingLevelCriteriaDisplayRepresentation_MAX = 2
};


// Enum FortniteGame.EFortStrategicBuildingCategory
enum class EFortStrategicBuildingCategory : uint8_t
{
	Defensive                      = 0,
	Offensive                      = 1,
	Utility                        = 2,
	EFortStrategicBuildingCategory_MAX = 3
};


// Enum FortniteGame.EFortThreatDeactivationType
enum class EFortThreatDeactivationType : uint8_t
{
	Off                            = 0,
	Dormant                        = 1,
	EFortThreatDeactivationType_MAX = 2
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct FortniteGame.AIHotSpotSlotConfig
// 0x001C
struct FAIHotSpotSlotConfig
{
	struct FVector                                     Offset;                                                   // 0x0000(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FVector                                     Direction;                                                // 0x000C(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
	EFortHotSpotSlot                                   SlotType;                                                 // 0x0018(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0019(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortItemQuantityPair
// 0x0030
struct FFortItemQuantityPair
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortItemQuantityPair.ItemDefinition
	int                                                Quantity;                                                 // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.AthenaCosmeticMaterialOverride
// 0x0038
struct FAthenaCosmeticMaterialOverride
{
	struct FName                                       ComponentName;                                            // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                MaterialOverrideIndex;                                    // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                ProgressionThreshold;                                     // 0x000C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0010(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.AthenaCosmeticMaterialOverride.OverrideMaterial
};

// ScriptStruct FortniteGame.FortMultiSizeBrush
// 0x02D0
struct FFortMultiSizeBrush
{
	struct FSlateBrush                                 Brush_XXS;                                                // 0x0000(0x0078) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSlateBrush                                 Brush_XS;                                                 // 0x0078(0x0078) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSlateBrush                                 Brush_S;                                                  // 0x00F0(0x0078) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSlateBrush                                 Brush_M;                                                  // 0x0168(0x0078) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSlateBrush                                 Brush_L;                                                  // 0x01E0(0x0078) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSlateBrush                                 Brush_XL;                                                 // 0x0258(0x0078) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.FortAlterationSlotStatus
// 0x0010
struct FFortAlterationSlotStatus
{
	class UFortAlterationItemDefinition*               Alteration;                                               // 0x0000(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, SaveGame, IsPlainOldData)
	int                                                MinRequiredLevel;                                         // 0x0008(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.GameplayTagMessage
// 0x0038
struct FGameplayTagMessage
{
	struct FGameplayTagContainer                       Tags;                                                     // 0x0000(0x0020) (Edit)
	struct FText                                       Text;                                                     // 0x0020(0x0018) (Edit)
};

// ScriptStruct FortniteGame.AthenaLevelInfo
// 0x0024
struct FAthenaLevelInfo
{
	int                                                AccountLevel;                                             // 0x0000(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Level;                                                    // 0x0004(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaxLevel;                                                 // 0x0008(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                LevelXp;                                                  // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                LevelXpForLevel;                                          // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                BookLevel;                                                // 0x0014(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                BookMaxLevel;                                             // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                BookLevelXp;                                              // 0x001C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                BookLevelXpForLevel;                                      // 0x0020(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.AthenaMatchStats
// 0x0074
struct FAthenaMatchStats
{
	int                                                SecondsAlive;                                             // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Kills;                                                    // 0x0004(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Downs;                                                    // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Assists;                                                  // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Revives;                                                  // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                DamageDealtToHostiles;                                    // 0x0014(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                DamageDealtToFriends;                                     // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                DamageDealtToStructures;                                  // 0x001C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                DamageTaken;                                              // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                RangedShots;                                              // 0x0024(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                RangedHit;                                                // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Accuracy;                                                 // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                TravelDistanceGround;                                     // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                GatheredWood;                                             // 0x0034(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                GatheredStone;                                            // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                GatheredMetal;                                            // 0x003C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaterialsGathered;                                        // 0x0040(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                UsedWood;                                                 // 0x0044(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                UsedStone;                                                // 0x0048(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                UsedMetal;                                                // 0x004C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaterialsUsed;                                            // 0x0050(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                NormalDamageToHostiles;                                   // 0x0054(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                NormalDamageToFriends;                                    // 0x0058(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                CriticalDamageToHostiles;                                 // 0x005C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                CriticalDamageToFriends;                                  // 0x0060(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                NormalHitsToHostiles;                                     // 0x0064(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                NormalHitsToFriends;                                      // 0x0068(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                CriticalHitsToHostiles;                                   // 0x006C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                CriticalHitsToFriends;                                    // 0x0070(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.AthenaMatchTeamStats
// 0x0008
struct FAthenaMatchTeamStats
{
	int                                                Place;                                                    // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                TotalPlayers;                                             // 0x0004(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.AthenaMatchXpMultiplierGroup
// 0x0008
struct FAthenaMatchXpMultiplierGroup
{
	EAthenaMatchXpMultiplierSource                     Source;                                                   // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                Amount;                                                   // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.AthenaAwardGroup
// 0x0028
struct FAthenaAwardGroup
{
	ERewardSource                                      RewardSource;                                             // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<struct FMcpLootEntry>                       Items;                                                    // 0x0008(0x0010) (ZeroConstructor)
	int                                                Score;                                                    // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              SeasonXp;                                                 // 0x001C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BookXp;                                                   // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.AthenaRewardResult
// 0x0030
struct FAthenaRewardResult
{
	int                                                LevelsGained;                                             // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BookLevelsGained;                                         // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                TotalSeasonXpGained;                                      // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                TotalBookXpGained;                                        // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	TArray<struct FAthenaMatchXpMultiplierGroup>       XpMultipliers;                                            // 0x0010(0x0010) (ZeroConstructor)
	TArray<struct FAthenaAwardGroup>                   Rewards;                                                  // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.AthenaMatchXpReward
// 0x0020
struct FAthenaMatchXpReward
{
	struct FText                                       Text;                                                     // 0x0000(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	int                                                Amount;                                                   // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.AthenaMatchLootReward
// 0x0018
struct FAthenaMatchLootReward
{
	struct FString                                     TemplateId;                                               // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int                                                Amount;                                                   // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.AthenaRewardItemReference
// 0x0040
struct FAthenaRewardItemReference
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.AthenaRewardItemReference.ItemDefinition
	struct FString                                     TemplateId;                                               // 0x0028(0x0010) (Edit, ZeroConstructor)
	int                                                Quantity;                                                 // 0x0038(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               IsChaseReward;                                            // 0x003C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x003D(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.AthenaRewardScheduleLevel
// 0x0010
struct FAthenaRewardScheduleLevel
{
	TArray<struct FAthenaRewardItemReference>          Rewards;                                                  // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct FortniteGame.AthenaRewardSchedule
// 0x0010
struct FAthenaRewardSchedule
{
	TArray<struct FAthenaRewardScheduleLevel>          Levels;                                                   // 0x0000(0x0010) (Edit, EditFixedSize, ZeroConstructor)
};

// ScriptStruct FortniteGame.AthenaSeasonBannerLevel
// 0x0050
struct FAthenaSeasonBannerLevel
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.AthenaSeasonBannerLevel.SurroundImage
	unsigned char                                      UnknownData01[0x28];                                      // 0x0028(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.AthenaSeasonBannerLevel.BannerMaterial
};

// ScriptStruct FortniteGame.AthenaSeasonBannerLevelSchedule
// 0x0010
struct FAthenaSeasonBannerLevelSchedule
{
	TArray<struct FAthenaSeasonBannerLevel>            Levels;                                                   // 0x0000(0x0010) (Edit, EditFixedSize, ZeroConstructor)
};

// ScriptStruct FortniteGame.AthenaWeaponAlterationRule
// 0x0058
struct FAthenaWeaponAlterationRule
{
	struct FGameplayTagQuery                           MatchCriteria;                                            // 0x0000(0x0048) (Edit)
	TArray<class UFortAlterationItemDefinition*>       Alterations;                                              // 0x0048(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortAttributeInitializationKey
// 0x0010
struct FFortAttributeInitializationKey
{
	struct FName                                       AttributeInitCategory;                                    // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       AttributeInitSubCategory;                                 // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortDamageSource
// 0x0010
struct FFortDamageSource
{
	TWeakObjectPtr<class AController>                  InstigatorController;                                     // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	TWeakObjectPtr<class AActor>                       DamageCauser;                                             // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.BuildingActorHotSpotDirection
// 0x0020
struct FBuildingActorHotSpotDirection
{
	class UAIHotSpotConfig*                            HotSpotConfig;                                            // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Offset;                                                   // 0x0008(0x000C) (Edit, IsPlainOldData)
	unsigned char                                      bMirrorX : 1;                                             // 0x0014(0x0001) (Edit)
	unsigned char                                      bMirrorY : 1;                                             // 0x0014(0x0001) (Edit)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
	EFortHotSpotDirection                              Direction;                                                // 0x0018(0x0001) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	EHotspotTypeConfigMode                             TypeConfigUsage;                                          // 0x0019(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x001A(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.MeshSet
// 0x0060
struct FMeshSet
{
	float                                              Weight;                                                   // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TEnumAsByte<EFortResourceType>                     ResourceType;                                             // 0x0004(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      bDoNotBlockBuildings : 1;                                 // 0x0005(0x0001) (Edit, BlueprintVisible, DisableEditOnInstance)
	unsigned char                                      bDestroyOnPlayerBuildingPlacement : 1;                    // 0x0005(0x0001) (Edit, BlueprintVisible, DisableEditOnInstance)
	unsigned char                                      bNeedsDamageOverlay : 1;                                  // 0x0005(0x0001) (Edit, BlueprintVisible, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0006(0x0002) MISSED OFFSET
	class UStaticMesh*                                 BaseMesh;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UParticleSystem*                             BreakEffect;                                              // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UParticleSystem*                             DeathParticles;                                           // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       DeathParticleSocketName;                                  // 0x0020(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class USoundBase*                                  DeathSound;                                               // 0x0028(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UParticleSystem*                             ConstructedEffect;                                        // 0x0030(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UStaticMesh*                                 SearchedMesh;                                             // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FCurveTableRowHandle                        SearchSpeed;                                              // 0x0040(0x0010) (Edit, BlueprintVisible, DisableEditOnInstance)
	float                                              LootNoiseRange;                                           // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FVector                                     LootSpawnLocation;                                        // 0x0054(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.TierMeshSets
// 0x0018
struct FTierMeshSets
{
	int                                                Tier;                                                     // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	TArray<struct FMeshSet>                            MeshSets;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortBounceData
// 0x0030
struct FFortBounceData
{
	float                                              StartTime;                                                // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              BounceValue;                                              // 0x0004(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Radius;                                                   // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	struct FLinearColor                                DeformationVector;                                        // 0x000C(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, EditConst, IsPlainOldData)
	struct FLinearColor                                DeformationCenter;                                        // 0x001C(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, EditConst, IsPlainOldData)
	TEnumAsByte<EFortBounceType>                       BounceType;                                               // 0x002C(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x002D(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.BuildingNavObstacle
// 0x0020
struct FBuildingNavObstacle
{
	struct FBox                                        LocalBounds;                                              // 0x0000(0x001C) (Edit, IsPlainOldData)
	EBuildingNavObstacleType                           ObstacleType;                                             // 0x001C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x001D(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.EditorOnlyBuildingInstanceMaterialParameters
// 0x0030
struct FEditorOnlyBuildingInstanceMaterialParameters
{
	TArray<struct FScalarParameterValue>               ScalarParams;                                             // 0x0000(0x0010) (Edit, ZeroConstructor, DisableEditOnTemplate)
	TArray<struct FVectorParameterValue>               VectorParams;                                             // 0x0010(0x0010) (Edit, ZeroConstructor, DisableEditOnTemplate)
	TArray<struct FTextureParameterValue>              TextureParams;                                            // 0x0020(0x0010) (Edit, ZeroConstructor, DisableEditOnTemplate)
};

// ScriptStruct FortniteGame.ChosenQuotaInfo
// 0x0010
struct FChosenQuotaInfo
{
	int                                                LootTier;                                                 // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FName                                       LootTierKey;                                              // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.RandomDayphaseFX
// 0x0038
struct FRandomDayphaseFX
{
	class UParticleSystem*                             ParticleSystem;                                           // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	TArray<class UParticleSystem*>                     AltParticleSystems;                                       // 0x0008(0x0010) (Edit, ZeroConstructor)
	TArray<TEnumAsByte<EFortDayPhase>>                 RequiredDayphases;                                        // 0x0018(0x0010) (Edit, ZeroConstructor)
	float                                              ChanceToSpawnFX;                                          // 0x0028(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bRandomSelectionAlreadyHappened;                          // 0x002C(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x002D(0x0003) MISSED OFFSET
	class UParticleSystemComponent*                    SpawnedComponent;                                         // 0x0030(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortConnectionData
// 0x0030
struct FFortConnectionData
{
	class ABuildingSMActor*                            ConnectedActor;                                           // 0x0000(0x0008) (ZeroConstructor, SaveGame, IsPlainOldData)
	struct FGuid                                       ConnectedActorGuid;                                       // 0x0008(0x0010) (SaveGame, IsPlainOldData)
	struct FName                                       MySocketName;                                             // 0x0018(0x0008) (ZeroConstructor, SaveGame, IsPlainOldData)
	struct FName                                       TheirSocketName;                                          // 0x0020(0x0008) (ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortConnectivityComponentData
// 0x0018
struct FFortConnectivityComponentData
{
	TArray<struct FFortConnectionData>                 Connections;                                              // 0x0000(0x0010) (ZeroConstructor, SaveGame)
	bool                                               bIsPowered;                                               // 0x0010(0x0001) (ZeroConstructor, SaveGame, IsPlainOldData)
	bool                                               bIsProvidingPower;                                        // 0x0011(0x0001) (ZeroConstructor, SaveGame, IsPlainOldData)
	bool                                               bAllowConnections;                                        // 0x0012(0x0001) (ZeroConstructor, SaveGame, IsPlainOldData)
	bool                                               bAllowsPowerToPassThrough;                                // 0x0013(0x0001) (ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortDeliveryInfoRequirementsFilter
// 0x0098
struct FFortDeliveryInfoRequirementsFilter
{
	struct FGameplayTagRequirements                    SourceTagRequirements;                                    // 0x0000(0x0040) (Edit, DisableEditOnInstance)
	struct FGameplayTagRequirements                    TargetTagRequirements;                                    // 0x0040(0x0040) (Edit, DisableEditOnInstance)
	TEnumAsByte<EFortTeamAffiliation>                  ApplicableTeamAffiliation;                                // 0x0080(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0081(0x0003) MISSED OFFSET
	unsigned char                                      bConsiderTeamAffiliationToInstigator : 1;                 // 0x0084(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0085(0x0003) MISSED OFFSET
	TEnumAsByte<EFortTeam>                             ApplicableTeam;                                           // 0x0088(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0089(0x0003) MISSED OFFSET
	unsigned char                                      bConsiderTeam : 1;                                        // 0x008C(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      bApplyToPlayerPawns : 1;                                  // 0x008C(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      bApplyToAIPawns : 1;                                      // 0x008C(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      bApplyToBuildingActors : 1;                               // 0x008C(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData03[0x3];                                       // 0x008D(0x0003) MISSED OFFSET
	EFortDeliveryInfoBuildingActorSpecification        BuildingActorSpecification;                               // 0x0090(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData04[0x3];                                       // 0x0091(0x0003) MISSED OFFSET
	unsigned char                                      bApplyToGlobalEnvironmentAbilityActor : 1;                // 0x0094(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData05[0x3];                                       // 0x0095(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.GameplayEffectApplicationInfo
// 0x0030
struct FGameplayEffectApplicationInfo
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.GameplayEffectApplicationInfo.GameplayEffect
	float                                              Level;                                                    // 0x0028(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.ProximityBasedGEDeliveryInfo
// 0x00B0
struct FProximityBasedGEDeliveryInfo
{
	struct FFortDeliveryInfoRequirementsFilter         DeliveryRequirements;                                     // 0x0000(0x0098) (Edit, DisableEditOnInstance)
	TArray<struct FGameplayEffectApplicationInfo>      EffectsToApply;                                           // 0x0098(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	EFortProximityBasedGEApplicationType               ProximityApplicationType;                                 // 0x00A8(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00A9(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAbilitySetDeliveryInfo
// 0x00A8
struct FFortAbilitySetDeliveryInfo
{
	struct FFortDeliveryInfoRequirementsFilter         DeliveryRequirements;                                     // 0x0000(0x0098) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0098(0x0010) UNKNOWN PROPERTY: ArrayProperty FortniteGame.FortAbilitySetDeliveryInfo.AbilitySets
};

// ScriptStruct FortniteGame.FortAbilitySetHandle
// 0x0028
struct FFortAbilitySetHandle
{
	TWeakObjectPtr<class UAbilitySystemComponent>      TargetAbilitySystemComponent;                             // 0x0000(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	TArray<struct FGameplayAbilitySpecHandle>          GrantedAbilityHandles;                                    // 0x0008(0x0010) (ZeroConstructor, Transient)
	TArray<struct FActiveGameplayEffectHandle>         AppliedEffectHandles;                                     // 0x0018(0x0010) (ZeroConstructor, Transient)
};

// ScriptStruct FortniteGame.BuildingGameplayActorAbilityDeliveryBucket
// 0x0090
struct FBuildingGameplayActorAbilityDeliveryBucket
{
	struct FGameplayTag                                Tag;                                                      // 0x0000(0x0008) (Edit, DisableEditOnInstance)
	TArray<struct FProximityBasedGEDeliveryInfo>       ProximityBasedEffectBuckets;                              // 0x0008(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FFortAbilitySetDeliveryInfo>         PawnPersistentAbilitySetBuckets;                          // 0x0018(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FFortAbilitySetHandle>               PersistentlyAppliedAbilitySets;                           // 0x0028(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      bEnabled : 1;                                             // 0x0038(0x0001) (Transient)
	unsigned char                                      bEnabledByDefault : 1;                                    // 0x0038(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      bHasGEsToApplyOnTouch : 1;                                // 0x0038(0x0001)
	unsigned char                                      bHasGEsToApplyOnPulseTimer : 1;                           // 0x0038(0x0001)
	unsigned char                                      bHasPersistentEffects : 1;                                // 0x0038(0x0001)
	unsigned char                                      UnknownData00[0x57];                                      // 0x0039(0x0057) MISSED OFFSET
};

// ScriptStruct FortniteGame.BuildingGameplayActorAbilityDeliveryInfo
// 0x0080
struct FBuildingGameplayActorAbilityDeliveryInfo
{
	TArray<struct FBuildingGameplayActorAbilityDeliveryBucket> DeliveryBuckets;                                          // 0x0000(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	float                                              ProximityPulseInterval;                                   // 0x0010(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      bHasGEsToApplyOnTouch : 1;                                // 0x0014(0x0001)
	unsigned char                                      bHasGEsToApplyOnPulseTimer : 1;                           // 0x0014(0x0001)
	unsigned char                                      bHasPersistentEffects : 1;                                // 0x0014(0x0001)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
	class ABuildingGameplayActor*                      OwningActor;                                              // 0x0018(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TArray<class AActor*>                              DeferredTouchActorsToProcess;                             // 0x0020(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x50];                                      // 0x0030(0x0050) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortSearchBounceData
// 0x0010
struct FFortSearchBounceData
{
	struct FVector                                     BounceNormal;                                             // 0x0000(0x000C) (IsPlainOldData)
	uint32_t                                           SearchAnimationCount;                                     // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.ConnectivityCube
// 0x00C0
struct FConnectivityCube
{
	unsigned char                                      UnknownData00[0xC0];                                      // 0x0000(0x00C0) MISSED OFFSET
};

// ScriptStruct FortniteGame.AuxiliaryEditTileMeshData
// 0x0020
struct FAuxiliaryEditTileMeshData
{
	class UStaticMesh*                                 TileMesh;                                                 // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UTexture2D*                                  TileTexture;                                              // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FRotator                                    RelativeRot;                                              // 0x0010(0x000C) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.EditModeState
// 0x0010
struct FEditModeState
{
	class UClass*                                      EditClass;                                                // 0x0000(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                RotationIterations;                                       // 0x0008(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bMirrored;                                                // 0x000C(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bCurrentlyValid;                                          // 0x000D(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x000E(0x0002) MISSED OFFSET
};

// ScriptStruct FortniteGame.TileCompInterpData
// 0x0018
struct FTileCompInterpData
{
	struct FVector                                     InitialTranslation;                                       // 0x0000(0x000C) (Transient, IsPlainOldData)
	struct FVector                                     DesiredTranslation;                                       // 0x000C(0x000C) (Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.FOBCoreChoice
// 0x002C (0x0038 - 0x000C)
struct FFOBCoreChoice : public FFastArraySerializerItem
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	class UFortFOBCoreDecoItemDefinition*              FOBCoreDef;                                               // 0x0010(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	EFOBFileHeaderStatus                               FileHeaderStatus;                                         // 0x0018(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
	struct FString                                     CoreFilename;                                             // 0x0020(0x0010) (ZeroConstructor, Transient, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	class UFortBuildingInstructions*                   BuildingInstructions;                                     // 0x0030(0x0008) (ZeroConstructor, Transient, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
};

// ScriptStruct FortniteGame.FOBCoreChoiceArray
// 0x0010 (0x00C0 - 0x00B0)
struct FFOBCoreChoiceArray : public FFastArraySerializer
{
	TArray<struct FFOBCoreChoice>                      Items;                                                    // 0x00B0(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortMapData
// 0x0048
struct FFortMapData
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortMapData.BuildingWorld
	struct FGameplayTagContainer                       BuildingLevelTags;                                        // 0x0028(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.BuildingActorNavArea
// 0x0004
struct FBuildingActorNavArea
{
	int                                                AreaBits;                                                 // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortSpawnSlotData
// 0x0020
struct FFortSpawnSlotData
{
	struct FVector                                     SpawnSlotLocation;                                        // 0x0000(0x000C) (IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	class AFortAIPawn*                                 OccupyingAI;                                              // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortRiftSlotStatus>                   SlotStatus;                                               // 0x0018(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortTargetFilter
// 0x0020
struct FFortTargetFilter
{
	TEnumAsByte<EFortTargetSelectionFilter>            ActorTypeFilter;                                          // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	class UClass*                                      ActorClassFilter;                                         // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExcludeInstigator;                                       // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExcludeRequester;                                        // 0x0011(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExcludeAllAttachedToInstigator;                          // 0x0012(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExcludeAllAttachedToRequester;                           // 0x0013(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExcludePawnFriends;                                      // 0x0014(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExcludeFriendlyAI;                                       // 0x0015(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExcludePawnEnemies;                                      // 0x0016(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExcludeNonPawnFriends;                                   // 0x0017(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExcludeNonPawnEnemies;                                   // 0x0018(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExcludeDBNOPawns;                                        // 0x0019(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExcludeWithoutNavigationCorridor;                        // 0x001A(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExcludeNonPlayerBuiltPieces;                             // 0x001B(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExcludePlayerBuiltPieces;                                // 0x001C(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExcludeNonBGABuildings;                                  // 0x001D(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bExcludeNonBlockingHits;                                  // 0x001E(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bTraceComplexCollision;                                   // 0x001F(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortCosmeticModification
// 0x0B20
struct FFortCosmeticModification
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortCosmeticModification.CosmeticMaterial
	unsigned char                                      UnknownData01[0x28];                                      // 0x0028(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortCosmeticModification.AmbientParticleSystem
	unsigned char                                      UnknownData02[0x28];                                      // 0x0050(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortCosmeticModification.MuzzleParticleSystem
	unsigned char                                      UnknownData03[0x28];                                      // 0x0078(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortCosmeticModification.ReloadParticleSystem
	unsigned char                                      UnknownData04[0x28];                                      // 0x00A0(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortCosmeticModification.BeamParticleSystem
	unsigned char                                      UnknownData05[0x9D8];                                     // 0x00C8(0x09D8) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortCosmeticModification.ImpactPhysicalSurfaceEffects
	unsigned char                                      UnknownData06[0x28];                                      // 0x0AA0(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.FortCosmeticModification.TracerTemplate
	bool                                               bModifyColor;                                             // 0x0AC8(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData07[0x3];                                       // 0x0AC9(0x0003) MISSED OFFSET
	struct FLinearColor                                ColorAlteration;                                          // 0x0ACC(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	unsigned char                                      UnknownData08[0x4];                                       // 0x0ADC(0x0004) MISSED OFFSET
	struct FName                                       ColorParameterName;                                       // 0x0AE0(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bModifyDecalColour;                                       // 0x0AE8(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData09[0x3];                                       // 0x0AE9(0x0003) MISSED OFFSET
	struct FLinearColor                                DecalColourAlterationStart;                               // 0x0AEC(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FLinearColor                                DecalColourAlterationEnd;                                 // 0x0AFC(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	bool                                               bModifyShellColour;                                       // 0x0B0C(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData10[0x3];                                       // 0x0B0D(0x0003) MISSED OFFSET
	struct FLinearColor                                ShellColourAlteration;                                    // 0x0B10(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct FortniteGame.MOBATurretPrioritySetting
// 0x000C
struct FMOBATurretPrioritySetting
{
	int                                                AIPriority;                                               // 0x0000(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                PlayerPriority;                                           // 0x0004(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                BuildingPriority;                                         // 0x0008(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.ClimbLinkData
// 0x0028
struct FClimbLinkData
{
	unsigned char                                      UnknownData00[0x20];                                      // 0x0000(0x0020) MISSED OFFSET
	uint32_t                                           UniqueLinkId;                                             // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.ColorSwatchPair
// 0x0018
struct FColorSwatchPair
{
	struct FName                                       ColorName;                                                // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                ColorValue;                                               // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct FortniteGame.CustomPartTextureParameter
// 0x0038
struct FCustomPartTextureParameter
{
	int                                                MaterialIndexForTextureParameter;                         // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FName                                       TextureParameterNameForMaterial;                          // 0x0008(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x28];                                      // 0x0010(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.CustomPartTextureParameter.TextureOverride
};

// ScriptStruct FortniteGame.CustomPartMaterialOverrideData
// 0x0030
struct FCustomPartMaterialOverrideData
{
	int                                                MaterialOverrideIndex;                                    // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0004(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.CustomPartMaterialOverrideData.OverrideMaterial
};

// ScriptStruct FortniteGame.CustomPartScalarParameter
// 0x0018
struct FCustomPartScalarParameter
{
	int                                                MaterialIndexForScalarParameter;                          // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FName                                       ScalarParameterNameForMaterial;                           // 0x0008(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              ScalarOverride;                                           // 0x0010(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.CustomPartVectorParameter
// 0x0020
struct FCustomPartVectorParameter
{
	int                                                MaterialIndexForVectorParameter;                          // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FName                                       VectorParameterNameForMaterial;                           // 0x0008(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                VectorOverride;                                           // 0x0010(0x0010) (Edit, IsPlainOldData)
};

// ScriptStruct FortniteGame.GameplayTagAnimationData
// 0x0050
struct FGameplayTagAnimationData
{
	struct FGameplayTagContainer                       GameplayTags;                                             // 0x0000(0x0020) (Edit)
	TEnumAsByte<EFortCustomGender>                     ValidGenders;                                             // 0x0020(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0021(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.GameplayTagAnimationData.AnimMontage
};

// ScriptStruct FortniteGame.GameplayTagAnimations
// 0x0010
struct FGameplayTagAnimations
{
	TArray<struct FGameplayTagAnimationData>           GameplayTagAnimData;                                      // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortCloudSaveRecordInfo
// 0x0018
struct FFortCloudSaveRecordInfo
{
	int                                                RecordIndex;                                              // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                ArchiveNumber;                                            // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FString                                     RecordFilename;                                           // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortCloudSaveInfo
// 0x0018
struct FFortCloudSaveInfo
{
	int                                                SaveCount;                                                // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	TArray<struct FFortCloudSaveRecordInfo>            SavedRecords;                                             // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.DeferredActorData
// 0x0040
struct FDeferredActorData
{
	class ABuildingActor*                              BuildingActor;                                            // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                ActorRecordIndex;                                         // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FTransform                                  BuildingTransform;                                        // 0x0010(0x0030) (IsPlainOldData)
};

// ScriptStruct FortniteGame.ViewOffsetData
// 0x0024
struct FViewOffsetData
{
	struct FVector                                     OffsetHigh;                                               // 0x0000(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     OffsetMid;                                                // 0x000C(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     OffsetLow;                                                // 0x0018(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct FortniteGame.PenetrationAvoidanceFeeler
// 0x0020
struct FPenetrationAvoidanceFeeler
{
	struct FRotator                                    AdjustmentRot;                                            // 0x0000(0x000C) (Edit, IsPlainOldData)
	float                                              WorldWeight;                                              // 0x000C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              PawnWeight;                                               // 0x0010(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              Extent;                                                   // 0x0014(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                TraceInterval;                                            // 0x0018(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                FramesUntilNextTrace;                                     // 0x001C(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortGameplayAbilityBehaviorDistanceData
// 0x0028
struct FFortGameplayAbilityBehaviorDistanceData
{
	struct FGameplayTagContainer                       DistanceDataTag;                                          // 0x0000(0x0020) (Edit)
	float                                              Distance;                                                 // 0x0020(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.AbilityToolSpawnParameters
// 0x0028
struct FAbilityToolSpawnParameters
{
	class UClass*                                      SpawnClass;                                               // 0x0000(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Location;                                                 // 0x0008(0x000C) (BlueprintVisible, IsPlainOldData)
	struct FRotator                                    Rotation;                                                 // 0x0014(0x000C) (BlueprintVisible, IsPlainOldData)
	class ABuildingSMActor*                            AttachedToActor;                                          // 0x0020(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.AbilityKitItem
// 0x0010
struct FAbilityKitItem
{
	class UFortItemDefinition*                         Item;                                                     // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Quantity;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortReplenishmentType>                Replenishment;                                            // 0x000C(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortTooltipValueData
// 0x0070
struct FFortTooltipValueData
{
	struct FText                                       DisplayName;                                              // 0x0000(0x0018) (Edit, BlueprintVisible)
	struct FText                                       FormattedValue;                                           // 0x0018(0x0018) (Edit, BlueprintVisible)
	struct FText                                       ExplanationText;                                          // 0x0030(0x0018) (Edit, BlueprintVisible)
	float                                              Value;                                                    // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	struct FGameplayTagContainer                       StateTags;                                                // 0x0050(0x0020) (Edit, BlueprintVisible)
};

// ScriptStruct FortniteGame.ReplicatedMontagePair
// 0x0028
struct FReplicatedMontagePair
{
	class UAnimMontage*                                Montage1;                                                 // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	class UAnimMontage*                                Montage2;                                                 // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FName                                       Section1;                                                 // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FName                                       Section2;                                                 // 0x0018(0x0008) (ZeroConstructor, IsPlainOldData)
	int8_t                                             RepIndex;                                                 // 0x0020(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.AttributeInfo
// 0x0010
struct FAttributeInfo
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.TokenAttributePair
// 0x0028
struct FTokenAttributePair
{
	struct FGameplayTag                                Token;                                                    // 0x0000(0x0008) (Edit)
	struct FGameplayAttribute                          Attribute;                                                // 0x0008(0x0020) (Edit)
};

// ScriptStruct FortniteGame.FortGameplayEffectModifierDescription
// 0x0040
struct FFortGameplayEffectModifierDescription
{
	struct FGameplayAttribute                          ModAttribute;                                             // 0x0000(0x0020)
	struct FText                                       ModDescription;                                           // 0x0020(0x0018) (BlueprintVisible, BlueprintReadOnly)
	bool                                               bIsBuff;                                                  // 0x0038(0x0001) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortAttributeDisplay>                 MagnitudeFormat;                                          // 0x0039(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFortStatDisplayType                               DisplayType;                                              // 0x003A(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x1];                                       // 0x003B(0x0001) MISSED OFFSET
	float                                              Magnitude;                                                // 0x003C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortGameplayEffectDescription
// 0x0050
struct FFortGameplayEffectDescription
{
	struct FText                                       EffectDisplayName;                                        // 0x0000(0x0018) (BlueprintVisible, BlueprintReadOnly)
	struct FText                                       EffectWrittenDescription;                                 // 0x0018(0x0018) (BlueprintVisible, BlueprintReadOnly)
	TArray<struct FFortGameplayEffectModifierDescription> ModDescriptions;                                          // 0x0030(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FText>                               GrantedTagDescriptions;                                   // 0x0040(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortMoveConfig
// 0x0028
struct FFortMoveConfig
{
	unsigned char                                      UnknownData00[0x18];                                      // 0x0000(0x0018) MISSED OFFSET
	class AActor*                                      FocusTarget;                                              // 0x0018(0x0008) (ZeroConstructor, IsPlainOldData)
	class UClass*                                      PushPawnClassOnBump;                                      // 0x0020(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortCharacterPartMontageInfo
// 0x0010
struct FFortCharacterPartMontageInfo
{
	TEnumAsByte<EFortCustomPartType>                   CharacterPart;                                            // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	class UAnimMontage*                                AnimMontage;                                              // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortGameplayAbilityMontageInfo
// 0x0060
struct FFortGameplayAbilityMontageInfo
{
	class UAnimMontage*                                MontageToPlay;                                            // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AnimPlayRate;                                             // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AnimRootMotionTranslationScale;                           // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EFortGameplayAbilityMontageSectionToPlay           MontageSectionToPlay;                                     // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
	struct FName                                       OverrideSection;                                          // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bPlayRandomSection;                                       // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
	TArray<struct FFortCharacterPartMontageInfo>       CharacterPartMontages;                                    // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	unsigned char                                      UnknownData02[0x28];                                      // 0x0038(0x0028) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAbilityTargetSelection
// 0x0060
struct FFortAbilityTargetSelection
{
	TEnumAsByte<EFortTargetSelectionShape>             Shape;                                                    // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FString                                     CustomShapeComponentName;                                 // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	EFortTargetSelectionTestType                       TestType;                                                 // 0x0018(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFortAbilityTargetingSource                        PrimarySource;                                            // 0x0019(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFortAbilityTargetingSource                        SecondarySource;                                          // 0x001A(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x1];                                       // 0x001B(0x0001) MISSED OFFSET
	float                                              Range;                                                    // 0x001C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector                                     HalfExtents;                                              // 0x0020(0x000C) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	float                                              ConeYawAngle;                                             // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ConePitchAngle;                                           // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ConeMinRadius;                                            // 0x0034(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FFortTargetFilter                           TargetFilter;                                             // 0x0038(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	bool                                               bExcludeObstructedByWorld;                                // 0x0058(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bCreateHitResultWhenNoTargetsFound;                       // 0x0059(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bUseProjectileRotationForDamageZones;                     // 0x005A(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFortAbilityTargetSelectionUsage                   TargetSelectionUsage;                                     // 0x005B(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaxTargets;                                               // 0x005C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortAbilityTargetSelectionList
// 0x0020
struct FFortAbilityTargetSelectionList
{
	TArray<struct FFortAbilityTargetSelection>         List;                                                     // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	unsigned char                                      bStopAtFirstSuccess : 1;                                  // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bKeepCheckingListOnIndestructibleHit : 1;                 // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bUseWeaponRanges : 1;                                     // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      bUseMaxYawAngleToTarget : 1;                              // 0x0010(0x0001)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	float                                              MaxYawAngleToTarget;                                      // 0x0014(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x0018(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortGameplayEffectContainerSpec
// 0x0080
struct FFortGameplayEffectContainerSpec
{
	struct FFortAbilityTargetSelectionList             TargetSelection;                                          // 0x0000(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	TArray<struct FGameplayEffectSpecHandle>           TargetGameplayEffectSpecs;                                // 0x0020(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FGameplayEffectSpecHandle>           OwnerGameplayEffectSpecs;                                 // 0x0030(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FGameplayTagContainer                       ActivationCues;                                           // 0x0040(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FGameplayTagContainer                       ImpactCues;                                               // 0x0060(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.FortGameplayAttributeData
// 0x0010 (0x0020 - 0x0010)
struct FFortGameplayAttributeData : public FGameplayAttributeData
{
	float                                              Minimum;                                                  // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Maximum;                                                  // 0x0014(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bIsClamped;                                               // 0x0018(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bShouldClampBase;                                         // 0x0019(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x001A(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAIAssignmentIdentifier
// 0x0030
struct FFortAIAssignmentIdentifier
{
	EAssignmentType                                    AssignmentType;                                           // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FGameplayTagContainer                       AssignmentGameplayTags;                                   // 0x0008(0x0020) (Edit, BlueprintVisible)
	TEnumAsByte<EFortTeam>                             AssignmentTeam;                                           // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAIGoalInfo
// 0x0018
struct FFortAIGoalInfo
{
	TWeakObjectPtr<class AActor>                       Actor;                                                    // 0x0000(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	struct FVector                                     Location;                                                 // 0x0008(0x000C) (Transient, IsPlainOldData)
	bool                                               bActorAlwaysPerceived;                                    // 0x0014(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAIGoal
// 0x0010 (0x0028 - 0x0018)
struct FFortAIGoal : public FFortAIGoalInfo
{
	TArray<class AFortAIController*>                   ControllersAssignedToGoal;                                // 0x0018(0x0010) (ZeroConstructor, Transient)
};

// ScriptStruct FortniteGame.GoalSelectionQueryInfo
// 0x0028
struct FGoalSelectionQueryInfo
{
	class UEnvQuery*                                   GoalSelectionQuery;                                       // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FGameplayTagContainer                       RequiredGameplayTags;                                     // 0x0008(0x0020) (Edit)
};

// ScriptStruct FortniteGame.AIHotSpotSlotInfo
// 0x0010
struct FAIHotSpotSlotInfo
{
	class AAIHotSpot*                                  HotSpot;                                                  // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnTemplate, EditConst, IsPlainOldData)
	int                                                SlotIndex;                                                // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnTemplate, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.AIHotSpotUseInfo
// 0x0008 (0x0018 - 0x0010)
struct FAIHotSpotUseInfo : public FAIHotSpotSlotInfo
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0010(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.IntensityContribution
// 0x0048
struct FIntensityContribution
{
	TEnumAsByte<EFortCombatFactors>                    CombatFactor;                                             // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFortAIDirectorFactor                              ContributingAIDirectorFactor;                             // 0x0001(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0002(0x0002) MISSED OFFSET
	float                                              MaxContribution;                                          // 0x0004(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bModifyContributionByCompletionPercentage;                // 0x0008(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
	struct FCurveTableRowHandle                        CompletionPercentageInitialMultiplier;                    // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FCurveTableRowHandle                        CompletionPercentageToStartReducingMultiplier;            // 0x0020(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FCurveTableRowHandle                        CompletionPercentageToStopReducingMultiplier;             // 0x0030(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	bool                                               bModifyByNumberOfCriticalEncounterGoals;                  // 0x0040(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0041(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.IntensityData
// 0x0030
struct FIntensityData
{
	TArray<struct FIntensityContribution>              ContributingFactors;                                      // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	float                                              ContributionsTotal;                                       // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	TArray<class UBuildingEditModeMetadata*>           ExceptionEditModes;                                       // 0x0018(0x0010) (Edit, ZeroConstructor)
	float                                              ExceptionEditModeWeight;                                  // 0x0028(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAIEncounterPIDController
// 0x0068
struct FFortAIEncounterPIDController
{
	float                                              ProportionalGain;                                         // 0x0000(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              IntegralGain;                                             // 0x0004(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DerivativeGain;                                           // 0x0008(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5C];                                      // 0x000C(0x005C) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAIEncounterPIDControllerSettings
// 0x0030
struct FFortAIEncounterPIDControllerSettings
{
	struct FCurveTableRowHandle                        ProportionalGain;                                         // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FCurveTableRowHandle                        IntegralGain;                                             // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FCurveTableRowHandle                        DerivativeGain;                                           // 0x0020(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.UtilityContribution
// 0x000C
struct FUtilityContribution
{
	TEnumAsByte<EFortCombatFactors>                    ContributingFactor;                                       // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EFortAIDirectorFactor                              ContributingAIDirectorFactor;                             // 0x0001(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0002(0x0002) MISSED OFFSET
	float                                              MaxContribution;                                          // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortFactorContributionType>           ContributionType;                                         // 0x0008(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.UtilityData
// 0x0040
struct FUtilityData
{
	TArray<struct FUtilityContribution>                ContributingFactors;                                      // 0x0000(0x0010) (Edit, ZeroConstructor)
	float                                              ContributionsTotal;                                       // 0x0010(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	bool                                               bApplyRecentSelectionPenalty;                             // 0x0014(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
	float                                              RecentlySelectedPenaltyPercentage;                        // 0x0018(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              PenaltyFallOffRate;                                       // 0x001C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FString                                     DebugGraphName;                                           // 0x0020(0x0010) (Edit, ZeroConstructor)
	struct FLinearColor                                DebugGraphColor;                                          // 0x0030(0x0010) (Edit, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortPlayerPerformanceEstimateSettings
// 0x0040
struct FFortPlayerPerformanceEstimateSettings
{
	struct FCurveTableRowHandle                        PlayerPerformanceEstimateTransformMin;                    // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FCurveTableRowHandle                        PlayerPerformanceEstimateTransformOrigin;                 // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FCurveTableRowHandle                        PlayerPerformanceEstimateTransformMax;                    // 0x0020(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	float                                              EncounterPlayerPerformanceWeight;                         // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              PreviousWavePlayerPerformanceWeight;                      // 0x0034(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              CampaignPlayerPerformanceWeight;                          // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAIEncounterSpawnGroupCap
// 0x0020
struct FFortAIEncounterSpawnGroupCap
{
	struct FCurveTableRowHandle                        MinSpawnGroupNumberCap;                                   // 0x0000(0x0010) (Edit, DisableEditOnInstance)
	struct FCurveTableRowHandle                        MaxSpawnGroupNumberCap;                                   // 0x0010(0x0010) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortAIEncounterSpawnGroupCapsCategory
// 0x0140
struct FFortAIEncounterSpawnGroupCapsCategory
{
	struct FGameplayTagQuery                           TagQuery;                                                 // 0x0000(0x0048) (Edit, DisableEditOnInstance)
	bool                                               bApplyGroupPopulationCurveToCategoryMax;                  // 0x0048(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
	struct FCurveTableRowHandle                        InitialSpawnGroupAvailabilityDelaySeconds;                // 0x0050(0x0010) (Edit, DisableEditOnInstance)
	struct FCurveTableRowHandle                        SpawnGroupAvailabilityDelaySeconds;                       // 0x0060(0x0010) (Edit, DisableEditOnInstance)
	struct FGameplayTagQuery                           UnlockingTagQuery;                                        // 0x0070(0x0048) (Edit, DisableEditOnInstance)
	TArray<struct FFortAIEncounterSpawnGroupCap>       SpawnGroupCapsPerPlayerCount;                             // 0x00B8(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	float                                              InitialSpawnGroupAvailabilityTime;                        // 0x00C8(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              NumActiveCategorySpawnGroups;                             // 0x00CC(0x0004) (ZeroConstructor, IsPlainOldData)
	TArray<float>                                      SpawnGroupAvailabilityTimes;                              // 0x00D0(0x0010) (ZeroConstructor)
	int                                                NumSpawnGroupAvailable;                                   // 0x00E0(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00E4(0x0004) MISSED OFFSET
	class UObject*                                     CategorySource;                                           // 0x00E8(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x50];                                      // 0x00F0(0x0050) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAIEncounterSpawnGroupCapsProfile
// 0x0030
struct FFortAIEncounterSpawnGroupCapsProfile
{
	struct FGameplayTagContainer                       EncounterTypeTags;                                        // 0x0000(0x0020) (Edit, DisableEditOnInstance)
	TArray<struct FFortAIEncounterSpawnGroupCapsCategory> PopulationCategories;                                     // 0x0020(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortAIEncounterSpawnPointsProfile
// 0x0040
struct FFortAIEncounterSpawnPointsProfile
{
	struct FGameplayTagContainer                       EncounterTypeTags;                                        // 0x0000(0x0020) (Edit, DisableEditOnInstance)
	TArray<struct FCurveTableRowHandle>                MaxSpawnPointsPerPlayerCount;                             // 0x0020(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FCurveTableRowHandle>                MinSpawnPointsPerPlayerCount;                             // 0x0030(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortAIEncounterPawnDifficultyLevelModifier
// 0x0058
struct FFortAIEncounterPawnDifficultyLevelModifier
{
	struct FGameplayTagQuery                           EncounterTagRequirementsQuery;                            // 0x0000(0x0048) (Edit, DisableEditOnInstance)
	struct FCurveTableRowHandle                        DifficultyLevelModifierCurve;                             // 0x0048(0x0010) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortAISpawnGroupUpgradeData
// 0x0060
struct FFortAISpawnGroupUpgradeData
{
	class UClass*                                      SpawnGroupUpgrade;                                        // 0x0000(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UClass*                                      UpgradeProbabilities;                                     // 0x0008(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UClass*                                      SpawnGroupCapsCategories;                                 // 0x0010(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FGameplayTagQuery                           EncounterTagRequirementsQuery;                            // 0x0018(0x0048) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.EncounterEnvironmentQueryInfo
// 0x0028
struct FEncounterEnvironmentQueryInfo
{
	class UEnvQuery*                                   EnvironmentQuery;                                         // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<struct FEnvNamedValue>                      QueryParams;                                              // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0018(0x0008) MISSED OFFSET
	bool                                               bIsDirectional;                                           // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortEncounterPawnNumberCaps
// 0x0018
struct FFortEncounterPawnNumberCaps
{
	bool                                               bApplyPawnNumberCaps;                                     // 0x0000(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<struct FCurveTableRowHandle>                PawnCapsPerPlayerCount;                                   // 0x0008(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortAISpawnGroupUpgradeUIData
// 0x00A8
struct FFortAISpawnGroupUpgradeUIData
{
	bool                                               bAlwaysDisplayHealthBar;                                  // 0x0000(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bOverrideHealthBarColor;                                  // 0x0001(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0002(0x0006) MISSED OFFSET
	struct FSlateBrush                                 UpgradeIcon;                                              // 0x0008(0x0078) (Edit, DisableEditOnInstance)
	struct FLinearColor                                HealthBarColorOverride;                                   // 0x0080(0x0010) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FText                                       UpgradeName;                                              // 0x0090(0x0018) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.PendingSpawnInfo
// 0x0160
struct FPendingSpawnInfo
{
	class UClass*                                      PawnClassToSpawn;                                         // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	class AActor*                                      SpawnPoint;                                               // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FVector                                     SpawnLocation;                                            // 0x0010(0x000C) (IsPlainOldData)
	struct FRotator                                    SpawnRotation;                                            // 0x001C(0x000C) (IsPlainOldData)
	class AActor*                                      SpawnSource;                                              // 0x0028(0x0008) (ZeroConstructor, IsPlainOldData)
	bool                                               bSpawnedFromExternalSpawner;                              // 0x0030(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0031(0x0003) MISSED OFFSET
	int                                                SpawnSetIndex;                                            // 0x0034(0x0004) (ZeroConstructor, IsPlainOldData)
	EFortressAIType                                    AIType;                                                   // 0x0038(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	class AFortPlayerController*                       TargetPlayer;                                             // 0x0040(0x0008) (ZeroConstructor, IsPlainOldData)
	class UFortAIEncounterInfo*                        EncounterInfo;                                            // 0x0048(0x0008) (ZeroConstructor, IsPlainOldData)
	float                                              DifficultyLevel;                                          // 0x0050(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0054(0x0004) MISSED OFFSET
	class UFortAISpawnGroup*                           SpawnGroup;                                               // 0x0058(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FGuid                                       SpawnGroupGuid;                                           // 0x0060(0x0010) (IsPlainOldData)
	int                                                EnemyIndexInSpawnGroup;                                   // 0x0070(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              TimeToSpawn;                                              // 0x0074(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FGuid                                       PendingSpawnInfoGuid;                                     // 0x0078(0x0010) (IsPlainOldData)
	bool                                               bIgnoreCollision;                                         // 0x0088(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bKillBuildingActorsAtSpawnLocation;                       // 0x0089(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x2];                                       // 0x008A(0x0002) MISSED OFFSET
	float                                              EncounterAILifespan;                                      // 0x008C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              ScoreMultiplier;                                          // 0x0090(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bDebugSpawnedAI;                                          // 0x0094(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x3];                                       // 0x0095(0x0003) MISSED OFFSET
	TArray<class UFortAbilitySet*>                     AbilitySetsToGrantOnSpawn;                                // 0x0098(0x0010) (ZeroConstructor)
	TArray<class UFortGameplayModifierItemDefinition*> ModifiersToApplyOnSpawn;                                  // 0x00A8(0x0010) (ZeroConstructor)
	struct FFortAISpawnGroupUpgradeUIData              UpgradeUIData;                                            // 0x00B8(0x00A8)
};

// ScriptStruct FortniteGame.FortPendingStoppedEncounterData
// 0x0010
struct FFortPendingStoppedEncounterData
{
	class UFortAIEncounterInfo*                        Encounter;                                                // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	EFortObjectiveStatus                               ObjectiveStatus;                                          // 0x0008(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bForceDestroyAI;                                          // 0x0009(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bEncounterCompletedSuccessfully;                          // 0x000A(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x000B(0x0005) MISSED OFFSET
};

// ScriptStruct FortniteGame.UtilityTypeFloatPair
// 0x0008
struct FUtilityTypeFloatPair
{
	TEnumAsByte<EFortAIUtility>                        Utility;                                                  // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              Value;                                                    // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.AIDirectorEventData
// 0x0030
struct FAIDirectorEventData
{
	EFortAIDirectorEvent                               Event;                                                    // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FCurveTableRowHandle                        DataMax;                                                  // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FCurveTableRowHandle                        CoolDownRate;                                             // 0x0018(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	EFortAIDirectorEventContribution                   ContributionType;                                         // 0x0028(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFortAIDirectorEventParticipant                    OwnerParticipantType;                                     // 0x0029(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x002A(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAIDirectorFactorContribution
// 0x000C
struct FFortAIDirectorFactorContribution
{
	EFortAIDirectorEvent                               AIDirectorEvent;                                          // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              MaxContribution;                                          // 0x0004(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortAIDirectorFactorContribution>     ContributionType;                                         // 0x0008(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAIDirectorFactorData
// 0x0020
struct FFortAIDirectorFactorData
{
	EFortAIDirectorFactor                              AIDirectorFactor;                                         // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<struct FFortAIDirectorFactorContribution>   ContributingEvents;                                       // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	float                                              MaxValue;                                                 // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAIDirectorEvent
// 0x0020
struct FFortAIDirectorEvent
{
	EFortAIDirectorEvent                               Event;                                                    // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	class UObject*                                     EventSource;                                              // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	class UObject*                                     EventTarget;                                              // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	float                                              EventValue;                                               // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortCurveSequenceInstanceInfo
// 0x0004
struct FFortCurveSequenceInstanceInfo
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x0000(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortSpawnPointsPercentageCurveSequenceInstanceInfo
// 0x000C (0x0010 - 0x0004)
struct FFortSpawnPointsPercentageCurveSequenceInstanceInfo : public FFortCurveSequenceInstanceInfo
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	class UFortSpawnPointsPercentageCurveSequence*     SpawnPointsPercentageCurveSequence;                       // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortIntensityCurveSequenceInstanceInfo
// 0x000C (0x0010 - 0x0004)
struct FFortIntensityCurveSequenceInstanceInfo : public FFortCurveSequenceInstanceInfo
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	class UFortIntensityCurveSequence*                 IntensityCurveSequence;                                   // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.AIEncounterSpawnGroupWeights
// 0x0018
struct FAIEncounterSpawnGroupWeights
{
	unsigned char                                      UnknownData00[0x18];                                      // 0x0000(0x0018) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAIPawnUpgradeData
// 0x0038
struct FFortAIPawnUpgradeData
{
	struct FCurveTableRowHandle                        SpawnPointsMultiplierCurve;                               // 0x0000(0x0010) (Edit, DisableEditOnInstance)
	struct FCurveTableRowHandle                        LifespanMultiplierCurve;                                  // 0x0010(0x0010) (Edit, DisableEditOnInstance)
	struct FCurveTableRowHandle                        ScoreMultiplierCurve;                                     // 0x0020(0x0010) (Edit, DisableEditOnInstance)
	class UFortGameplayModifierItemDefinition*         ModifierDefinition;                                       // 0x0030(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.SpawnGroupInstanceInfo
// 0x0130
struct FSpawnGroupInstanceInfo
{
	class UFortAISpawnGroup*                           SpawnGroup;                                               // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                NumActiveAlive;                                           // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                TotalGroupCost;                                           // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                SpawnPointsUsed;                                          // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                NumEngaged;                                               // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bReadyToSpawn;                                            // 0x0018(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bFinishedSpawning;                                        // 0x0019(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x001A(0x0002) MISSED OFFSET
	struct FGuid                                       GroupGuid;                                                // 0x001C(0x0010) (IsPlainOldData)
	int                                                EnemySpawnDataIndex;                                      // 0x002C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              TimeSelected;                                             // 0x0030(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                NextEnemyToSpawnIndex;                                    // 0x0034(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FGameplayTagContainer                       UpgradeTags;                                              // 0x0038(0x0020)
	struct FFortAISpawnGroupUpgradeUIData              UpgradeUIData;                                            // 0x0058(0x00A8)
	TArray<struct FFortAIPawnUpgradeData>              PawnUpgrades;                                             // 0x0100(0x0010) (ZeroConstructor)
	TArray<class UFortGameplayModifierItemDefinition*> ModifiersForAllPawns;                                     // 0x0110(0x0010) (ZeroConstructor)
	TArray<class AFortAIPawn*>                         PawnList;                                                 // 0x0120(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortAIEncounterWaveProgressEstimation
// 0x001C
struct FFortAIEncounterWaveProgressEstimation
{
	float                                              SectionProgressEstimate;                                  // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              SectionStartTime;                                         // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              LastWaveProgressUpdateTime;                               // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              PeakAndFadeWavePercentage;                                // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              MaxAdjustmentPerSecond;                                   // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortAIWaveProgressSection>            CurrentSection;                                           // 0x0014(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
	int                                                NumberOfWaveSegments;                                     // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortGoalActorEncounterDataManagerPair
// 0x0010
struct FFortGoalActorEncounterDataManagerPair
{
	class AActor*                                      GoalActor;                                                // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	class AFortAIDirectorDataManager*                  EncounterDataManager;                                     // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortEncounterSettings
// 0x0058
struct FFortEncounterSettings
{
	TArray<TEnumAsByte<EFortEncounterDirection>>       ForbiddenSpawnDirections;                                 // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bRiftsDestroyPlayerBuiltBuildings;                        // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bMustFindSpawnPoints;                                     // 0x0011(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bTrackCombatParticipation;                                // 0x0012(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bDisplayThreatVisuals;                                    // 0x0013(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                NumRiftsToUseOverride;                                    // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bUseEQSQueryToFindAISpawnLocations;                       // 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bRelevantForTotalAICap;                                   // 0x0019(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x001A(0x0006) MISSED OFFSET
	class UEnvQuery*                                   RiftSelectionQuery;                                       // 0x0020(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<class AActor*>                              ScriptedSpawnPoints;                                      // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<class AActor*>                              WorkingScriptedSpawnPoints;                               // 0x0038(0x0010) (ZeroConstructor, Transient)
	TArray<class UFortDifficultyOptionCategoryEncounter*> InjectedOverrideCategories;                               // 0x0048(0x0010) (ZeroConstructor, Transient)
};

// ScriptStruct FortniteGame.FortSpawnAIRequest
// 0x0050
struct FFortSpawnAIRequest
{
	struct FGuid                                       SpawnGroupInstanceGuid;                                   // 0x0000(0x0010) (IsPlainOldData)
	int                                                EnemyIndex;                                               // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector                                     SpawnLocation;                                            // 0x0014(0x000C) (IsPlainOldData)
	struct FRotator                                    SpawnRotation;                                            // 0x0020(0x000C) (IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	class AActor*                                      SpawnPoint;                                               // 0x0030(0x0008) (ZeroConstructor, IsPlainOldData)
	TArray<class UFortAbilitySet*>                     AbilitySetsToGrantOnSpawn;                                // 0x0038(0x0010) (ZeroConstructor)
	bool                                               bIgnoreCollisionWhenSpawning;                             // 0x0048(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAISpawnerData
// 0x0060
struct FFortAISpawnerData
{
	struct FGuid                                       SpawnGroupInstanceGuid;                                   // 0x0000(0x0010) (IsPlainOldData)
	struct FFortSpawnAIRequest                         ReservedSpawnRequest;                                     // 0x0010(0x0050)
};

// ScriptStruct FortniteGame.FortAIEncounterTimedModifierTags
// 0x0028
struct FFortAIEncounterTimedModifierTags
{
	float                                              TimeSeconds;                                              // 0x0000(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FGameplayTagContainer                       GameplayTags;                                             // 0x0008(0x0020) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.EncounterEnvironmentQueryInstance
// 0x0048
struct FEncounterEnvironmentQueryInstance
{
	struct FEncounterEnvironmentQueryInfo              EnvironmentQueryInfo;                                     // 0x0000(0x0028)
	int                                                QueryID;                                                  // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bIsWaitingForQueryResults;                                // 0x002C(0x0001) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortEncounterDirection>               ChosenDirection;                                          // 0x002D(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x002E(0x0002) MISSED OFFSET
	TArray<struct FVector>                             QueryLocations;                                           // 0x0030(0x0010) (ZeroConstructor)
	int                                                NumTimesUsed;                                             // 0x0040(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAIEncounterRift
// 0x0018
struct FFortAIEncounterRift
{
	int                                                QueryID;                                                  // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector                                     RiftLocation;                                             // 0x0004(0x000C) (IsPlainOldData)
	class ABuildingRift*                               RiftActor;                                                // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortAIEncounterSpawnArea
// 0x0048
struct FFortAIEncounterSpawnArea
{
	TArray<struct FEncounterEnvironmentQueryInstance>  QueryInstances;                                           // 0x0000(0x0010) (ZeroConstructor)
	TArray<struct FFortAIEncounterRift>                PendingRifts;                                             // 0x0010(0x0010) (ZeroConstructor)
	TArray<struct FFortAIEncounterRift>                Rifts;                                                    // 0x0020(0x0010) (ZeroConstructor)
	TArray<class UFortPathCostEstimator*>              PathEstimators;                                           // 0x0030(0x0010) (ZeroConstructor)
	bool                                               bIsActive;                                                // 0x0040(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bUsingFallbackQuery;                                      // 0x0041(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0042(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAIEncounterQueryDirectionTracker
// 0x0048
struct FFortAIEncounterQueryDirectionTracker
{
	bool                                               bHasTriedPreviousDirections;                              // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<TEnumAsByte<EFortEncounterDirection>>       PreviousQueryDirections;                                  // 0x0008(0x0010) (ZeroConstructor)
	TArray<TEnumAsByte<EFortEncounterDirection>>       ChosenDirections;                                         // 0x0018(0x0010) (ZeroConstructor)
	TArray<TEnumAsByte<EFortEncounterDirection>>       FailedDirections;                                         // 0x0028(0x0010) (ZeroConstructor)
	TArray<TEnumAsByte<EFortEncounterDirection>>       AvailableDirections;                                      // 0x0038(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortEncounterTransitionSettings
// 0x0001
struct FFortEncounterTransitionSettings
{
	unsigned char                                      UnknownData00[0x1];                                       // 0x0000(0x0001) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortGeneratedEncounterSequence
// 0x0030
struct FFortGeneratedEncounterSequence
{
	struct FFortEncounterTransitionSettings            TransitionSettings;                                       // 0x0000(0x0001)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                StartingGeneratedEncounterProfileIndex;                   // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                NumEncountersInSequence;                                  // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FGameplayTagContainer                       EncounterSequenceTags;                                    // 0x0010(0x0020)
};

// ScriptStruct FortniteGame.GoalSelectionCriteria
// 0x0008
struct FGoalSelectionCriteria
{
	class UEnvQuery*                                   GoalSelectionQuery;                                       // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.PawnGoalSelectionCriteria
// 0x0050
struct FPawnGoalSelectionCriteria
{
	struct FGameplayTagContainer                       IncludeEnemiesWithTags;                                   // 0x0000(0x0020) (Edit)
	struct FGameplayTagContainer                       ExcludeEnemiesWithTags;                                   // 0x0020(0x0020) (Edit)
	TArray<struct FGoalSelectionCriteria>              GoalSelectionCriteria;                                    // 0x0040(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct FortniteGame.PawnGoalSelectionTableEntry
// 0x0070
struct FPawnGoalSelectionTableEntry
{
	struct FGameplayTagContainer                       RequiredGameplayTags;                                     // 0x0000(0x0020) (Edit)
	struct FPawnGoalSelectionCriteria                  PawnGoalSelectionCriteria;                                // 0x0020(0x0050) (Edit)
};

// ScriptStruct FortniteGame.EncounterGoalSelectionTableEntry
// 0x0028
struct FEncounterGoalSelectionTableEntry
{
	struct FGameplayTagContainer                       RequiredGameplayTags;                                     // 0x0000(0x0020) (Edit)
	struct FGoalSelectionCriteria                      GoalSelectionCriteria;                                    // 0x0020(0x0008) (Edit, IsPlainOldData)
};

// ScriptStruct FortniteGame.AutoAcquireSlot
// 0x0010 (0x0020 - 0x0010)
struct FAutoAcquireSlot : public FAIHotSpotSlotInfo
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0010(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortPickupEntryData
// 0x0030
struct FFortPickupEntryData
{
	struct FInterpCurveFloat                           FloatCurve;                                               // 0x0000(0x0018)
	struct FGuid                                       PickupGuid;                                               // 0x0018(0x0010) (IsPlainOldData)
	float                                              StartTime;                                                // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.PawnDamageZones
// 0x0018
struct FPawnDamageZones
{
	bool                                               bActive;                                                  // 0x0000(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<struct FName>                               Bones;                                                    // 0x0008(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortSpokenLine
// 0x0030
struct FFortSpokenLine
{
	class USoundBase*                                  Audio;                                                    // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	class UAnimMontage*                                AnimMontage;                                              // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               AnimSequence;                                             // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	class AFortPawn*                                   Addressee;                                                // 0x0018(0x0008) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortFeedbackBroadcastFilter>          BroadcastFilter;                                          // 0x0020(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0021(0x0003) MISSED OFFSET
	float                                              Delay;                                                    // 0x0024(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bInterruptCurrentLine;                                    // 0x0028(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bCanBeInterrupted;                                        // 0x0029(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bCanQue;                                                  // 0x002A(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x5];                                       // 0x002B(0x0005) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortPawnVocalChord
// 0x00D8
struct FFortPawnVocalChord
{
	class UAudioComponent*                             FeedbackAudioComponent;                                   // 0x0000(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FFortSpokenLine                             ReplicatedSpokenLine;                                     // 0x0008(0x0030)
	struct FFortSpokenLine                             PendingSpokenLine;                                        // 0x0038(0x0030) (RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	struct FFortSpokenLine                             QueuedSpokenLine;                                         // 0x0068(0x0030) (RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	struct FFortSpokenLine                             CurrentSpokenLine;                                        // 0x0098(0x0030) (RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	unsigned char                                      UnknownData00[0x10];                                      // 0x00C8(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortActiveMontageDecisionWindow
// 0x0018
struct FFortActiveMontageDecisionWindow
{
	class UFortAnimNotifyState_AbilityDecisionWindow*  DecisionWindow;                                           // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	class UAnimSequenceBase*                           DecisionAnimation;                                        // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	bool                                               bReceivedPrimaryInput;                                    // 0x0010(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bReceivedSecondaryInput;                                  // 0x0011(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bAlreadyProcessedInput;                                   // 0x0012(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x0013(0x0005) MISSED OFFSET
};

// ScriptStruct FortniteGame.DamagerInfo
// 0x0030
struct FDamagerInfo
{
	class AActor*                                      DamageCauser;                                             // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                DamageAmount;                                             // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FGameplayTagContainer                       SourceTags;                                               // 0x0010(0x0020)
};

// ScriptStruct FortniteGame.CalloutEntry
// 0x0080
struct FCalloutEntry
{
	struct FGameplayTag                                CalloutTag;                                               // 0x0000(0x0008) (Edit, DisableEditOnInstance)
	struct FSlateBrush                                 CalloutIcon;                                              // 0x0008(0x0078) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortFeedbackHandle
// 0x0018
struct FFortFeedbackHandle
{
	class UFortFeedbackBank*                           FeedbackBank;                                             // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       EventName;                                                // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bReadOnly;                                                // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bBankDefined;                                             // 0x0011(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortFeedbackBroadcastFilter>          BroadcastFilterOverride;                                  // 0x0012(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x0013(0x0005) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortSentenceAudio
// 0x0040
struct FFortSentenceAudio
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortSentenceAudio.Audio
	struct FFortFeedbackHandle                         Handle;                                                   // 0x0028(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortConversationSentence
// 0x00C8
struct FFortConversationSentence
{
	struct FFortSentenceAudio                          SpeechAudio;                                              // 0x0000(0x0040) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FText                                       SpeechText;                                               // 0x0040(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0058(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortConversationSentence.TalkingHeadTexture
	struct FText                                       TalkingHeadTitle;                                         // 0x0080(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	unsigned char                                      UnknownData01[0x28];                                      // 0x0098(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortConversationSentence.AnimMontage
	float                                              PostSentenceDelay;                                        // 0x00C0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              DisplayDuration;                                          // 0x00C4(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.AssetAttachment
// 0x0030
struct FAssetAttachment
{
	struct FName                                       SocketName;                                               // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class USkeletalMesh*                               SkeletalMeshAsset;                                        // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UStaticMesh*                                 StaticMeshAsset;                                          // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bSkipOnDedicatedServers;                                  // 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
	class USkeletalMeshComponent*                      SkelMeshComp;                                             // 0x0020(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	class UStaticMeshComponent*                        StaticMeshComp;                                           // 0x0028(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
};

// ScriptStruct FortniteGame.MinimapGoalByTagColorsData
// 0x0030
struct FMinimapGoalByTagColorsData
{
	struct FGameplayTagContainer                       GoalTags;                                                 // 0x0000(0x0020) (Edit, DisableEditOnInstance)
	struct FLinearColor                                MinimapColor;                                             // 0x0020(0x0010) (Edit, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortAIAppearanceOverrideEntry
// 0x0060
struct FFortAIAppearanceOverrideEntry
{
	struct FName                                       AppearanceName;                                           // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bIsFemale;                                                // 0x0008(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0009(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortAIAppearanceOverrideEntry.SkeletalMesh
	unsigned char                                      UnknownData02[0x28];                                      // 0x0038(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortAIAppearanceOverrideEntry.FeedbackBank
};

// ScriptStruct FortniteGame.FortAIPawnVariantDefinition
// 0x0068
struct FFortAIPawnVariantDefinition
{
	class UClass*                                      PawnClass;                                                // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FCurveTableRowHandle                        VariantWeightCurve;                                       // 0x0008(0x0010) (Edit, BlueprintVisible)
	float                                              CurrentWeight;                                            // 0x0018(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FGameplayTagQuery                           RequiredTagsQuery;                                        // 0x0020(0x0048) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.SpawnGroupEnemy
// 0x0010
struct FSpawnGroupEnemy
{
	class UClass*                                      EnemyVariantClass;                                        // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bOverrideVariantSpawnPointValue;                          // 0x0008(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
	int                                                SpawnValue;                                               // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortSpawnGroupEncounterTypeData
// 0x0040
struct FFortSpawnGroupEncounterTypeData
{
	struct FGameplayTagContainer                       EncounterTypeTags;                                        // 0x0000(0x0020) (Edit, DisableEditOnInstance)
	struct FCurveTableRowHandle                        MaxGroupCategoryPopulationDensityCurve;                   // 0x0020(0x0010) (Edit)
	struct FCurveTableRowHandle                        RespawnDelayCurve;                                        // 0x0030(0x0010) (Edit)
};

// ScriptStruct FortniteGame.SpawnGroupProgression
// 0x0008
struct FSpawnGroupProgression
{
	class UFortAISpawnGroup*                           SpawnGroup;                                               // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortAIPawnUpgrade
// 0x0058
struct FFortAIPawnUpgrade
{
	struct FGameplayTagQuery                           TagQuery;                                                 // 0x0000(0x0048) (Edit, DisableEditOnInstance)
	TArray<struct FFortAIPawnUpgradeData>              PawnUpgradeDataPerPlayerCount;                            // 0x0048(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortAIPawnUpgradeProbability
// 0x0058
struct FFortAIPawnUpgradeProbability
{
	struct FGameplayTagQuery                           TagQuery;                                                 // 0x0000(0x0048) (Edit, DisableEditOnInstance)
	struct FCurveTableRowHandle                        UpgradeProbability;                                       // 0x0048(0x0010) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortAlterationSlots
// 0x0002
struct FFortAlterationSlots
{
	TEnumAsByte<EFortAlteration>                       Type;                                                     // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      NumSlots;                                                 // 0x0001(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortConditionalCosmeticModification
// 0x0B40
struct FFortConditionalCosmeticModification
{
	struct FFortCosmeticModification                   CosmeticModification;                                     // 0x0000(0x0B20) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FGameplayTagContainer                       ConditionalTags;                                          // 0x0B20(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.FortConditionalIncludeTags
// 0x0040
struct FFortConditionalIncludeTags
{
	struct FGameplayTagContainer                       ConditionTags;                                            // 0x0000(0x0020) (Edit)
	struct FGameplayTagContainer                       IncludeTags;                                              // 0x0020(0x0020) (Edit)
};

// ScriptStruct FortniteGame.FortMontageInputAction
// 0x0018
struct FFortMontageInputAction
{
	struct FGameplayTag                                TriggerAbilityTag;                                        // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FName                                       NextSection;                                              // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFortMontageInputType                              InputType;                                                // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortSpawnContext
// 0x0028
struct FFortSpawnContext
{
	TEnumAsByte<EFortTeam>                             Team;                                                     // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, SaveGame, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FGameplayTagContainer                       Tags;                                                     // 0x0008(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, EditConst, SaveGame)
};

// ScriptStruct FortniteGame.TieredWaveSetData
// 0x0160
struct FTieredWaveSetData
{
	int                                                EDOIdx;                                                   // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              BreatherBetweenWaves;                                     // 0x0004(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	EWaveRules                                         WaveRules;                                                // 0x0008(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
	float                                              WaveLengthMod;                                            // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              NumKillsMod;                                              // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              KillPointsMod;                                            // 0x0014(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              DifficultyAddMod;                                         // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData02[0x28];                                      // 0x001C(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.TieredWaveSetData.OverrideSpawnPointsMultiplier
	unsigned char                                      UnknownData03[0x28];                                      // 0x0048(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.TieredWaveSetData.OverrideSpawnProgression
	unsigned char                                      UnknownData04[0x28];                                      // 0x0070(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.TieredWaveSetData.OverrideUtilitiesAdjustment
	unsigned char                                      UnknownData05[0x28];                                      // 0x0098(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.TieredWaveSetData.OverrideUtilitiesFree
	unsigned char                                      UnknownData06[0x28];                                      // 0x00C0(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.TieredWaveSetData.OverrideUtilitiesLocked
	unsigned char                                      UnknownData07[0x28];                                      // 0x00E8(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.TieredWaveSetData.OverrideDistance
	unsigned char                                      UnknownData08[0x28];                                      // 0x0110(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.TieredWaveSetData.OverrideDirectionNumber
	unsigned char                                      UnknownData09[0x28];                                      // 0x0138(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.TieredWaveSetData.OverrideModifierTags
};

// ScriptStruct FortniteGame.ChoiceDataEntry
// 0x0050
struct FChoiceDataEntry
{
	struct FText                                       ButtonText;                                               // 0x0000(0x0018) (Edit, BlueprintVisible)
	struct FText                                       ButtonDescription;                                        // 0x0018(0x0018) (Edit, BlueprintVisible)
	struct FText                                       ConfirmText;                                              // 0x0030(0x0018) (Edit, BlueprintVisible)
	bool                                               bEnabled;                                                 // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bRequireConfirmation;                                     // 0x0049(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bCloseAfterSelection;                                     // 0x004A(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x004B(0x0005) MISSED OFFSET
};

// ScriptStruct FortniteGame.ChoiceData
// 0x0030
struct FChoiceData
{
	int                                                MenuIdentifier;                                           // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bShowCloseButton;                                         // 0x0004(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0005(0x0003) MISSED OFFSET
	struct FText                                       Title;                                                    // 0x0008(0x0018) (Edit, BlueprintVisible)
	TArray<struct FChoiceDataEntry>                    Items;                                                    // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortDialogDescription
// 0x0150
struct FFortDialogDescription
{
	struct FSlateBrush                                 Icon;                                                     // 0x0000(0x0078) (BlueprintVisible)
	struct FText                                       MessageHeader;                                            // 0x0078(0x0018) (BlueprintVisible)
	struct FText                                       MessageBody;                                              // 0x0090(0x0018) (BlueprintVisible)
	struct FText                                       AcceptButtonText;                                         // 0x00A8(0x0018) (BlueprintVisible)
	struct FText                                       IgnoreButtonText;                                         // 0x00C0(0x0018) (BlueprintVisible)
	struct FText                                       DismissButtonText;                                        // 0x00D8(0x0018) (BlueprintVisible)
	float                                              DisplayTime;                                              // 0x00F0(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00F4(0x0004) MISSED OFFSET
	class UUserWidget*                                 AdditionalContent;                                        // 0x00F8(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	EFortDialogFeedbackType                            FeedBackType;                                             // 0x0100(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Dismissable;                                              // 0x0101(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x0102(0x0006) MISSED OFFSET
	class UFortNotificationHandler*                    NotificationHandler;                                      // 0x0108(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x40];                                      // 0x0110(0x0040) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortSafeZoneVolumeDefinition
// 0x0030
struct FFortSafeZoneVolumeDefinition
{
	class AVolume*                                     Volume;                                                   // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FScalableFloat                              RejectionChance;                                          // 0x0008(0x0028) (Edit)
};

// ScriptStruct FortniteGame.FortSafeZoneDefinition
// 0x0160
struct FFortSafeZoneDefinition
{
	struct FScalableFloat                              Radius;                                                   // 0x0000(0x0028) (Edit)
	struct FScalableFloat                              RejectRadius;                                             // 0x0028(0x0028) (Edit)
	struct FScalableFloat                              WaitTime;                                                 // 0x0050(0x0028) (Edit)
	struct FScalableFloat                              ShrinkTime;                                               // 0x0078(0x0028) (Edit)
	struct FScalableFloat                              FiftyFiftyWaitTimePlayerRatioScale;                       // 0x00A0(0x0028) (Edit)
	struct FScalableFloat                              FiftyFiftyShrinkTimePlayerRatioScale;                     // 0x00C8(0x0028) (Edit)
	struct FScalableFloat                              SupplyDropMinCount;                                       // 0x00F0(0x0028) (Edit)
	struct FScalableFloat                              SupplyDropMaxCount;                                       // 0x0118(0x0028) (Edit)
	unsigned char                                      UnknownData00[0x20];                                      // 0x0140(0x0020) MISSED OFFSET
};

// ScriptStruct FortniteGame.AthenaCarPlayerSlot
// 0x0020
struct FAthenaCarPlayerSlot
{
	struct FName                                       SeatSocket;                                               // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	TArray<struct FName>                               ExitSockets;                                              // 0x0008(0x0010) (Edit, ZeroConstructor)
	class APawn*                                       Player;                                                   // 0x0018(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.ReplicatedAthenaVehicleState
// 0x000C
struct FReplicatedAthenaVehicleState
{
	struct FVector                                     ForwardVectorTarget;                                      // 0x0000(0x000C) (IsPlainOldData)
};

// ScriptStruct FortniteGame.MyFortCategoryData
// 0x0058
struct FMyFortCategoryData
{
	struct FText                                       CategoryName;                                             // 0x0000(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FGameplayTag                                TooltipTag;                                               // 0x0018(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FGameplayTagContainer                       ModifiedTagContainer;                                     // 0x0020(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	bool                                               bIsCore;                                                  // 0x0040(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0041(0x0007) MISSED OFFSET
	TArray<struct FGameplayAttribute>                  Attributes;                                               // 0x0048(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortAttributeDetailsInfo
// 0x0320
struct FFortAttributeDetailsInfo
{
	struct FGameplayTagContainer                       RequiredTags;                                             // 0x0000(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FFortMultiSizeBrush                         Icon;                                                     // 0x0020(0x02D0) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FText                                       DisplayName;                                              // 0x02F0(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FText                                       Description;                                              // 0x0308(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.FortAttributeInfo
// 0x0078
struct FFortAttributeInfo
{
	struct FGameplayAttribute                          Attribute;                                                // 0x0000(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, EditConst)
	TEnumAsByte<EFortAttributeDisplay>                 DisplayMethod;                                            // 0x0020(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
	struct FText                                       UnitDisplayName;                                          // 0x0028(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	float                                              DisplayScalingFactor;                                     // 0x0040(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	struct FText                                       FormatText;                                               // 0x0048(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	TArray<struct FFortAttributeDetailsInfo>           AttributeDetails;                                         // 0x0060(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	bool                                               bShowInSummaries;                                         // 0x0070(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bShowInDifferences;                                       // 0x0071(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bShowAsBuffInFE;                                          // 0x0072(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bNegativeValuesShouldBeDisplayedPositively;               // 0x0073(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0074(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.HomebaseBannerColor
// 0x0020
struct FHomebaseBannerColor
{
	struct FLinearColor                                PrimaryColor;                                             // 0x0000(0x0010) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FLinearColor                                SecondaryColor;                                           // 0x0010(0x0010) (Edit, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortAnalyticsEventAttribute
// 0x0020
struct FFortAnalyticsEventAttribute
{
	unsigned char                                      UnknownData00[0x20];                                      // 0x0000(0x0020) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortTierCollectionLayoutOutput
// 0x0050
struct FFortTierCollectionLayoutOutput
{
	struct FName                                       SpawnCollectionName;                                      // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       DifficultyRowName;                                        // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       ModifierProgressionName;                                  // 0x0010(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              AdditiveDifficultyMod;                                    // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	TArray<class UFortBadgeItemDefinition*>            RewardBadges;                                             // 0x0020(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FName>                               StartTierLootTierGroups;                                  // 0x0030(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FName>                               WaveCompleteLootTierGroups;                               // 0x0040(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.DistanceToTargetComparison
// 0x0030
struct FDistanceToTargetComparison
{
	bool                                               bUseOverriddenValue;                                      // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              OverriddenValue;                                          // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FGameplayTagContainer                       DistanceDataTags;                                         // 0x0008(0x0020) (Edit)
	TEnumAsByte<EArithmeticKeyOperation>               Operator;                                                 // 0x0028(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ETargetDistanceComparisonType>         ComparisonType;                                           // 0x0029(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x002A(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortActorRecord
// 0x0070
struct FFortActorRecord
{
	struct FGuid                                       ActorGuid;                                                // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, EditConst, IsPlainOldData)
	TEnumAsByte<EFortBuildingPersistentState>          ActorState;                                               // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
	class UClass*                                      ActorClass;                                               // 0x0018(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	struct FTransform                                  ActorTransform;                                           // 0x0020(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly, EditConst, IsPlainOldData)
	bool                                               bSpawnedActor;                                            // 0x0050(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0051(0x0007) MISSED OFFSET
	TArray<unsigned char>                              ActorData;                                                // 0x0058(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0068(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortBuildingInstruction
// 0x0070
struct FFortBuildingInstruction
{
	struct FFortActorRecord                            ActorRecord;                                              // 0x0000(0x0070) (Edit, BlueprintVisible, BlueprintReadOnly, EditConst, SaveGame)
};

// ScriptStruct FortniteGame.InterpOffsetData
// 0x001C
struct FInterpOffsetData
{
	struct FVector                                     ViewOffset;                                               // 0x0000(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     LargeBodyTypeAddtnlOffset;                                // 0x000C(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              PitchAngle;                                               // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.InterpOffset
// 0x0010
struct FInterpOffset
{
	TArray<struct FInterpOffsetData>                   SamplePoints;                                             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct FortniteGame.CarriedObjectAttachmentInfo
// 0x0028
struct FCarriedObjectAttachmentInfo
{
	class AActor*                                      AttachParent;                                             // 0x0000(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	struct FName                                       SocketName;                                               // 0x0008(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	struct FVector                                     RelativeTranslation;                                      // 0x0010(0x000C) (Transient, IsPlainOldData)
	struct FRotator                                    RelativeRotation;                                         // 0x001C(0x000C) (Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.AIDirectorDebugInfo
// 0x0028
struct FAIDirectorDebugInfo
{
	float                                              Timestamp;                                                // 0x0000(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	TArray<float>                                      DebugGraphData;                                           // 0x0008(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0018(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.LastBuildableState
// 0x0010
struct FLastBuildableState
{
	class UBuildingEditModeMetadata*                   LastBuildableMetaData;                                    // 0x0000(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	bool                                               LastBuildableMirrored;                                    // 0x0008(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
	int                                                LastBuildableRotationIterations;                          // 0x000C(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortDamageNumberInfo
// 0x0068
struct FFortDamageNumberInfo
{
	struct FVector                                     WorldLocation;                                            // 0x0000(0x000C) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FVector                                     HitNormal;                                                // 0x000C(0x000C) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	bool                                               bIsCriticalDamage;                                        // 0x0018(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0019(0x0003) MISSED OFFSET
	int                                                Damage;                                                   // 0x001C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFortDamageNumberType                              DamageNumberType;                                         // 0x0020(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0021(0x0003) MISSED OFFSET
	float                                              VisualDamageScale;                                        // 0x0024(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFortElementalDamageType                           ElementalDamageType;                                      // 0x0028(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EStatCategory                                      ScoreType;                                                // 0x0029(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bAttachScoreNumberToPlayer;                               // 0x002A(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x5];                                       // 0x002B(0x0005) MISSED OFFSET
	class UStaticMeshComponent*                        StaticMeshComponent;                                      // 0x0030(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, InstancedReference, IsPlainOldData)
	TArray<class UMaterialInstanceDynamic*>            MeshMIDs;                                                 // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        DamageNumberArray;                                        // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TWeakObjectPtr<class AActor>                       DamagedActor;                                             // 0x0058(0x0008) (ZeroConstructor, IsPlainOldData)
	TWeakObjectPtr<class APawn>                        DamageCauser;                                             // 0x0060(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortGiftingInfo
// 0x0028
struct FFortGiftingInfo
{
	struct FString                                     PlayerName;                                               // 0x0000(0x0010) (ZeroConstructor)
	class UFortHeroType*                               HeroType;                                                 // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0018(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortItemEntryStateValue
// 0x0018
struct FFortItemEntryStateValue
{
	int                                                IntValue;                                                 // 0x0000(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FName                                       NameValue;                                                // 0x0008(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TEnumAsByte<EFortItemEntryState>                   StateType;                                                // 0x0010(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortItemEntry
// 0x00A4 (0x00B0 - 0x000C)
struct FFortItemEntry : public FFastArraySerializerItem
{
	int                                                Count;                                                    // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, SaveGame, IsPlainOldData)
	int                                                PreviousCount;                                            // 0x0010(0x0004) (ZeroConstructor, Transient, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	class UFortItemDefinition*                         ItemDefinition;                                           // 0x0018(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              Durability;                                               // 0x0020(0x0004) (ZeroConstructor, SaveGame, IsPlainOldData)
	int                                                Level;                                                    // 0x0024(0x0004) (ZeroConstructor, SaveGame, IsPlainOldData)
	int                                                LoadedAmmo;                                               // 0x0028(0x0004) (ZeroConstructor, SaveGame, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	TArray<class UFortAlterationItemDefinition*>       AlterationDefinitions;                                    // 0x0030(0x0010) (ZeroConstructor, SaveGame)
	struct FString                                     ItemSource;                                               // 0x0040(0x0010) (ZeroConstructor, SaveGame)
	struct FGuid                                       ItemGuid;                                                 // 0x0050(0x0010) (SaveGame, IsPlainOldData)
	bool                                               inventory_overflow_date;                                  // 0x0060(0x0001) (ZeroConstructor, SaveGame, IsPlainOldData)
	bool                                               bIsReplicatedCopy;                                        // 0x0061(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bIsDirty;                                                 // 0x0062(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData02[0x5];                                       // 0x0063(0x0005) MISSED OFFSET
	struct FFortGiftingInfo                            GiftingInfo;                                              // 0x0068(0x0028)
	TArray<struct FFortItemEntryStateValue>            StateValues;                                              // 0x0090(0x0010) (ZeroConstructor, Transient)
	TWeakObjectPtr<class AFortInventory>               ParentInventory;                                          // 0x00A0(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	struct FGameplayAbilitySpecHandle                  GameplayAbilitySpecHandle;                                // 0x00A8(0x0004) (Transient)
	unsigned char                                      UnknownData03[0x4];                                       // 0x00AC(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortRewardActivity
// 0x0078
struct FFortRewardActivity
{
	TEnumAsByte<EFortRewardActivityType>               ActivityType;                                             // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	struct FGuid                                       ActivityGuid;                                             // 0x0004(0x0010) (IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FText                                       TitleText;                                                // 0x0018(0x0018)
	struct FText                                       DescriptionText;                                          // 0x0030(0x0018)
	float                                              RewardDisplayTime;                                        // 0x0048(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	TArray<struct FFortItemEntry>                      RewardItems;                                              // 0x0050(0x0010) (ZeroConstructor)
	TArray<struct FFortItemEntry>                      MissedRewardItems;                                        // 0x0060(0x0010) (ZeroConstructor)
	EFortCompletionResult                              ActivityCompletionResult;                                 // 0x0070(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x0071(0x0003) MISSED OFFSET
	int                                                AdditionalCompletionMissionPoints;                        // 0x0074(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortRewardReport
// 0x0068
struct FFortRewardReport
{
	struct FText                                       MissionName;                                              // 0x0000(0x0018)
	struct FText                                       TheaterName;                                              // 0x0018(0x0018)
	struct FText                                       Difficulty;                                               // 0x0030(0x0018)
	float                                              DifficultyValue;                                          // 0x0048(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	TArray<struct FFortRewardActivity>                 RewardActivities;                                         // 0x0050(0x0010) (ZeroConstructor)
	bool                                               bIsFinalized;                                             // 0x0060(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0061(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortUpdatedObjectiveStat
// 0x0018
struct FFortUpdatedObjectiveStat
{
	class UFortQuestItemDefinition*                    Quest;                                                    // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FName                                       BackendName;                                              // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                StatValue;                                                // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortPersistentGameplayStatValue
// 0x0018
struct FFortPersistentGameplayStatValue
{
	struct FString                                     StatName;                                                 // 0x0000(0x0010) (ZeroConstructor)
	int                                                StatValue;                                                // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortPersistentGameplayStatContainer
// 0x0010
struct FFortPersistentGameplayStatContainer
{
	TArray<struct FFortPersistentGameplayStatValue>    GameplayStats;                                            // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortCombatManagerEvent
// 0x0008
struct FFortCombatManagerEvent
{
	float                                              EventValue;                                               // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortCombatEvents>                     Event;                                                    // 0x0004(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0005(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortCrackEffectData
// 0x0028
struct FFortCrackEffectData
{
	struct FVector_NetQuantizeNormal                   Normal;                                                   // 0x0000(0x000C)
	struct FVector_NetQuantize10                       Position;                                                 // 0x000C(0x000C)
	TEnumAsByte<EPhysicalSurface>                      SurfaceType;                                              // 0x0018(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
	class AFortCrackEffect*                            OldCrackEffect;                                           // 0x0020(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.BuildingClassData
// 0x0010
struct FBuildingClassData
{
	class UClass*                                      BuildingClass;                                            // 0x0000(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                PreviousBuildingLevel;                                    // 0x0008(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                UpgradeLevel;                                             // 0x000C(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortRequirementsInfo
// 0x0048
struct FFortRequirementsInfo
{
	int                                                CommanderLevel;                                           // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                PersonalPowerRating;                                      // 0x0004(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                MaxPersonalPowerRating;                                   // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                PartyPowerRating;                                         // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                MaxPartyPowerRating;                                      // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	class UFortQuestItemDefinition*                    ActiveQuestDefinition;                                    // 0x0018(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UFortQuestItemDefinition*                    QuestDefinition;                                          // 0x0020(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FDataTableRowHandle                         ObjectiveStatHandle;                                      // 0x0028(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	class UFortQuestItemDefinition*                    UncompletedQuestDefinition;                               // 0x0038(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UFortItemDefinition*                         ItemDefinition;                                           // 0x0040(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.AttributeModifierInfo
// 0x0030
struct FAttributeModifierInfo
{
	unsigned char                                      UnknownData00[0x18];                                      // 0x0000(0x0018) MISSED OFFSET
	class UGameplayEffect*                             InstantGEs;                                               // 0x0018(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0020(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.SpawnPickupEntry
// 0x0018
struct FSpawnPickupEntry
{
	struct FString                                     Name;                                                     // 0x0000(0x0010) (ZeroConstructor)
	class UClass*                                      PickupClass;                                              // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FriendCode
// 0x0020
struct FFriendCode
{
	struct FString                                     Code;                                                     // 0x0000(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FString                                     CodeType;                                                 // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortClientAnnouncementData
// 0x0001
struct FFortClientAnnouncementData
{
	unsigned char                                      UnknownData00[0x1];                                       // 0x0000(0x0001) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortClientAnnouncementData_Basic
// 0x00D7 (0x00D8 - 0x0001)
struct FFortClientAnnouncementData_Basic : public FFortClientAnnouncementData
{
	struct FSlateBrush                                 Icon;                                                     // 0x0000(0x0078) (Edit, BlueprintVisible)
	struct FText                                       TitleText;                                                // 0x0078(0x0018) (Edit, BlueprintVisible)
	struct FText                                       DetailText;                                               // 0x0090(0x0018) (Edit, BlueprintVisible)
	struct FText                                       GamepadDetailText;                                        // 0x00A8(0x0018) (Edit, BlueprintVisible)
	int                                                Priority;                                                 // 0x00C0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00C4(0x0004) MISSED OFFSET
	float                                              DisplayTime;                                              // 0x00C8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00CC(0x0004) MISSED OFFSET
	class USoundBase*                                  OnStartSound;                                             // 0x00D0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortClientAnnouncementData_Conversation
// 0x000F (0x0010 - 0x0001)
struct FFortClientAnnouncementData_Conversation : public FFortClientAnnouncementData
{
	class UFortConversation*                           Conversation;                                             // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EFortAnnouncementDisplayPreference                 ConversationDisplayPreference;                            // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortClientAnnouncementData_Tutorial
// 0x0050 (0x0128 - 0x00D8)
struct FFortClientAnnouncementData_Tutorial : public FFortClientAnnouncementData_Basic
{
	float                                              AutoContinueDelay;                                        // 0x00D8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00DC(0x0004) MISSED OFFSET
	struct FText                                       NameText;                                                 // 0x00E0(0x0018) (Edit, BlueprintVisible)
	struct FText                                       SystemText;                                               // 0x00F8(0x0018) (Edit, BlueprintVisible)
	bool                                               bButtonEnabled;                                           // 0x0110(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bLightboxEnabled;                                         // 0x0111(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bLightboxDisableInputOnly;                                // 0x0112(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x1];                                       // 0x0113(0x0001) MISSED OFFSET
	struct FMargin                                     Padding;                                                  // 0x0114(0x0010) (Edit, BlueprintVisible)
	TEnumAsByte<EVerticalAlignment>                    VAlign;                                                   // 0x0124(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EHorizontalAlignment>                  HAlign;                                                   // 0x0125(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x2];                                       // 0x0126(0x0002) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortClientAnnouncementData_ZoneModifiers
// 0x000F (0x0010 - 0x0001)
struct FFortClientAnnouncementData_ZoneModifiers : public FFortClientAnnouncementData
{
	TArray<class UFortGameplayModifierItemDefinition*> Modifiers;                                                // 0x0000(0x0010) (BlueprintVisible, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortClientAnnouncementQueue
// 0x0010
struct FFortClientAnnouncementQueue
{
	TArray<class AFortClientAnnouncement*>             Announcements;                                            // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortEventName
// 0x0010
struct FFortEventName
{
	struct FName                                       CategoryName;                                             // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FName                                       EventName;                                                // 0x0008(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortClientEventName
// 0x0000 (0x0010 - 0x0010)
struct FFortClientEventName : public FFortEventName
{

};

// ScriptStruct FortniteGame.FortClientEvent
// 0x0020
struct FFortClientEvent
{
	struct FName                                       CategoryName;                                             // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       EventName;                                                // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UObject*                                     EventSource;                                              // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UObject*                                     EventFocus;                                               // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortActionKeyMapping
// 0x0058
struct FFortActionKeyMapping
{
	struct FName                                       ActionName;                                               // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FText                                       LocalizedName;                                            // 0x0008(0x0018)
	struct FKey                                        KeyBind1;                                                 // 0x0020(0x0018)
	struct FKey                                        KeyBind2;                                                 // 0x0038(0x0018)
	float                                              InputScale;                                               // 0x0050(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bIsAxisMapping;                                           // 0x0054(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0055(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortPendingSlottedItemOperation
// 0x0018
struct FFortPendingSlottedItemOperation
{
	struct FString                                     SlottedItemId;                                            // 0x0000(0x0010) (ZeroConstructor)
	struct FName                                       SlotRowName;                                              // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortSelectableRewardOption
// 0x0010
struct FFortSelectableRewardOption
{
	TArray<struct FFortItemQuantityPair>               Rewards;                                                  // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortHiddenRewardQuantityPair
// 0x0010
struct FFortHiddenRewardQuantityPair
{
	struct FName                                       TemplateId;                                               // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Quantity;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortRewardInfo
// 0x0030
struct FFortRewardInfo
{
	TArray<struct FFortSelectableRewardOption>         SelectableRewards;                                        // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FFortItemQuantityPair>               StandardRewards;                                          // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FFortHiddenRewardQuantityPair>       HiddenRewards;                                            // 0x0020(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortCollectionBookRewards
// 0x0070
struct FFortCollectionBookRewards
{
	ECollectionBookRewardType                          RewardType;                                               // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FName                                       PageId;                                                   // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       SectionId;                                                // 0x0010(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                XpRequired;                                               // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FText                                       Description;                                              // 0x0020(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	bool                                               bIsMajorReward;                                           // 0x0038(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	struct FFortRewardInfo                             Rewards;                                                  // 0x0040(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.FortCollectionBookSectionState
// 0x0018
struct FFortCollectionBookSectionState
{
	struct FString                                     Section;                                                  // 0x0000(0x0010) (ZeroConstructor)
	EFortCollectionBookState                           State;                                                    // 0x0010(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.CombatEventData
// 0x0030
struct FCombatEventData
{
	float                                              Heat;                                                     // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MaxHeatContribution;                                      // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              CoolDownRate;                                             // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FString                                     EventName;                                                // 0x0010(0x0010) (Edit, ZeroConstructor)
	struct FLinearColor                                DebugGraphColor;                                          // 0x0020(0x0010) (Edit, IsPlainOldData)
};

// ScriptStruct FortniteGame.CombatEventMultiplier
// 0x0008
struct FCombatEventMultiplier
{
	TEnumAsByte<EFortCombatEvents>                     CombatEvent;                                              // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              MaxContribution;                                          // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.CombatFactorData
// 0x0038
struct FCombatFactorData
{
	TArray<struct FCombatEventMultiplier>              ContributingCombatEvents;                                 // 0x0000(0x0010) (Edit, ZeroConstructor)
	float                                              MaxValue;                                                 // 0x0010(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     DebugFactorName;                                          // 0x0018(0x0010) (Edit, ZeroConstructor)
	struct FLinearColor                                DebugGraphColor;                                          // 0x0028(0x0010) (Edit, IsPlainOldData)
};

// ScriptStruct FortniteGame.CombatThresholdData
// 0x0028
struct FCombatThresholdData
{
	float                                              HeatLevel;                                                // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     ThresholdName;                                            // 0x0008(0x0010) (Edit, ZeroConstructor)
	struct FLinearColor                                DebugGraphColor;                                          // 0x0018(0x0010) (Edit, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortCompendiumItemInfo
// 0x0030
struct FFortCompendiumItemInfo
{
	bool                                               bGrantWithCompendium;                                     // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0001(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortCompendiumItemInfo.CompendiumItemDefinition
};

// ScriptStruct FortniteGame.FortCompendiumQuestInfo
// 0x0030
struct FFortCompendiumQuestInfo
{
	bool                                               bGrantWithCompendium;                                     // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0001(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortCompendiumQuestInfo.QuestDefinition
};

// ScriptStruct FortniteGame.BASEGameplayEffect
// 0x0010
struct FBASEGameplayEffect
{
	class UClass*                                      Effect;                                                   // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                LevelOverride;                                            // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.PatternBASEEffect
// 0x0010
struct FPatternBASEEffect
{
	class UBuildingEditModeMetadata*                   Pattern;                                                  // 0x0000(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UStaticMesh*                                 Mesh;                                                     // 0x0008(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortBaseWeaponStats
// 0x0118 (0x0120 - 0x0008)
struct FFortBaseWeaponStats : public FTableRowBase
{
	int                                                BaseLevel;                                                // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DmgPB;                                                    // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DmgMid;                                                   // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DmgLong;                                                  // 0x0014(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DmgMaxRange;                                              // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              EnvDmgPB;                                                 // 0x001C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              EnvDmgMid;                                                // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              EnvDmgLong;                                               // 0x0024(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              EnvDmgMaxRange;                                           // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ImpactDmgPB;                                              // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ImpactDmgMid;                                             // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ImpactDmgLong;                                            // 0x0034(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ImpactDmgMaxRange;                                        // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bForceControl;                                            // 0x003C(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x003D(0x0003) MISSED OFFSET
	float                                              RngPB;                                                    // 0x0040(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RngMid;                                                   // 0x0044(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RngLong;                                                  // 0x0048(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RngMax;                                                   // 0x004C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UCurveTable*                                 DmgScaleTable;                                            // 0x0050(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       DmgScaleTableRow;                                         // 0x0058(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DmgScale;                                                 // 0x0060(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0064(0x0004) MISSED OFFSET
	class UCurveTable*                                 EnvDmgScaleTable;                                         // 0x0068(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       EnvDmgScaleTableRow;                                      // 0x0070(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              EnvDmgScale;                                              // 0x0078(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x007C(0x0004) MISSED OFFSET
	class UCurveTable*                                 ImpactDmgScaleTable;                                      // 0x0080(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       ImpactDmgScaleTableRow;                                   // 0x0088(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ImpactDmgScale;                                           // 0x0090(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x4];                                       // 0x0094(0x0004) MISSED OFFSET
	struct FName                                       SurfaceRatioRowName;                                      // 0x0098(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DamageZone_Light;                                         // 0x00A0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DamageZone_Normal;                                        // 0x00A4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DamageZone_Critical;                                      // 0x00A8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DamageZone_Vulnerability;                                 // 0x00AC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              KnockbackMagnitude;                                       // 0x00B0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MidRangeKnockbackMagnitude;                               // 0x00B4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              LongRangeKnockbackMagnitude;                              // 0x00B8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              KnockbackZAngle;                                          // 0x00BC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              StunTime;                                                 // 0x00C0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              StunScale;                                                // 0x00C4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UDataTable*                                  Durability;                                               // 0x00C8(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       DurabilityRowName;                                        // 0x00D0(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DurabilityScale;                                          // 0x00D8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DurabilityPerUse;                                         // 0x00DC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DiceCritChance;                                           // 0x00E0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DiceCritDamageMultiplier;                                 // 0x00E4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ReloadTime;                                               // 0x00E8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ReloadScale;                                              // 0x00EC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFortWeaponReloadType                              ReloadType;                                               // 0x00F0(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bReloadInterruptIsImmediate;                              // 0x00F1(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x2];                                       // 0x00F2(0x0002) MISSED OFFSET
	int                                                ClipSize;                                                 // 0x00F4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ClipScale;                                                // 0x00F8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                InitialClips;                                             // 0x00FC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                CartridgePerFire;                                         // 0x0100(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                AmmoCostPerFire;                                          // 0x0104(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaxAmmoCostPerFire;                                       // 0x0108(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MinChargeTime;                                            // 0x010C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaxChargeTime;                                            // 0x0110(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ChargeDownTime;                                           // 0x0114(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MinChargeDamageMultiplier;                                // 0x0118(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaxChargeDamageMultiplier;                                // 0x011C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.ConsumeEffectData
// 0x0050
struct FConsumeEffectData
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.ConsumeEffectData.EffectClass
	struct FScalableFloat                              Level;                                                    // 0x0028(0x0028) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortDailyRewardScheduleDisplayData
// 0x0060
struct FFortDailyRewardScheduleDisplayData
{
	struct FText                                       Title;                                                    // 0x0000(0x0018) (Edit)
	struct FText                                       Description;                                              // 0x0018(0x0018) (Edit)
	struct FText                                       ItemDescription;                                          // 0x0030(0x0018) (Edit)
	struct FText                                       EpicItemDescription;                                      // 0x0048(0x0018) (Edit)
};

// ScriptStruct FortniteGame.FortDailyRewardScheduleDefinition
// 0x00A8
struct FFortDailyRewardScheduleDefinition
{
	struct FName                                       ScheduleName;                                             // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0008(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortDailyRewardScheduleDefinition.EnablingToken
	class UDataTable*                                  Rewards;                                                  // 0x0030(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FFortDailyRewardScheduleDisplayData         DisplayData;                                              // 0x0038(0x0060) (Edit)
	struct FDateTime                                   BeginDate;                                                // 0x0098(0x0008) (Edit)
	struct FDateTime                                   EndDate;                                                  // 0x00A0(0x0008) (Edit)
};

// ScriptStruct FortniteGame.PooledDamageNumberComponents
// 0x0010
struct FPooledDamageNumberComponents
{
	TArray<class UStaticMeshComponent*>                Components;                                               // 0x0000(0x0010) (ExportObject, ZeroConstructor, Transient)
};

// ScriptStruct FortniteGame.LiveDamageNumberComponent
// 0x0018
struct FLiveDamageNumberComponent
{
	class UStaticMeshComponent*                        Component;                                                // 0x0000(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0008(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.DecoPlacementState
// 0x0080
struct FDecoPlacementState
{
	struct FVector                                     Start;                                                    // 0x0000(0x000C) (IsPlainOldData)
	struct FVector                                     End;                                                      // 0x000C(0x000C) (IsPlainOldData)
	struct FVector                                     RawLocation;                                              // 0x0018(0x000C) (IsPlainOldData)
	struct FVector                                     Normal;                                                   // 0x0024(0x000C) (IsPlainOldData)
	struct FQuat                                       AbsoluteRotation;                                         // 0x0030(0x0010) (IsPlainOldData)
	struct FVector                                     GridLocation;                                             // 0x0040(0x000C) (IsPlainOldData)
	struct FVector                                     PreviousLocation;                                         // 0x004C(0x000C) (IsPlainOldData)
	struct FVector                                     FallbackLocation;                                         // 0x0058(0x000C) (IsPlainOldData)
	TWeakObjectPtr<class AActor>                       LastHitActor;                                             // 0x0064(0x0008) (ZeroConstructor, IsPlainOldData)
	TWeakObjectPtr<class ABuildingSMActor>             CurrentBuildingActorAttachment;                           // 0x006C(0x0008) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortDecoPlacementQueryResults>        CanPlaceState;                                            // 0x0074(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0xB];                                       // 0x0075(0x000B) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortTierProgressionInfo
// 0x0018
struct FFortTierProgressionInfo
{
	struct FString                                     ProgressionLayoutGuid;                                    // 0x0000(0x0010) (ZeroConstructor)
	int                                                HighestDefeatedTier;                                      // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortTierProgression
// 0x0010
struct FFortTierProgression
{
	TArray<struct FFortTierProgressionInfo>            ProgressionInfo;                                          // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.TieredModifierSetData
// 0x0010
struct FTieredModifierSetData
{
	int                                                WaveNumber;                                               // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                ModifierDuration;                                         // 0x0004(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	struct FName                                       ModifierLootTierGroup;                                    // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
};

// ScriptStruct FortniteGame.GameDifficultyInfo
// 0x0078 (0x0080 - 0x0008)
struct FGameDifficultyInfo : public FTableRowBase
{
	int                                                ContentAccountLevel;                                      // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Difficulty;                                               // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DifficultyMatchmakingMinOverride;                         // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DifficultyMatchmakingMaxOverride;                         // 0x0014(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                LootLevel;                                                // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                RequiredRating;                                           // 0x001C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                PvPRating;                                                // 0x0020(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                RecommendedRating;                                        // 0x0024(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ScoreBonus;                                               // 0x0028(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	struct FString                                     LootTierGroup;                                            // 0x0030(0x0010) (Edit, ZeroConstructor)
	struct FString                                     BonusLootTierGroup;                                       // 0x0040(0x0010) (Edit, ZeroConstructor)
	struct FText                                       ThreatDisplayName;                                        // 0x0050(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FName                                       ColorParamName;                                           // 0x0068(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                DefaultPlayerLives;                                       // 0x0070(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0074(0x0004) MISSED OFFSET
	struct FName                                       PlayerStatClampRowName;                                   // 0x0078(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.ActiveGameplayModifierHandle
// 0x0004
struct FActiveGameplayModifierHandle
{
	int                                                Handle;                                                   // 0x0000(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.ActiveTieredCollectionLayout
// 0x0014 (0x0020 - 0x000C)
struct FActiveTieredCollectionLayout : public FFastArraySerializerItem
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	class UFortTieredCollectionLayout*                 Layout;                                                   // 0x0010(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                MaxTierUnlocked;                                          // 0x0018(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      bLocked : 1;                                              // 0x001C(0x0001) (Transient)
	unsigned char                                      UnknownData01[0x3];                                       // 0x001D(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.ActiveTieredCollectionLayoutArray
// 0x0018 (0x00C8 - 0x00B0)
struct FActiveTieredCollectionLayoutArray : public FFastArraySerializer
{
	TArray<struct FActiveTieredCollectionLayout>       LayoutArray;                                              // 0x00B0(0x0010) (ZeroConstructor, Transient)
	bool                                               bTiersForced;                                             // 0x00C0(0x0001) (ZeroConstructor, Transient, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00C1(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.DeployableBaseInstance
// 0x000C (0x0018 - 0x000C)
struct FDeployableBaseInstance : public FFastArraySerializerItem
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	class ADeployableBasePlot*                         DeployableBase;                                           // 0x0010(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.DeployableBaseArray
// 0x0010 (0x00C0 - 0x00B0)
struct FDeployableBaseArray : public FFastArraySerializer
{
	TArray<struct FDeployableBaseInstance>             DeployableBases;                                          // 0x00B0(0x0010) (ZeroConstructor, Transient)
};

// ScriptStruct FortniteGame.FortUserCloudRequestHandle
// 0x0008
struct FFortUserCloudRequestHandle
{
	uint64_t                                           Handle;                                                   // 0x0000(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.PendingDeployableBaseUser
// 0x0040
struct FPendingDeployableBaseUser
{
	struct FUniqueNetIdRepl                            UserNetID;                                                // 0x0000(0x0028)
	struct FFortUserCloudRequestHandle                 LoadingCloudRequestHandle;                                // 0x0028(0x0008)
	class UFortDeployableBaseRecord*                   BaseRecord;                                               // 0x0030(0x0008) (ZeroConstructor, IsPlainOldData)
	class ADeployableBasePlot*                         BasePlot;                                                 // 0x0038(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.PendingDeployableManagerAction
// 0x0070
struct FPendingDeployableManagerAction
{
	EQueueActionType                                   ActionType;                                               // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<class ADeployableBasePlot*>                 PendingPlots;                                             // 0x0008(0x0010) (ZeroConstructor)
	int                                                CurrentPlotRunningIndex;                                  // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	EDeployableBaseBuildingState                       DesiredPlotState;                                         // 0x001C(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x43];                                      // 0x001D(0x0043) MISSED OFFSET
	class AFortDeployableBaseManager*                  Manager;                                                  // 0x0060(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0068(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.EnvironmentBuildingRestorationRecord
// 0x0050
struct FEnvironmentBuildingRestorationRecord
{
	class UClass*                                      ActorClass;                                               // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0008(0x0008) MISSED OFFSET
	struct FTransform                                  ActorTransform;                                           // 0x0010(0x0030) (IsPlainOldData)
	struct FName                                       QuotaSelectedLootTierKey;                                 // 0x0040(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                QuotaSelectedLootTier;                                    // 0x0048(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.AvailableTierLayout
// 0x0030
struct FAvailableTierLayout
{
	class UFortTieredCollectionLayout*                 Layout;                                                   // 0x0000(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TArray<struct FFortTierCollectionLayoutOutput>     AvailableTiers;                                           // 0x0008(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FFortTierCollectionLayoutOutput>     LockedTiers;                                              // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	unsigned char                                      bLocked : 1;                                              // 0x0028(0x0001) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortPickupLocationData
// 0x0060
struct FFortPickupLocationData
{
	class AFortPawn*                                   PickupTarget;                                             // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	class AFortPickup*                                 CombineTarget;                                            // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	class AFortPawn*                                   ItemOwner;                                                // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FVector_NetQuantize10                       LootInitialPosition;                                      // 0x0018(0x000C)
	struct FVector_NetQuantize10                       LootFinalPosition;                                        // 0x0024(0x000C)
	float                                              FlyTime;                                                  // 0x0030(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector_NetQuantizeNormal                   StartDirection;                                           // 0x0034(0x000C)
	struct FVector_NetQuantize10                       FinalTossRestLocation;                                    // 0x0040(0x000C)
	EFortPickupTossState                               TossState;                                                // 0x004C(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x004D(0x0003) MISSED OFFSET
	struct FGuid                                       PickupGuid;                                               // 0x0050(0x0010) (IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
};

// ScriptStruct FortniteGame.FortTaggedUnlockBase
// 0x0008
struct FFortTaggedUnlockBase
{
	struct FGameplayTag                                RequiredTag;                                              // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortTaggedDeployableBasePlotExpansionUnlock
// 0x0010 (0x0018 - 0x0008)
struct FFortTaggedDeployableBasePlotExpansionUnlock : public FFortTaggedUnlockBase
{
	struct FIntVector                                  CellExpansionVector;                                      // 0x0008(0x000C) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortTaggedDeployableBaseLootUnlock
// 0x0008 (0x0010 - 0x0008)
struct FFortTaggedDeployableBaseLootUnlock : public FFortTaggedUnlockBase
{
	struct FName                                       LootTierGroup;                                            // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortEncounterLockedUtility
// 0x0002
struct FFortEncounterLockedUtility
{
	TEnumAsByte<EFortAIUtility>                        Utility;                                                  // 0x0000(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TEnumAsByte<EFortEncounterUtilityDesire>           UtilityDesire;                                            // 0x0001(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortCriteriaRequirementData
// 0x0018 (0x0020 - 0x0008)
struct FFortCriteriaRequirementData : public FTableRowBase
{
	struct FGameplayTag                                RequiredTag;                                              // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, EditConst)
	bool                                               bGlobalMod;                                               // 0x0010(0x0001) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	float                                              ModValue;                                                 // 0x0014(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	bool                                               bRequireRarity;                                           // 0x0018(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	EFortRarity                                        RequiredRarity;                                           // 0x0019(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x001A(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.ItemAndCount
// 0x0010
struct FItemAndCount
{
	int                                                Count;                                                    // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	class UFortItemDefinition*                         Item;                                                     // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortFeedbackResponse
// 0x0020
struct FFortFeedbackResponse
{
	struct FFortFeedbackHandle                         Handle;                                                   // 0x0000(0x0018) (Edit)
	TEnumAsByte<EFortFeedbackContext>                  Context;                                                  // 0x0018(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortFeedbackLine
// 0x0098
struct FFortFeedbackLine
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortFeedbackLine.Audio
	unsigned char                                      UnknownData01[0x28];                                      // 0x0028(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortFeedbackLine.AnimSequence
	unsigned char                                      UnknownData02[0x28];                                      // 0x0050(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortFeedbackLine.AnimMontage
	TEnumAsByte<EFortFeedbackAddressee>                Addressee;                                                // 0x0078(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortFeedbackContext>                  Context;                                                  // 0x0079(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x6];                                       // 0x007A(0x0006) MISSED OFFSET
	TArray<struct FFortFeedbackResponse>               ResponseEvents;                                           // 0x0080(0x0010) (Edit, ZeroConstructor)
	bool                                               bInterruptCurrentLine;                                    // 0x0090(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bCanBeInterrupted;                                        // 0x0091(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bCanQue;                                                  // 0x0092(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData04[0x5];                                       // 0x0093(0x0005) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortFeedbackAction
// 0x0030
struct FFortFeedbackAction
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
	struct FFortFeedbackHandle                         Handle;                                                   // 0x0008(0x0018) (Edit)
	TArray<struct FFortFeedbackLine>                   Lines;                                                    // 0x0020(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortFeedbackActionBankDefined
// 0x0008 (0x0038 - 0x0030)
struct FFortFeedbackActionBankDefined : public FFortFeedbackAction
{
	float                                              MinReplayTime;                                            // 0x0030(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MinReplayTimeForSpeaker;                                  // 0x0034(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortFeedbackEventData
// 0x0038
struct FFortFeedbackEventData
{
	struct FFortFeedbackHandle                         Handle;                                                   // 0x0000(0x0018) (Edit)
	float                                              ChanceToPlay;                                             // 0x0018(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MinReplayTime;                                            // 0x001C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MinReplayTimeForSpeaker;                                  // 0x0020(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MaxWitnessDistance;                                       // 0x0024(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bInterruptCurrentLine;                                    // 0x0028(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bCanBeInterrupted;                                        // 0x0029(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bCanQue;                                                  // 0x002A(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortFeedbackBroadcastFilter>          MultiplayerBroadcastFilter;                               // 0x002B(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortFeedbackSelectionMethod>          ContextSelectionMethod;                                   // 0x002C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x002D(0x0003) MISSED OFFSET
	float                                              FeedbackDelay;                                            // 0x0030(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              TimeLastPlayed;                                           // 0x0034(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortFootstepAudioData
// 0x0040
struct FFortFootstepAudioData
{
	class USoundBase*                                  SoundAssets[0x6];                                         // 0x0000(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class USoundAttenuation*                           SoundAttenuation;                                         // 0x0030(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              VolumeMultiplier;                                         // 0x0038(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.ActiveFortCamera
// 0x0020
struct FActiveFortCamera
{
	class UFortCameraMode*                             Camera;                                                   // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	class AActor*                                      ViewTarget;                                               // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	float                                              TransitionAlpha;                                          // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              TransitionUpdateRate;                                     // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              BlendWeight;                                              // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortCameraInstanceEntry
// 0x0018
struct FFortCameraInstanceEntry
{
	class UClass*                                      CameraClass;                                              // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	class AActor*                                      ViewTarget;                                               // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	class UFortCameraMode*                             Camera;                                                   // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortCameraModeOverride
// 0x0010
struct FFortCameraModeOverride
{
	class UClass*                                      OriginalClass;                                            // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UClass*                                      ClassOverride;                                            // 0x0008(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortCameraPrototype
// 0x0028
struct FFortCameraPrototype
{
	struct FName                                       PrototypeName;                                            // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FString                                     PrototypeDescription;                                     // 0x0008(0x0010) (Edit, ZeroConstructor)
	TArray<struct FFortCameraModeOverride>             ModeOverrides;                                            // 0x0018(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortFXAnimationInfoBase
// 0x0018
struct FFortFXAnimationInfoBase
{
	class UCurveFloat*                                 LerpCurve;                                                // 0x0000(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0008(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortSplineMeshScaleAnimationInfo
// 0x0010 (0x0028 - 0x0018)
struct FFortSplineMeshScaleAnimationInfo : public FFortFXAnimationInfoBase
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0018(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortSplineMeshSnapAnimationInfo
// 0x0010 (0x0028 - 0x0018)
struct FFortSplineMeshSnapAnimationInfo : public FFortFXAnimationInfoBase
{
	class USplineComponent*                            TargetSpline;                                             // 0x0018(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0020(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortSplineMeshAnimSet
// 0x0030
struct FFortSplineMeshAnimSet
{
	class USplineMeshComponent*                        SplineMesh;                                               // 0x0000(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	TArray<struct FFortSplineMeshScaleAnimationInfo>   ScaleAnims;                                               // 0x0008(0x0010) (ZeroConstructor, Transient)
	TArray<struct FFortSplineMeshSnapAnimationInfo>    SnapAnims;                                                // 0x0018(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortFloatAnimationInfo
// 0x0008 (0x0020 - 0x0018)
struct FFortFloatAnimationInfo : public FFortFXAnimationInfoBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0018(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortFloatParamAnimationInfo
// 0x0008 (0x0028 - 0x0020)
struct FFortFloatParamAnimationInfo : public FFortFloatAnimationInfo
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0020(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortLinearColorAnimationInfo
// 0x0020 (0x0038 - 0x0018)
struct FFortLinearColorAnimationInfo : public FFortFXAnimationInfoBase
{
	unsigned char                                      UnknownData00[0x20];                                      // 0x0018(0x0020) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortLinearColorParamAnimationInfo
// 0x0008 (0x0040 - 0x0038)
struct FFortLinearColorParamAnimationInfo : public FFortLinearColorAnimationInfo
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortLinearColorCurveAnimationInfo
// 0x0010 (0x0028 - 0x0018)
struct FFortLinearColorCurveAnimationInfo : public FFortFXAnimationInfoBase
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0018(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortLinearColorCurveParamAnimationInfo
// 0x0008 (0x0030 - 0x0028)
struct FFortLinearColorCurveParamAnimationInfo : public FFortLinearColorCurveAnimationInfo
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortMIDAnimSet
// 0x0040
struct FFortMIDAnimSet
{
	class UMaterialInstanceDynamic*                    Mid;                                                      // 0x0000(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TArray<struct FFortFloatParamAnimationInfo>        FloatParamAnims;                                          // 0x0008(0x0010) (ZeroConstructor, Transient)
	TArray<struct FFortLinearColorParamAnimationInfo>  ColorParamAnims;                                          // 0x0018(0x0010) (ZeroConstructor, Transient)
	TArray<struct FFortLinearColorCurveParamAnimationInfo> ColorCurveParamAnims;                                     // 0x0028(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortParticleAnimSet
// 0x0020
struct FFortParticleAnimSet
{
	class UParticleSystemComponent*                    PSC;                                                      // 0x0000(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	TArray<struct FFortFloatParamAnimationInfo>        ParamAnims;                                               // 0x0008(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0018(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortLightAnimSet
// 0x0020
struct FFortLightAnimSet
{
	class ULightComponent*                             LightComp;                                                // 0x0000(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	TArray<struct FFortFloatAnimationInfo>             IntensityAnims;                                           // 0x0008(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0018(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.QuickBarSlotData
// 0x0040
struct FQuickBarSlotData
{
	TArray<EFortItemType>                              AcceptedItemTypes;                                        // 0x0000(0x0010) (Edit, ZeroConstructor)
	bool                                               bStaticSlot;                                              // 0x0010(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0011(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.QuickBarSlotData.DefaultItem
};

// ScriptStruct FortniteGame.QuickBarData
// 0x0010
struct FQuickBarData
{
	TArray<struct FQuickBarSlotData>                   QuickbarSlots;                                            // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortHighlightColors
// 0x0030
struct FFortHighlightColors
{
	struct FLinearColor                                OutlineColor;                                             // 0x0000(0x0010) (Edit, IsPlainOldData)
	struct FLinearColor                                SceneModulationColor1;                                    // 0x0010(0x0010) (Edit, IsPlainOldData)
	struct FLinearColor                                SceneModulationColor2;                                    // 0x0020(0x0010) (Edit, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortHighlightColorsContainer
// 0x0060
struct FFortHighlightColorsContainer
{
	struct FFortHighlightColors                        ValidHighlight;                                           // 0x0000(0x0030) (Edit)
	struct FFortHighlightColors                        InvalidHighlight;                                         // 0x0030(0x0030) (Edit)
};

// ScriptStruct FortniteGame.FortReplicatedStatMapping
// 0x0020
struct FFortReplicatedStatMapping
{
	EStatCategory                                      StatCategory;                                             // 0x0000(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FText                                       DisplayName;                                              // 0x0008(0x0018) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.KeybindIcon
// 0x02E8
struct FKeybindIcon
{
	struct FKey                                        Key;                                                      // 0x0000(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FFortMultiSizeBrush                         Brush;                                                    // 0x0018(0x02D0) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.SubGameInfo
// 0x0010
struct FSubGameInfo
{
	class UFortTokenType*                              AccessToken;                                              // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               RequiredFullInstall;                                      // 0x0008(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortPlayerSpawnPadPlacementData
// 0x0058
struct FFortPlayerSpawnPadPlacementData
{
	class UEnvQuery*                                   PlacementQuery;                                           // 0x0000(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0008(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.FortPlayerSpawnPadPlacementData.ActorToPlace
	bool                                               bSnapToGrid;                                              // 0x0030(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bAdjustPlacementForFloors;                                // 0x0031(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x0032(0x0006) MISSED OFFSET
	struct FGameplayTagContainer                       TagsToAddToChosenPlacementActor;                          // 0x0038(0x0020) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.SoundPerResourceLevel
// 0x0030
struct FSoundPerResourceLevel
{
	class USoundBase*                                  Sounds[0x6];                                              // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortQuestPackInfo
// 0x0030
struct FFortQuestPackInfo
{
	struct FString                                     Name;                                                     // 0x0000(0x0010) (Edit, ZeroConstructor)
	struct FString                                     DefaultQuestPack;                                         // 0x0010(0x0010) (Edit, ZeroConstructor)
	int                                                MaxActiveDailyQuests;                                     // 0x0020(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                MaxRerollsPerDay;                                         // 0x0024(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               IsStreamingQuestPack;                                     // 0x0028(0x0001) (Edit, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.ConditionalFoundationQuotaTier
// 0x0018
struct FConditionalFoundationQuotaTier
{
	TArray<class UClass*>                              FoundationClasses;                                        // 0x0000(0x0010) (Edit, ZeroConstructor)
	int                                                MinFoundations;                                           // 0x0010(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                MaxFoundations;                                           // 0x0014(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.ConditionalFoundationQuota
// 0x0010
struct FConditionalFoundationQuota
{
	TArray<struct FConditionalFoundationQuotaTier>     Tiers;                                                    // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct FortniteGame.SettingsHUDVisibilityAndText
// 0x0048
struct FSettingsHUDVisibilityAndText
{
	struct FGameplayTag                                HUDVisibilityGameplayTag;                                 // 0x0000(0x0008) (Edit, DisableEditOnInstance)
	ESlateVisibility                                   DefaultHUDVisibility;                                     // 0x0008(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
	struct FText                                       DisplayText;                                              // 0x0010(0x0018) (Edit, DisableEditOnInstance)
	struct FText                                       ToolTipText;                                              // 0x0028(0x0018) (Edit, DisableEditOnInstance)
	bool                                               bHideOnConsolePlatforms;                                  // 0x0040(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0041(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.ItemDefinitionAndCount
// 0x0030
struct FItemDefinitionAndCount
{
	int                                                Count;                                                    // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0004(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.ItemDefinitionAndCount.ItemDefinition
};

// ScriptStruct FortniteGame.FortAbilityTagRelationship
// 0x0048
struct FFortAbilityTagRelationship
{
	struct FGameplayTag                                AbilityTag;                                               // 0x0000(0x0008) (Edit)
	struct FGameplayTagContainer                       AbilityTagsToBlock;                                       // 0x0008(0x0020) (Edit)
	struct FGameplayTagContainer                       AbilityTagsToCancel;                                      // 0x0028(0x0020) (Edit)
};

// ScriptStruct FortniteGame.UISoundFeedback
// 0x0008
struct FUISoundFeedback
{
	class USoundBase*                                  UISound;                                                  // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.AthenaPlaylistDataTableSet
// 0x0040
struct FAthenaPlaylistDataTableSet
{
	struct FString                                     Description;                                              // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                PlaylistId;                                               // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	class UDataTable*                                  LootTierData;                                             // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UDataTable*                                  LootPackages;                                             // 0x0020(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UDataTable*                                  RangedWeapons;                                            // 0x0028(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCurveTable*                                 GameData;                                                 // 0x0030(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCurveTable*                                 ResourceRates;                                            // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.TeamFOBRequiredTags
// 0x0028
struct FTeamFOBRequiredTags
{
	struct FGameplayTagContainer                       RequiredFOBSpawnTags;                                     // 0x0000(0x0020) (Edit, DisableEditOnInstance)
	TEnumAsByte<EFortTeam>                             Team;                                                     // 0x0020(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.CachedPlayerFOBInformation
// 0x0030
struct FCachedPlayerFOBInformation
{
	struct FUniqueNetIdRepl                            PlayerID;                                                 // 0x0000(0x0028) (Transient)
	TEnumAsByte<EFortTeam>                             Team;                                                     // 0x0028(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.ScorePlacementTable
// 0x0040
struct FScorePlacementTable
{
	TArray<float>                                      Solo;                                                     // 0x0000(0x0010) (ZeroConstructor)
	TArray<float>                                      Duos;                                                     // 0x0010(0x0010) (ZeroConstructor)
	TArray<float>                                      Squads;                                                   // 0x0020(0x0010) (ZeroConstructor)
	TArray<float>                                      FiftyFifty;                                               // 0x0030(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortPlacedBuilding
// 0x0020
struct FFortPlacedBuilding
{
	struct FString                                     BuildingTag;                                              // 0x0000(0x0010) (ZeroConstructor)
	struct FString                                     PlacedTag;                                                // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortOutpostCoreInfo
// 0x0020
struct FFortOutpostCoreInfo
{
	TArray<struct FFortPlacedBuilding>                 PlacedBuildings;                                          // 0x0000(0x0010) (ZeroConstructor)
	TArray<struct FString>                             AccountsWithEditPermission;                               // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortAthenaGamepadAimAssistSettings
// 0x00B0
struct FFortAthenaGamepadAimAssistSettings
{
	class UCurveFloat*                                 TargetWeightCurve;                                        // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              TargetWeightScale;                                        // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              TargetDBNOWeightScale;                                    // 0x000C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat*                                 PullStrengthYawCurve;                                     // 0x0010(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat*                                 PullStrengthPitchCurve;                                   // 0x0018(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat*                                 PullStrengthScalarForFOVCurve;                            // 0x0020(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              PullMaxRate;                                              // 0x0028(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	class UCurveFloat*                                 SlowStrengthYawCurve;                                     // 0x0030(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat*                                 SlowStrengthPitchCurve;                                   // 0x0038(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat*                                 SlowStrengthScalarForFOVCurve;                            // 0x0040(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              SlowDecayTime;                                            // 0x0048(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	struct FFortAbilityTargetSelection                 TargetSelection;                                          // 0x0050(0x0060) (Edit)
};

// ScriptStruct FortniteGame.FortAthenaGamepadLookSettings
// 0x00C0
struct FFortAthenaGamepadLookSettings
{
	class UCurveFloat*                                 GamepadLookYawCurves[0xA];                                // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat*                                 GamepadLookPitchCurves[0xA];                              // 0x0050(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   GamepadLookScale;                                         // 0x00A0(0x0008) (Edit, IsPlainOldData)
	float                                              GamepadLookScaleDownsightsDecayTime;                      // 0x00A8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector2D                                   GamepadLookAccelTime;                                     // 0x00AC(0x0008) (Edit, IsPlainOldData)
	struct FVector2D                                   GamepadLookDecelTime;                                     // 0x00B4(0x0008) (Edit, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00BC(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortGameplayEffectContainer
// 0x0088
struct FFortGameplayEffectContainer
{
	struct FGameplayTag                                ApplicationTag;                                           // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FFortAbilityTargetSelectionList             TargetSelection;                                          // 0x0008(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	TArray<class UClass*>                              TargetGameplayEffectClasses;                              // 0x0028(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<class UClass*>                              OwnerGameplayEffectClasses;                               // 0x0038(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FGameplayTagContainer                       ActivationCues;                                           // 0x0048(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FGameplayTagContainer                       ImpactCues;                                               // 0x0068(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.FortAbilityCost
// 0x0040
struct FFortAbilityCost
{
	EFortAbilityCostSource                             CostSource;                                               // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FScalableFloat                              CostValue;                                                // 0x0008(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly)
	class UFortItemDefinition*                         ItemDefinition;                                           // 0x0030(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bOnlyApplyCostOnHit;                                      // 0x0038(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.TurnFloatRange
// 0x0008
struct FTurnFloatRange
{
	float                                              Min;                                                      // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              Max;                                                      // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.TurnTransitionData
// 0x0048
struct FTurnTransitionData
{
	struct FName                                       MontageSectionName;                                       // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MinYawAngle;                                              // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MaxYawAngle;                                              // 0x000C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              TurnRate;                                                 // 0x0010(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FGameplayTagContainer                       RequiredGameplayTags;                                     // 0x0018(0x0020) (Edit)
	int                                                PriorityLevel;                                            // 0x0038(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FTurnFloatRange                             SpeedConstraintRange;                                     // 0x003C(0x0008) (Edit, IsPlainOldData)
	bool                                               bEnableSpeedConstraint;                                   // 0x0044(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bSkipTransitionInCrowd;                                   // 0x0045(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x0046(0x0002) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortParticleSystemParamBucket
// 0x0010
struct FFortParticleSystemParamBucket
{
	TArray<struct FParticleSysParam>                   Parameters;                                               // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortGameplayEffectDeliveryInfo
// 0x00A8
struct FFortGameplayEffectDeliveryInfo
{
	struct FFortDeliveryInfoRequirementsFilter         DeliveryRequirements;                                     // 0x0000(0x0098) (Edit, DisableEditOnInstance)
	TArray<struct FGameplayEffectApplicationInfo>      GameplayEffects;                                          // 0x0098(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortHostSessionParams
// 0x0010
struct FFortHostSessionParams
{
	struct FName                                       SessionName;                                              // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                ControllerId;                                             // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortDisconnectedPlayerReservation
// 0x0038
struct FFortDisconnectedPlayerReservation
{
	struct FName                                       SessionName;                                              // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FUniqueNetIdRepl                            PlayerID;                                                 // 0x0008(0x0028)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.OnTimeHitInfo
// 0x0030
struct FOnTimeHitInfo
{
	struct FScriptDelegate                             TimeCallback;                                             // 0x0000(0x0010) (ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x20];                                      // 0x0010(0x0020) MISSED OFFSET
};

// ScriptStruct FortniteGame.TeamChangeRequest
// 0x0010
struct FTeamChangeRequest
{
	class AFortPlayerController*                       RequestingController;                                     // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortTeam>                             DesiredTeam;                                              // 0x0008(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.AppliedHomebaseData
// 0x0030
struct FAppliedHomebaseData
{
	class UAbilitySystemComponent*                     Source;                                                   // 0x0000(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	class UAbilitySystemComponent*                     Target;                                                   // 0x0008(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	TArray<struct FActiveGameplayEffectHandle>         AppliedEffects;                                           // 0x0010(0x0010) (ZeroConstructor, Transient)
	TArray<struct FFortAbilitySetHandle>               AppliedAbilitySets;                                       // 0x0020(0x0010) (ZeroConstructor, Transient)
};

// ScriptStruct FortniteGame.ReplicatedStatValues
// 0x0008
struct FReplicatedStatValues
{
	int                                                StatValue;                                                // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                ScoreValue;                                               // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortExperienceDelta
// 0x0024
struct FFortExperienceDelta
{
	int                                                Level;                                                    // 0x0000(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Xp;                                                       // 0x0004(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                BaseXPEarned;                                             // 0x0008(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                BonusXPEarned;                                            // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                BoostXPEarned;                                            // 0x0010(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                BoostXPMissed;                                            // 0x0014(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                RestXPEarned;                                             // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                GroupBoostXPEarned;                                       // 0x001C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFortIsFinalXpUpdate                               IsFinalXpUpdate;                                          // 0x0020(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0021(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortPlayerScoreReport
// 0x0298
struct FFortPlayerScoreReport
{
	struct FUniqueNetIdRepl                            PlayerID;                                                 // 0x0000(0x0028) (BlueprintVisible, BlueprintReadOnly)
	struct FString                                     PlayerName;                                               // 0x0028(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TWeakObjectPtr<class AFortPlayerState>             PlayerState;                                              // 0x0038(0x0008) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortTeam>                             PlayerTeam;                                               // 0x0040(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0041(0x0003) MISSED OFFSET
	struct FReplicatedStatValues                       ReplicatedStats_Campaign[0x22];                           // 0x0044(0x0008)
	struct FReplicatedStatValues                       ReplicatedStats_Zone[0x22];                               // 0x0154(0x0008)
	int                                                InitialLevel;                                             // 0x0264(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                InitialExperienceAmount;                                  // 0x0268(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FFortExperienceDelta                        ExperienceInfoDelta;                                      // 0x026C(0x0024)
	int                                                LastExperienceDeltaAmount;                                // 0x0290(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                LastScoreDeltaAmount;                                     // 0x0294(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.EndOfDayRecap
// 0x0020
struct FEndOfDayRecap
{
	int                                                DayNumber;                                                // 0x0000(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                TeamScoreAtStartOfDay;                                    // 0x0004(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                TeamScoreAtEndOfDay;                                      // 0x0008(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	TArray<struct FFortPlayerScoreReport>              ScoreReports;                                             // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.ActiveGameplayModifier
// 0x00CC (0x00D8 - 0x000C)
struct FActiveGameplayModifier : public FFastArraySerializerItem
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	class UFortGameplayModifierItemDefinition*         ModifierDef;                                              // 0x0010(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	struct FActiveGameplayModifierHandle               ModifierHandle;                                           // 0x0018(0x0004) (Transient, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	TArray<class AFortGameplayMutator*>                Mutators;                                                 // 0x0020(0x0010) (ZeroConstructor, Transient, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	int                                                Expiration;                                               // 0x0030(0x0004) (ZeroConstructor, Transient, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	unsigned char                                      UnknownData02[0xA4];                                      // 0x0034(0x00A4) MISSED OFFSET
};

// ScriptStruct FortniteGame.ActiveGameplayModifierArray
// 0x0018 (0x00C8 - 0x00B0)
struct FActiveGameplayModifierArray : public FFastArraySerializer
{
	TArray<struct FActiveGameplayModifier>             Items;                                                    // 0x00B0(0x0010) (ZeroConstructor, Transient)
	int                                                ModifierHandleGenerator;                                  // 0x00C0(0x0004) (ZeroConstructor, Transient, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	bool                                               bSupportRuntimeModifierShutdown;                          // 0x00C4(0x0001) (ZeroConstructor, Transient, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	unsigned char                                      UnknownData00[0x3];                                       // 0x00C5(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.PlayerBuildableClassContainer
// 0x0010
struct FPlayerBuildableClassContainer
{
	TArray<class UClass*>                              BuildingClasses;                                          // 0x0000(0x0010) (ZeroConstructor, Transient)
};

// ScriptStruct FortniteGame.Voter
// 0x0030
struct FVoter
{
	int                                                VoteDecision;                                             // 0x0000(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FUniqueNetIdRepl                            NetId;                                                    // 0x0008(0x0028) (Transient)
};

// ScriptStruct FortniteGame.HordeDifficultyTierInfo
// 0x0010
struct FHordeDifficultyTierInfo
{
	struct FName                                       DifficultyTierName;                                       // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UFortQuestItemDefinition*                    QuestPrerequisite;                                        // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.PermaniteBoundariesInfo
// 0x0014
struct FPermaniteBoundariesInfo
{
	int                                                MaxPermaniteStructures;                                   // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                TotalPermaniteStructures;                                 // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              AveragePermaniteStructureLevel;                           // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MinPermaniteStructureLevel;                               // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MaxPermaniteStructureLevel;                               // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.LoginFailureLogSubmitOptions
// 0x0018
struct FLoginFailureLogSubmitOptions
{
	bool                                               bSubmitLogs;                                              // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                LogTailKb;                                                // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	TArray<ELoginResult>                               DoNotUploadReasons;                                       // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.PurchaseFailureLogSubmitOptions
// 0x0018
struct FPurchaseFailureLogSubmitOptions
{
	bool                                               bSubmitLogs;                                              // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                LogTailKb;                                                // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	TArray<struct FString>                             DoNotUploadReasons;                                       // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.PartyFailureLogSubmitReason
// 0x0020
struct FPartyFailureLogSubmitReason
{
	struct FString                                     Reason;                                                   // 0x0000(0x0010) (ZeroConstructor)
	struct FString                                     SubReason;                                                // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.PartyFailureLogSubmit
// 0x0018
struct FPartyFailureLogSubmit
{
	bool                                               bSubmitLogs;                                              // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                LogTailKb;                                                // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	TArray<struct FPartyFailureLogSubmitReason>        Reasons;                                                  // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.SubGameAccess
// 0x0003
struct FSubGameAccess
{
	ESubGame                                           SubGame;                                                  // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	ESubGameAccessStatus                               AccessStatus;                                             // 0x0001(0x0001) (ZeroConstructor, IsPlainOldData)
	ESubGameMatchmakingStatus                          MatchmakingStatus;                                        // 0x0002(0x0001) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortSavedModeLoadout
// 0x0020
struct FFortSavedModeLoadout
{
	struct FString                                     LoadoutName;                                              // 0x0000(0x0010) (ZeroConstructor)
	TArray<struct FString>                             SelectedGadgets;                                          // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.HeroSpecializationAttributeRequirement
// 0x0028
struct FHeroSpecializationAttributeRequirement
{
	struct FGameplayAttribute                          Attribute;                                                // 0x0000(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	float                                              MinimumValue;                                             // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortSpecializationSlot
// 0x0088
struct FFortSpecializationSlot
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortSpecializationSlot.GrantedAbilityKit
	unsigned char                                      UnknownData01[0x28];                                      // 0x0028(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortSpecializationSlot.RemovedAbilityKit
	TArray<struct FHeroSpecializationAttributeRequirement> AttributeRequirements;                                    // 0x0050(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	struct FGameplayTagContainer                       RequiredTags;                                             // 0x0060(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	int                                                MinimumHeroLevel;                                         // 0x0080(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0084(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.HeroAbilityKit
// 0x0050
struct FHeroAbilityKit
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.HeroAbilityKit.InherentAbilityKit
	struct FGameplayTagContainer                       RequiredGPTags;                                           // 0x0028(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	bool                                               bShowInAbilityScreen;                                     // 0x0048(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.HeroItem
// 0x0078
struct FHeroItem
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.HeroItem.Item
	int                                                Quantity;                                                 // 0x0028(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortReplenishmentType>                Replenishment;                                            // 0x002C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x002D(0x0003) MISSED OFFSET
	struct FGameplayTagContainer                       RequiredGPTags;                                           // 0x0030(0x0020) (Edit)
	struct FGameplayTagContainer                       SwapTag;                                                  // 0x0050(0x0020) (Edit)
	bool                                               bShowInAbilityScreen;                                     // 0x0070(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0071(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.HomebaseSquadAttributeBonus
// 0x0030
struct FHomebaseSquadAttributeBonus
{
	struct FGameplayAttribute                          AttributeGranted;                                         // 0x0000(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FCurveTableRowHandle                        BonusCurve;                                               // 0x0020(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.HomebaseSquadSlot
// 0x0060
struct FHomebaseSquadSlot
{
	struct FText                                       DisplayName;                                              // 0x0000(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	TArray<EFortItemType>                              ValidSlottableItemTypes;                                  // 0x0018(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FGameplayTagContainer                       TagFilter;                                                // 0x0028(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	TArray<struct FHomebaseSquadAttributeBonus>        SlottingBonuses;                                          // 0x0048(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	class UCurveTable*                                 PersonalityMatchBonusTable;                               // 0x0058(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.HomebaseSquad
// 0x0080 (0x0088 - 0x0008)
struct FHomebaseSquad : public FTableRowBase
{
	struct FText                                       DisplayName;                                              // 0x0008(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FText                                       ShortDisplayName;                                         // 0x0020(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	EFortHomebaseSquadType                             SquadType;                                                // 0x0038(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	struct FGameplayTag                                ManagerSynergyTag;                                        // 0x0040(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	TArray<struct FHomebaseSquadSlot>                  CrewSlots;                                                // 0x0048(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FGameplayTagContainer                       RequiredTheaterTags;                                      // 0x0058(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	int                                                MaxNumDefendersAllowedInLevel;                            // 0x0078(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaxNumDefendersAllowedInGroupLevel;                       // 0x007C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bConsiderNumPlayersForMaxNumDefenders;                    // 0x0080(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bAlwaysRemoveOldestDefenderWhenReplacing;                 // 0x0081(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x0082(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.HomebaseNodePage
// 0x0058 (0x0060 - 0x0008)
struct FHomebaseNodePage : public FTableRowBase
{
	struct FText                                       DisplayName;                                              // 0x0008(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FText                                       Description;                                              // 0x0020(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FString                                     EventID;                                                  // 0x0038(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int                                                PositionIndex;                                            // 0x0048(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	TArray<struct FName>                               NodeList;                                                 // 0x0050(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.HomebaseNodeInstancePrerequisites
// 0x0020
struct FHomebaseNodeInstancePrerequisites
{
	struct FName                                       NodeInstanceId;                                           // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bHideConnection;                                          // 0x0008(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
	struct FName                                       PrereqPageId;                                             // 0x0010(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EPrereqNodeType                                    PrereqNodeType;                                           // 0x0018(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0019(0x0003) MISSED OFFSET
	int                                                MinOwnedNodesRequiredFromPrereqPage;                      // 0x001C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.HomebaseNodeANDPrerequisites
// 0x0010
struct FHomebaseNodeANDPrerequisites
{
	TArray<struct FHomebaseNodeInstancePrerequisites>  AND_Prerequisites;                                        // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.HomebaseSquadSlotId
// 0x0010
struct FHomebaseSquadSlotId
{
	struct FName                                       SquadId;                                                  // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                SquadSlotIndex;                                           // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.HomebaseNode
// 0x00B8 (0x00C0 - 0x0008)
struct FHomebaseNode : public FTableRowBase
{
	struct FText                                       DisplayName;                                              // 0x0008(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	TArray<struct FHomebaseNodeANDPrerequisites>       OR_Prerequisites;                                         // 0x0020(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FFortItemQuantityPair>               Cost;                                                     // 0x0030(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0040(0x0010) UNKNOWN PROPERTY: ArrayProperty FortniteGame.HomebaseNode.QuestTemplateRequirements
	EFortHomebaseNodeDisplayType                       DisplayType;                                              // 0x0050(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFortHomebaseNodeMagnitude                         DisplayMagnitude;                                         // 0x0051(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFortHomebaseNodeActionType                        ActionType;                                               // 0x0052(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x5];                                       // 0x0053(0x0005) MISSED OFFSET
	struct FName                                       DrillDownNodePageId;                                      // 0x0058(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UFortAbilityKit*                             AbilityKit;                                               // 0x0060(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UClass*                                      GameplayEffect;                                           // 0x0068(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TArray<struct FName>                               GameplayEffectRowNames;                                   // 0x0070(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FHomebaseSquadSlotId>                UnlockedSquadSlots;                                       // 0x0080(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int                                                NumPowerPoints;                                           // 0x0090(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0094(0x0004) MISSED OFFSET
	struct FName                                       StyleId;                                                  // 0x0098(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FText                                       Description;                                              // 0x00A0(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	class UClass*                                      CustomTooltip;                                            // 0x00B8(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.WorkerSetBonusState
// 0x0010
struct FWorkerSetBonusState
{
	struct FGameplayTag                                SetBonusTag;                                              // 0x0000(0x0008) (BlueprintVisible)
	int                                                CurrentMatchCount;                                        // 0x0008(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                RequiredMatchCountToActivate;                             // 0x000C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.WorkerSetBonusData
// 0x0038
struct FWorkerSetBonusData
{
	struct FGameplayTag                                SetBonusTypeTag;                                          // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FText                                       DisplayName;                                              // 0x0008(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	int                                                RequiredWorkersCount;                                     // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	class UClass*                                      SetBonusEffect;                                           // 0x0028(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                SelectionWeight;                                          // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                PowerPoints;                                              // 0x0034(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.WorkerPortraitData
// 0x0028
struct FWorkerPortraitData
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.WorkerPortraitData.Portrait
};

// ScriptStruct FortniteGame.WorkerGenderData
// 0x0018
struct FWorkerGenderData
{
	TEnumAsByte<EFortCustomGender>                     Gender;                                                   // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<struct FWorkerPortraitData>                 PotraitData;                                              // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.WorkerPersonalityData
// 0x0038
struct FWorkerPersonalityData
{
	struct FGameplayTag                                PersonalityTypeTag;                                       // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FText                                       PersonalityName;                                          // 0x0008(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	int                                                SelectionWeight;                                          // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	TArray<struct FWorkerGenderData>                   GenderData;                                               // 0x0028(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.ManagerSynergyData
// 0x0018
struct FManagerSynergyData
{
	struct FGameplayTag                                SynergyTypeTag;                                           // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	TArray<struct FWorkerGenderData>                   GenderData;                                               // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.TeamMapInfo
// 0x0048
struct FTeamMapInfo
{
	TArray<unsigned char>                              ReplicatedSeedPack;                                       // 0x0000(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x34];                                      // 0x0010(0x0034) MISSED OFFSET
	TEnumAsByte<EFortTeam>                             TeamId;                                                   // 0x0044(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0045(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.TeamMapExplorationEvent
// 0x0002
struct FTeamMapExplorationEvent
{
	TEnumAsByte<EFortTeam>                             TeamId;                                                   // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	int8_t                                             ExplorationThreshold;                                     // 0x0001(0x0001) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortInstensityCurveSequenceProgression
// 0x0018
struct FFortInstensityCurveSequenceProgression
{
	class UFortIntensityCurveSequence*                 CurveSequence;                                            // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FCurveTableRowHandle                        SelectionWeight;                                          // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.InteractionType
// 0x0028
struct FInteractionType
{
	TEnumAsByte<ETInteractionType>                     InteractionType;                                          // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	TWeakObjectPtr<class AFortPlayerPawn>              RequestingPawn;                                           // 0x0004(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x000C(0x0008) MISSED OFFSET
	TWeakObjectPtr<class UPrimitiveComponent>          InteractComponent;                                        // 0x0014(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FVector                                     InteractPoint;                                            // 0x001C(0x000C) (IsPlainOldData)
};

// ScriptStruct FortniteGame.FortItemList
// 0x00C0 (0x0170 - 0x00B0)
struct FFortItemList : public FFastArraySerializer
{
	TArray<struct FFortItemEntry>                      ReplicatedEntries;                                        // 0x00B0(0x0010) (ZeroConstructor, SaveGame)
	unsigned char                                      UnknownData00[0x50];                                      // 0x00C0(0x0050) MISSED OFFSET
	TArray<class UFortWorldItem*>                      ItemInstances;                                            // 0x0110(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x50];                                      // 0x0120(0x0050) MISSED OFFSET
};

// ScriptStruct FortniteGame.ItemCategoryMappingData
// 0x0020
struct FItemCategoryMappingData
{
	EFortItemType                                      CategoryType;                                             // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FText                                       CategoryName;                                             // 0x0008(0x0018) (Edit)
};

// ScriptStruct FortniteGame.ItemCategory
// 0x0308
struct FItemCategory
{
	struct FGameplayTagContainer                       TagContainer;                                             // 0x0000(0x0020) (Edit)
	struct FText                                       CategoryName;                                             // 0x0020(0x0018) (Edit)
	struct FFortMultiSizeBrush                         CategoryBrush;                                            // 0x0038(0x02D0) (Edit)
};

// ScriptStruct FortniteGame.KeepEventWaveData
// 0x0040
struct FKeepEventWaveData
{
	struct FText                                       WaveDescription;                                          // 0x0000(0x0018) (Edit, DisableEditOnInstance)
	class UClass*                                      EncounterTemplate;                                        // 0x0018(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UFortAISpawnGroupProgressionInfo*            SpawnGroupProgressionInfo;                                // 0x0020(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              WarmupTime;                                               // 0x0028(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              EncounterTime;                                            // 0x002C(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                DifficultyLevel;                                          // 0x0030(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              AliveMultiplier;                                          // 0x0034(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                EnemySpawnBits1;                                          // 0x0038(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                EnemySpawnBits2;                                          // 0x003C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.KeepEventInfo
// 0x0030
struct FKeepEventInfo
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.KeepEventInfo.KeepEvent
	int                                                DifficultyLevelOffset;                                    // 0x0028(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortDialogExternalLatentActionHandle
// 0x0004
struct FFortDialogExternalLatentActionHandle
{
	int                                                Handle;                                                   // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortWeaponDurabilityByRarityStats
// 0x0028 (0x0030 - 0x0008)
struct FFortWeaponDurabilityByRarityStats : public FTableRowBase
{
	int                                                Handmade;                                                 // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Ordinary;                                                 // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Sturdy;                                                   // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Quality;                                                  // 0x0014(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Fine;                                                     // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Elegant;                                                  // 0x001C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Masterwork;                                               // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Epic;                                                     // 0x0024(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Badass;                                                   // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Legendary;                                                // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortTrapStats
// 0x0018 (0x0138 - 0x0120)
struct FFortTrapStats : public FFortBaseWeaponStats
{
	float                                              ArmTime;                                                  // 0x0120(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              FireDelay;                                                // 0x0124(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              DamageDelay;                                              // 0x0128(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                PlacementScore;                                           // 0x012C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                ActivationScore;                                          // 0x0130(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0134(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortRangedWeaponStats
// 0x0130 (0x0250 - 0x0120)
struct FFortRangedWeaponStats : public FFortBaseWeaponStats
{
	float                                              Spread;                                                   // 0x0120(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SpreadDownsights;                                         // 0x0124(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              StandingStillSpreadMultiplier;                            // 0x0128(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AthenaCrouchingSpreadMultiplier;                          // 0x012C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AthenaJumpingFallingSpreadMultiplier;                     // 0x0130(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AthenaSprintingSpreadMultiplier;                          // 0x0134(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MinSpeedForSpreadMultiplier;                              // 0x0138(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaxSpeedForSpreadMultiplier;                              // 0x013C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SpreadDownsightsAdditionalCooldownTime;                   // 0x0140(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              HeatX1;                                                   // 0x0144(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              HeatY1;                                                   // 0x0148(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              HeatX2;                                                   // 0x014C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              HeatY2;                                                   // 0x0150(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              HeatX3;                                                   // 0x0154(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              HeatY3;                                                   // 0x0158(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              HeatXScale;                                               // 0x015C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              HeatYScale;                                               // 0x0160(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              CoolX1;                                                   // 0x0164(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              CoolY1;                                                   // 0x0168(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              CoolX2;                                                   // 0x016C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              CoolY2;                                                   // 0x0170(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              CoolX3;                                                   // 0x0174(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              CoolY3;                                                   // 0x0178(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              CoolXScale;                                               // 0x017C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              CoolYScale;                                               // 0x0180(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                BulletsPerCartridge;                                      // 0x0184(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              FiringRate;                                               // 0x0188(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ROFScale;                                                 // 0x018C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              BurstFiringRate;                                          // 0x0190(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RecoilVert;                                               // 0x0194(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RecoilVertScale;                                          // 0x0198(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RecoilVertScaleGamepad;                                   // 0x019C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              VertRecoilDownChance;                                     // 0x01A0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RecoilHoriz;                                              // 0x01A4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RecoilHorizScale;                                         // 0x01A8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RecoilHorizScaleGamepad;                                  // 0x01AC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RecoilInterpSpeed;                                        // 0x01B0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RecoilRecoveryInterpSpeed;                                // 0x01B4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RecoilRecoveryDelay;                                      // 0x01B8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RecoilRecoveryFraction;                                   // 0x01BC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RecoilDownsightsMultiplier;                               // 0x01C0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AthenaRecoilMagnitudeMin;                                 // 0x01C4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AthenaRecoilMagnitudeMax;                                 // 0x01C8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AthenaRecoilMagnitudeScale;                               // 0x01CC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AthenaRecoilAngleMin;                                     // 0x01D0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AthenaRecoilAngleMax;                                     // 0x01D4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AthenaRecoilRollMagnitudeMin;                             // 0x01D8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              AthenaRecoilRollMagnitudeMax;                             // 0x01DC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              AthenaRecoilInterpSpeed;                                  // 0x01E0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AthenaRecoilRecoveryInterpSpeed;                          // 0x01E4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AthenaRecoilDownsightsMultiplier;                         // 0x01E8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AthenaAimAssistRange;                                     // 0x01EC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ADSTransitionInTime;                                      // 0x01F0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ADSTransitionOutTime;                                     // 0x01F4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaxSpareAmmo;                                             // 0x01F8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                BulletsPerTracer;                                         // 0x01FC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AIDelayBeforeFiringMin;                                   // 0x0200(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AIDelayBeforeFiringMax;                                   // 0x0204(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AIFireDurationMin;                                        // 0x0208(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AIFireDurationMax;                                        // 0x020C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AIMinSpreadDuration;                                      // 0x0210(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AIMaxSpreadDuration;                                      // 0x0214(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AIDurationSpreadMultiplier;                               // 0x0218(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AIAdditionalSpreadForTargetMovingLaterally;               // 0x021C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              EQSDensity;                                               // 0x0220(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MinApproachRange;                                         // 0x0224(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MinActualRange;                                           // 0x0228(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MinPreferredRange;                                        // 0x022C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MinPreferredRangeEQS;                                     // 0x0230(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaxPreferredRangeEQS;                                     // 0x0234(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaxPreferredRange;                                        // 0x0238(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaxActualRange;                                           // 0x023C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaxApproachRange;                                         // 0x0240(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SweepRadius;                                              // 0x0244(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AutoReloadDelayOverride;                                  // 0x0248(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x024C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortPawnStats
// 0x0088 (0x0090 - 0x0008)
struct FFortPawnStats : public FTableRowBase
{
	float                                              MaximumHealth;                                            // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SpeedWalk;                                                // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SpeedRun;                                                 // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SpeedSprint;                                              // 0x0014(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SpeedCrouchedRun;                                         // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SpeedCrouchedSprint;                                      // 0x001C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SpeedBackwardsMultiplier;                                 // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SpeedDBNO;                                                // 0x0024(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              AccelerationStrafeMultiplierSprint;                       // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MinAnalogWalkSpeed;                                       // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              GroundFriction;                                           // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              BrakingDecelerationWalking;                               // 0x0034(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              BrakingDecelerationFalling;                               // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              BrakingFrictionFactor;                                    // 0x003C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaxAcceleration;                                          // 0x0040(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              JumpZVelocity;                                            // 0x0044(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UCurveTable*                                 FallingDamageTable;                                       // 0x0048(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       FallingDamageTableRow;                                    // 0x0050(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              HealthRegenRate;                                          // 0x0058(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              HealthRegenDelay;                                         // 0x005C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              HealthRegenThreshold;                                     // 0x0060(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaxShield;                                                // 0x0064(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ShieldRegenRate;                                          // 0x0068(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ShieldRegenDelay;                                         // 0x006C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ShieldRegenThreshold;                                     // 0x0070(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaxControlResistance;                                     // 0x0074(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ControlResistanceRegenRate;                               // 0x0078(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ControlResistanceRegenDelay;                              // 0x007C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ControlResistanceRegenThreshold;                          // 0x0080(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              KnockbackMultiplier;                                      // 0x0084(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              KnockbackThreshold;                                       // 0x0088(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bAllowChainStun;                                          // 0x008C(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFortControlRecoveryBehavior                       ControlRecoveryBehavior;                                  // 0x008D(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x008E(0x0002) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortMeleeWeaponStats
// 0x0028 (0x0148 - 0x0120)
struct FFortMeleeWeaponStats : public FFortBaseWeaponStats
{
	float                                              RangeVSEnemies;                                           // 0x0120(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ConeYawAngle;                                             // 0x0124(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              ConePitchAngle;                                           // 0x0128(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SwingPlaySpeed;                                           // 0x012C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SwingTime;                                                // 0x0130(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              BuildingConeAngle;                                        // 0x0134(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              BuildingConeAnglePitch;                                   // 0x0138(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RangeVSBuildings2D;                                       // 0x013C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RangeVSBuildingsZ;                                        // 0x0140(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              RangeVSWeakSpots;                                         // 0x0144(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.ServerLaunchInfo
// 0x0010
struct FServerLaunchInfo
{
	float                                              LaunchServerTime;                                         // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	class AFortPlayerPawnAthena*                       LaunchedPawn;                                             // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.LeaderboardRowData
// 0x0048
struct FLeaderboardRowData
{
	int                                                Rank;                                                     // 0x0000(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     User;                                                     // 0x0008(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int                                                Value;                                                    // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FUniqueNetIdRepl                            PlatformAccountId;                                        // 0x0020(0x0028) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.MatchmakingParams
// 0x00A8
struct FMatchmakingParams
{
	int                                                ControllerId;                                             // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                PartySize;                                                // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FString                                     DatacenterId;                                             // 0x0008(0x0010) (ZeroConstructor)
	int                                                PlaylistId;                                               // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MatchmakingLevel;                                         // 0x001C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MissionDifficultyMin;                                     // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MissionDifficultyMax;                                     // 0x0024(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FString                                     TheaterId;                                                // 0x0028(0x0010) (ZeroConstructor)
	struct FString                                     ZoneInstanceId;                                           // 0x0038(0x0010) (ZeroConstructor)
	struct FString                                     WUID;                                                     // 0x0048(0x0010) (ZeroConstructor)
	struct FUniqueNetIdRepl                            WorldOwnerId;                                             // 0x0058(0x0028)
	struct FString                                     SessionId;                                                // 0x0080(0x0010) (ZeroConstructor)
	EMatchmakingStartLocation                          StartWith;                                                // 0x0090(0x0001) (ZeroConstructor, IsPlainOldData)
	EMatchmakingFlags                                  Flags;                                                    // 0x0091(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0092(0x0002) MISSED OFFSET
	float                                              ChanceToHostOverride;                                     // 0x0094(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              ChanceToHostIncrease;                                     // 0x0098(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                NumAttempts;                                              // 0x009C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MaxSearchResultsOverride;                                 // 0x00A0(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MaxProcessedSearchResults;                                // 0x00A4(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortCachedMatchmakingSearchParams
// 0x00B8
struct FFortCachedMatchmakingSearchParams
{
	EFortMatchmakingType                               MatchmakingType;                                          // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FMatchmakingParams                          MatchmakingParams;                                        // 0x0008(0x00A8)
	bool                                               bValid;                                                   // 0x00B0(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x00B1(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortMatchmakingConfig
// 0x0010
struct FFortMatchmakingConfig
{
	float                                              ChanceToHostOverride;                                     // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              ChanceToHostIncrease;                                     // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MaxSearchResultsOverride;                                 // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MaxProcessedSearchResults;                                // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortInviteSessionParams
// 0x0038
struct FFortInviteSessionParams
{
	TEnumAsByte<EMatchmakingState>                     State;                                                    // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FText                                       FailureReason;                                            // 0x0008(0x0018)
	TEnumAsByte<EPartyReservationResult>               LastBeaconResponse;                                       // 0x0020(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x17];                                      // 0x0021(0x0017) MISSED OFFSET
};

// ScriptStruct FortniteGame.FriendCodeLocString
// 0x0020
struct FFriendCodeLocString
{
	struct FString                                     Lang;                                                     // 0x0000(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FString                                     Text;                                                     // 0x0010(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortPublicAccountInfo
// 0x0034
struct FFortPublicAccountInfo
{
	int                                                Level;                                                    // 0x0000(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaxLevel;                                                 // 0x0004(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                LevelXp;                                                  // 0x0008(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                LevelXpForLevel;                                          // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FAthenaLevelInfo                            BattleRoyaleLevel;                                        // 0x0010(0x0024) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.FortPrivateAccountInfo
// 0x0004 (0x0038 - 0x0034)
struct FFortPrivateAccountInfo : public FFortPublicAccountInfo
{
	int                                                MtxBalance;                                               // 0x0034(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortAthenaLoadout
// 0x0070
struct FFortAthenaLoadout
{
	struct FString                                     BannerIconId;                                             // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FString                                     BannerColorId;                                            // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	class UAthenaGliderItemDefinition*                 Glider;                                                   // 0x0020(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UAthenaPickaxeItemDefinition*                Pickaxe;                                                  // 0x0028(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UAthenaCharacterItemDefinition*              Character;                                                // 0x0030(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UAthenaHatItemDefinition*                    Hat;                                                      // 0x0038(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UAthenaBackpackItemDefinition*               Backpack;                                                 // 0x0040(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UAthenaLoadingScreenItemDefinition*          LoadingScreen;                                            // 0x0048(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UAthenaBattleBusItemDefinition*              BattleBus;                                                // 0x0050(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TArray<class UAthenaDanceItemDefinition*>          Dances;                                                   // 0x0058(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	class UAthenaVictoryPoseItemDefinition*            VictoryPose;                                              // 0x0068(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortHomeBaseInfo
// 0x0040
struct FFortHomeBaseInfo
{
	struct FString                                     BannerIconId;                                             // 0x0000(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FString                                     BannerColorId;                                            // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FText                                       Name;                                                     // 0x0020(0x0018) (BlueprintVisible, BlueprintReadOnly)
	bool                                               ValidData;                                                // 0x0038(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortBattlePassInfo
// 0x0014
struct FFortBattlePassInfo
{
	bool                                               bOwnsBattlePass;                                          // 0x0000(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                BattlePassLevel;                                          // 0x0004(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                SelfMatchBoostXp;                                         // 0x0008(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                FriendMatchBoostXp;                                       // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bValidData;                                               // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortQuestClientSettings
// 0x0010
struct FFortQuestClientSettings
{
	TArray<struct FString>                             PinnedQuestInstances;                                     // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortQuestObjectiveCompletion
// 0x0028
struct FFortQuestObjectiveCompletion
{
	struct FString                                     StatName;                                                 // 0x0000(0x0010) (ZeroConstructor)
	int                                                Count;                                                    // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x14];                                      // 0x0014(0x0014) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortQuestEarnedBadgeData
// 0x0018
struct FFortQuestEarnedBadgeData
{
	struct FString                                     TemplateId;                                               // 0x0000(0x0010) (ZeroConstructor)
	int                                                Count;                                                    // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.AccountIdAndScore
// 0x0018
struct FAccountIdAndScore
{
	struct FString                                     AccountId;                                                // 0x0000(0x0010) (ZeroConstructor)
	int                                                TotalScore;                                               // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bCriticalMatchBonus;                                      // 0x0014(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortItemInstanceQuantityPair
// 0x0010
struct FFortItemInstanceQuantityPair
{
	class UFortItem*                                   Item;                                                     // 0x0000(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortInventoryType>                    InventoryType;                                            // 0x0008(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
	int                                                Quantity;                                                 // 0x000C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.AthenaSeasonRewardLevelInfo
// 0x0020
struct FAthenaSeasonRewardLevelInfo
{
	EAthenaSeasonRewardTrack                           Track;                                                    // 0x0000(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                Level;                                                    // 0x0004(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                XpToNextLevel;                                            // 0x0008(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	TArray<struct FAthenaRewardItemReference>          Rewards;                                                  // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortWorldProfileUpdateRequest
// 0x0110
struct FFortWorldProfileUpdateRequest
{
	unsigned char                                      UnknownData00[0x40];                                      // 0x0000(0x0040) MISSED OFFSET
	TArray<class UFortMcpProfileWorld*>                WorldProfilesToSave;                                      // 0x0040(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0050(0x0010) MISSED OFFSET
	int                                                NumberOfRequests;                                         // 0x0060(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0xAC];                                      // 0x0064(0x00AC) MISSED OFFSET
};

// ScriptStruct FortniteGame.QuickBarSlot
// 0x0018
struct FQuickBarSlot
{
	TArray<struct FGuid>                               Items;                                                    // 0x0000(0x0010) (ZeroConstructor)
	bool                                               bEnabled;                                                 // 0x0010(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.QuickBar
// 0x0090
struct FQuickBar
{
	int                                                CurrentFocusedSlot;                                       // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                PreviousFocusedSlot;                                      // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                SecondaryFocusedSlot;                                     // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	TArray<struct FQuickBarSlot>                       Slots;                                                    // 0x0010(0x0010) (ZeroConstructor)
	struct FQuickBarData                               DataDefinition;                                           // 0x0020(0x0010)
	unsigned char                                      UnknownData01[0x50];                                      // 0x0030(0x0050) UNKNOWN PROPERTY: SetProperty FortniteGame.QuickBar.EquippedItemDefinitions
	TArray<int>                                        SharedVisibleSlotIndicesWhenUsingGamepad;                 // 0x0080(0x0010) (ZeroConstructor, Transient, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
};

// ScriptStruct FortniteGame.FortWorldPlayerLoadout
// 0x0140
struct FFortWorldPlayerLoadout
{
	bool                                               bPlayerIsNew;                                             // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<struct FString>                             PinnedSchematicInstances;                                 // 0x0008(0x0010) (ZeroConstructor)
	struct FQuickBar                                   PrimaryQuickBarRecord;                                    // 0x0018(0x0090)
	struct FQuickBar                                   SecondaryQuickBarRecord;                                  // 0x00A8(0x0090)
	int                                                ZonesCompleted;                                           // 0x0138(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x013C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.ItemIdAndQuantityPair
// 0x0018
struct FItemIdAndQuantityPair
{
	struct FString                                     ItemId;                                                   // 0x0000(0x0010) (ZeroConstructor)
	int                                                Quantity;                                                 // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortBatchUpdatePlayer_Update
// 0x00F8
struct FFortBatchUpdatePlayer_Update
{
	struct FUniqueNetIdRepl                            AccountId;                                                // 0x0000(0x0028)
	int                                                TheaterNum;                                               // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	struct FMcpProfileChangeRequest                    TheaterItemUpdate;                                        // 0x0030(0x0058)
	int                                                OutpostNum;                                               // 0x0088(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x008C(0x0004) MISSED OFFSET
	struct FMcpProfileChangeRequest                    OutpostItemUpdate;                                        // 0x0090(0x0058)
	TArray<struct FFortQuestObjectiveCompletion>       QuestObjectiveUpdates;                                    // 0x00E8(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortBatchUpdatePlayer_DeployableBaseUpdate
// 0x0050
struct FFortBatchUpdatePlayer_DeployableBaseUpdate
{
	struct FUniqueNetIdRepl                            AccountId;                                                // 0x0000(0x0028)
	struct FString                                     DeployableBaseItemId;                                     // 0x0028(0x0010) (ZeroConstructor)
	struct FFortCloudSaveInfo                          CloudSaveInfo;                                            // 0x0038(0x0018)
};

// ScriptStruct FortniteGame.FortTheaterColorInfo
// 0x0030
struct FFortTheaterColorInfo
{
	bool                                               bUseDifficultyToDetermineColor;                           // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FSlateColor                                 Color;                                                    // 0x0008(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortMissionAlertRuntimeData
// 0x0003
struct FFortMissionAlertRuntimeData
{
	EFortMissionAlertCategory                          MissionAlertCategory;                                     // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bRespectTileRequirements;                                 // 0x0001(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bAllowQuickplay;                                          // 0x0002(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortTheaterRuntimeData
// 0x0438
struct FFortTheaterRuntimeData
{
	EFortTheaterType                                   TheaterType;                                              // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FGameplayTagContainer                       TheaterTags;                                              // 0x0008(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FFortRequirementsInfo                       TheaterVisibilityRequirements;                            // 0x0028(0x0048) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FFortRequirementsInfo                       Requirements;                                             // 0x0070(0x0048) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	ESubGame                                           RequiredSubGameForVisibility;                             // 0x00B8(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bOnlyMatchLinkedQuestsToTiles;                            // 0x00B9(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x00BA(0x0006) MISSED OFFSET
	class UClass*                                      WorldMapPinClass;                                         // 0x00C0(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UTexture2D*                                  TheaterImage;                                             // 0x00C8(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FFortMultiSizeBrush                         TheaterImages;                                            // 0x00D0(0x02D0) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FFortTheaterColorInfo                       TheaterColorInfo;                                         // 0x03A0(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FName                                       Socket;                                                   // 0x03D0(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FFortRequirementsInfo                       MissionAlertRequirements;                                 // 0x03D8(0x0048) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	TArray<struct FFortMissionAlertRuntimeData>        MissionAlertCategoryRequirements;                         // 0x0420(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	float                                              HighestDifficulty;                                        // 0x0430(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0434(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortLinkedQuest
// 0x0018
struct FFortLinkedQuest
{
	class UFortQuestItemDefinition*                    QuestDefinition;                                          // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FDataTableRowHandle                         ObjectiveStatHandle;                                      // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.FortTheaterMissionWeight
// 0x0030
struct FFortTheaterMissionWeight
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.FortTheaterMissionWeight.MissionGenerator
	float                                              Weight;                                                   // 0x0028(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortTheaterDifficultyWeight
// 0x0028
struct FFortTheaterDifficultyWeight
{
	struct FDataTableRowHandle                         DifficultyInfo;                                           // 0x0000(0x0010) (Edit, DisableEditOnInstance)
	struct FString                                     LootTierGroup;                                            // 0x0010(0x0010) (ZeroConstructor, Transient)
	float                                              Weight;                                                   // 0x0020(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortTheaterMapTileData
// 0x00D8
struct FFortTheaterMapTileData
{
	EFortTheaterMapTileType                            TileType;                                                 // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0001(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.FortTheaterMapTileData.ZoneTheme
	struct FFortRequirementsInfo                       Requirements;                                             // 0x0030(0x0048) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	TArray<struct FFortLinkedQuest>                    LinkedQuests;                                             // 0x0078(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int                                                XCoordinate;                                              // 0x0088(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                YCoordinate;                                              // 0x008C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TArray<struct FFortTheaterMissionWeight>           MissionWeightOverrides;                                   // 0x0090(0x0010) (Edit, ZeroConstructor)
	TArray<struct FFortTheaterDifficultyWeight>        DifficultyWeightOverrides;                                // 0x00A0(0x0010) (Edit, ZeroConstructor)
	bool                                               CanBeMissionAlert;                                        // 0x00B0(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x00B1(0x0007) MISSED OFFSET
	struct FGameplayTagContainer                       TileTags;                                                 // 0x00B8(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance, EditConst)
};

// ScriptStruct FortniteGame.FortTheaterMapMissionData
// 0x0030
struct FFortTheaterMapMissionData
{
	TArray<struct FFortTheaterMissionWeight>           MissionWeights;                                           // 0x0000(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FFortTheaterDifficultyWeight>        DifficultyWeights;                                        // 0x0010(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	int                                                NumMissionsAvailable;                                     // 0x0020(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                NumMissionsToChange;                                      // 0x0024(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              MissionChangeFrequency;                                   // 0x0028(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortMissionAlertRequirementsInfo
// 0x0050
struct FFortMissionAlertRequirementsInfo
{
	EFortMissionAlertCategory                          Category;                                                 // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FFortRequirementsInfo                       Requirements;                                             // 0x0008(0x0048) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortTheaterMapRegionData
// 0x00F8
struct FFortTheaterMapRegionData
{
	struct FText                                       DisplayName;                                              // 0x0000(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance, EditConst)
	struct FGameplayTagContainer                       RegionTags;                                               // 0x0018(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance, EditConst)
	TArray<int>                                        TileIndices;                                              // 0x0038(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, EditConst)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0048(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortTheaterMapRegionData.RegionThemeIcon
	struct FFortTheaterMapMissionData                  MissionData;                                              // 0x0070(0x0030) (Edit, DisableEditOnInstance)
	struct FFortRequirementsInfo                       Requirements;                                             // 0x00A0(0x0048) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	TArray<struct FFortMissionAlertRequirementsInfo>   MissionAlertRequirements;                                 // 0x00E8(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortTheaterMapData
// 0x04D0
struct FFortTheaterMapData
{
	struct FText                                       DisplayName;                                              // 0x0000(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FString                                     UniqueId;                                                 // 0x0018(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, EditConst)
	int                                                TheaterSlot;                                              // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bIsTestTheater;                                           // 0x002C(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x002D(0x0003) MISSED OFFSET
	struct FString                                     RequiredEventFlag;                                        // 0x0030(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	struct FName                                       MissionRewardNamedWeightsRowName;                         // 0x0040(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FText                                       Description;                                              // 0x0048(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FText                                       ThreatDisplayName;                                        // 0x0060(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FFortTheaterRuntimeData                     RuntimeInfo;                                              // 0x0078(0x0438) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	TArray<struct FFortTheaterMapTileData>             Tiles;                                                    // 0x04B0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, EditConst)
	TArray<struct FFortTheaterMapRegionData>           Regions;                                                  // 0x04C0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, EditConst)
};

// ScriptStruct FortniteGame.FortAvailableMissionData
// 0x00A8
struct FFortAvailableMissionData
{
	struct FString                                     MissionGuid;                                              // 0x0000(0x0010) (ZeroConstructor)
	struct FMcpLootResult                              MissionRewards;                                           // 0x0010(0x0020)
	struct FMcpLootResult                              BonusMissionRewards;                                      // 0x0030(0x0020)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0050(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.FortAvailableMissionData.MissionGenerator
	struct FDataTableRowHandle                         MissionDifficultyInfo;                                    // 0x0078(0x0010)
	int                                                TileIndex;                                                // 0x0088(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x008C(0x0004) MISSED OFFSET
	struct FDateTime                                   AvailableUntil;                                           // 0x0090(0x0008)
	TArray<class UFortItemDefinition*>                 ItemDefinitionRefCache;                                   // 0x0098(0x0010) (ZeroConstructor, Transient)
};

// ScriptStruct FortniteGame.FortAvailableTheaterMissions
// 0x0028
struct FFortAvailableTheaterMissions
{
	struct FString                                     TheaterId;                                                // 0x0000(0x0010) (ZeroConstructor)
	TArray<struct FFortAvailableMissionData>           AvailableMissions;                                        // 0x0010(0x0010) (ZeroConstructor)
	struct FDateTime                                   NextRefresh;                                              // 0x0020(0x0008)
};

// ScriptStruct FortniteGame.FortAvailableMissionAlertData
// 0x0098
struct FFortAvailableMissionAlertData
{
	struct FString                                     CategoryName;                                             // 0x0000(0x0010) (ZeroConstructor)
	struct FString                                     SpreadDataName;                                           // 0x0010(0x0010) (ZeroConstructor)
	struct FString                                     MissionAlertGuid;                                         // 0x0020(0x0010) (ZeroConstructor)
	int                                                TileIndex;                                                // 0x0030(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
	struct FDateTime                                   AvailableUntil;                                           // 0x0038(0x0008)
	struct FDateTime                                   RefreshSpreadAt;                                          // 0x0040(0x0008)
	struct FMcpLootResult                              MissionAlertRewards;                                      // 0x0048(0x0020)
	struct FMcpLootResult                              MissionAlertModifiers;                                    // 0x0068(0x0020)
	TArray<class UFortItemDefinition*>                 ItemDefinitionRefCache;                                   // 0x0088(0x0010) (ZeroConstructor, Transient)
};

// ScriptStruct FortniteGame.FortAvailableMissionAlerts
// 0x0028
struct FFortAvailableMissionAlerts
{
	struct FString                                     TheaterId;                                                // 0x0000(0x0010) (ZeroConstructor)
	TArray<struct FFortAvailableMissionAlertData>      AvailableMissionAlerts;                                   // 0x0010(0x0010) (ZeroConstructor)
	struct FDateTime                                   NextRefresh;                                              // 0x0020(0x0008)
};

// ScriptStruct FortniteGame.FortActiveTheaterInfo
// 0x0030
struct FFortActiveTheaterInfo
{
	TArray<struct FFortTheaterMapData>                 Theaters;                                                 // 0x0000(0x0010) (ZeroConstructor)
	TArray<struct FFortAvailableTheaterMissions>       Missions;                                                 // 0x0010(0x0010) (ZeroConstructor)
	TArray<struct FFortAvailableMissionAlerts>         MissionAlerts;                                            // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.NavAgentData
// 0x0018
struct FNavAgentData
{
	struct FName                                       AgentName;                                                // 0x0000(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FCurveTableRowHandle                        BuildingActorHealthToNavAreaStrengthHandle;               // 0x0008(0x0010) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortMiniMapData
// 0x0080
struct FFortMiniMapData
{
	class UTexture2D*                                  MiniMapIcon;                                              // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FVector2D                                   IconScale;                                                // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, SaveGame, IsPlainOldData)
	unsigned char                                      bUseIconSize : 1;                                         // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, SaveGame)
	unsigned char                                      bIsVisible : 1;                                           // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, SaveGame)
	unsigned char                                      bIsVisibleOnMiniMap : 1;                                  // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, SaveGame)
	unsigned char                                      bShowVerticalOffset : 1;                                  // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, SaveGame)
	unsigned char                                      bShowFarOffIndicator : 1;                                 // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, SaveGame)
	unsigned char                                      bAllowLocalOverrides : 1;                                 // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, SaveGame)
	unsigned char                                      bUseTeamAffiliationColors : 1;                            // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, SaveGame)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	struct FLinearColor                                Color;                                                    // 0x0014(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, SaveGame, IsPlainOldData)
	struct FLinearColor                                FriendColor;                                              // 0x0024(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, SaveGame, IsPlainOldData)
	struct FLinearColor                                EnemyColor;                                               // 0x0034(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, SaveGame, IsPlainOldData)
	struct FLinearColor                                NeutralColor;                                             // 0x0044(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, SaveGame, IsPlainOldData)
	struct FLinearColor                                PulseColor;                                               // 0x0054(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, SaveGame, IsPlainOldData)
	float                                              ColorPulsesPerSecond;                                     // 0x0064(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              SizePulsesPerSecond;                                      // 0x0068(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, SaveGame, IsPlainOldData)
	float                                              ViewableDistance;                                         // 0x006C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, SaveGame, IsPlainOldData)
	struct FVector                                     LocationOffset;                                           // 0x0070(0x000C) (Edit, BlueprintVisible, BlueprintReadOnly, SaveGame, IsPlainOldData)
	int                                                Priority;                                                 // 0x007C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, SaveGame, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortMissionEventName
// 0x0000 (0x0010 - 0x0010)
struct FFortMissionEventName : public FFortEventName
{

};

// ScriptStruct FortniteGame.FortMissionPlacementActorPreferredTagInfo
// 0x0038
struct FFortMissionPlacementActorPreferredTagInfo
{
	struct FDataTableRowHandle                         DifficultyInfo;                                           // 0x0000(0x0010) (Edit, DisableEditOnInstance)
	struct FGameplayTagContainer                       PlacementActorPreferredTags;                              // 0x0010(0x0020) (Edit, DisableEditOnInstance)
	float                                              Difficulty;                                               // 0x0030(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortMissionFocusDisplayData
// 0x0020
struct FFortMissionFocusDisplayData
{
	struct FText                                       CurrentFocusDisplayText;                                  // 0x0000(0x0018)
	float                                              CurrentFocusPercentage;                                   // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortBadgeCount
// 0x0014 (0x0020 - 0x000C)
struct FFortBadgeCount : public FFastArraySerializerItem
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	class UFortBadgeItemDefinition*                    Badge;                                                    // 0x0010(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	int                                                Count;                                                    // 0x0018(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortBadgeCountArray
// 0x0010 (0x00C0 - 0x00B0)
struct FFortBadgeCountArray : public FFastArraySerializer
{
	TArray<struct FFortBadgeCount>                     Badges;                                                   // 0x00B0(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortGeneratedMissionOption
// 0x0018
struct FFortGeneratedMissionOption
{
	class UFortDifficultyOptionCategoryMission*        MissionOptionCategory;                                    // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	class UClass*                                      MissionOption;                                            // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	float                                              RangeLerpValue;                                           // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortGeneratedEncounterOption
// 0x0018
struct FFortGeneratedEncounterOption
{
	class UFortDifficultyOptionCategoryEncounter*      EncounterOptionCategory;                                  // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	class UClass*                                      EncounterOption;                                          // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	float                                              RangeLerpValue;                                           // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bChangedSinceLastVLog;                                    // 0x0014(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortEncounterModeSettings
// 0x0004
struct FFortEncounterModeSettings
{
	TEnumAsByte<EFortEncounterPacingMode>              PacingMode;                                               // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortEncounterSpawnLocationPlacementMode> SpawnLocationMode;                                        // 0x0001(0x0001) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortEncounterUtilitiesMode>           UtilitiesMode;                                            // 0x0002(0x0001) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortEncounterSpawnLimitType>          SpawnLimitMode;                                           // 0x0003(0x0001) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortGeneratedEncounterProfile
// 0x0050
struct FFortGeneratedEncounterProfile
{
	float                                              EncounterDifficultyLevel;                                 // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	TArray<struct FFortGeneratedEncounterOption>       EncounterOptions;                                         // 0x0008(0x0010) (ZeroConstructor)
	struct FFortEncounterModeSettings                  EncounterModeSettings;                                    // 0x0018(0x0004)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FGameplayTagContainer                       EncounterTypeTags;                                        // 0x0020(0x0020)
	int                                                DifficultyOptionPointsAvailableAtGeneration;              // 0x0040(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MinDifficultyOptionPointsToUse;                           // 0x0044(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bShouldReselectOptionsPerInstance;                        // 0x0048(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0049(0x0003) MISSED OFFSET
	int                                                GeneratedEncounterIndex;                                  // 0x004C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortGeneratedDifficultyOptions
// 0x0040
struct FFortGeneratedDifficultyOptions
{
	float                                              GameDifficultyAtGeneration;                               // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                DifficultyOptionPointsAvailableAtGeneration;              // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MaxEncounterSpawnPointsAtGeneration;                      // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MinDifficultyOptionPointsToUse;                           // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	TArray<struct FFortGeneratedEncounterSequence>     GeneratedEncounterSequences;                              // 0x0010(0x0010) (ZeroConstructor)
	TArray<struct FFortGeneratedMissionOption>         MissionOptions;                                           // 0x0020(0x0010) (ZeroConstructor)
	TArray<struct FFortGeneratedEncounterProfile>      GeneratedEncounterProfiles;                               // 0x0030(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortMissionInstancedConfigDataBucket
// 0x0010
struct FFortMissionInstancedConfigDataBucket
{
	struct FGameplayTag                                Tag;                                                      // 0x0000(0x0008) (Transient)
	class UFortMissionConfigData*                      ConfigData;                                               // 0x0008(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortMissionInstancedConfigData
// 0x0010
struct FFortMissionInstancedConfigData
{
	TArray<struct FFortMissionInstancedConfigDataBucket> ConfigDataBuckets;                                        // 0x0000(0x0010) (ZeroConstructor, Transient)
};

// ScriptStruct FortniteGame.FortMissionWeightedReward
// 0x0088
struct FFortMissionWeightedReward
{
	struct FName                                       LootTierGroup;                                            // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FSlateBrush                                 LootIcon;                                                 // 0x0008(0x0078) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	float                                              Weight;                                                   // 0x0080(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0084(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortMissionEvent
// 0x0098
struct FFortMissionEvent
{
	struct FName                                       EventType;                                                // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FGameplayTagContainer                       ObjectiveHandle;                                          // 0x0008(0x0020) (Edit, BlueprintVisible)
	class UObject*                                     EventFocus;                                               // 0x0028(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UDataAsset*                                  EventContent;                                             // 0x0030(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class AActor*                                      EventInstigator;                                          // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                GenericInt;                                               // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              GenericFloat;                                             // 0x0044(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FText                                       GenericText;                                              // 0x0048(0x0018) (Edit, BlueprintVisible)
	struct FGameplayTagContainer                       GameplayTags;                                             // 0x0060(0x0020) (Edit, BlueprintVisible)
	struct FGuid                                       MissionGuid;                                              // 0x0080(0x0010) (Edit, BlueprintVisible, IsPlainOldData)
	class UFortMissionEventParams*                     Params;                                                   // 0x0090(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortDifficultyOptionBudget
// 0x0030
struct FFortDifficultyOptionBudget
{
	struct FGameplayTagContainer                       BudgetTypeTags;                                           // 0x0000(0x0020) (Edit, DisableEditOnInstance)
	struct FCurveTableRowHandle                        DifficultyOptionPointsCurve;                              // 0x0020(0x0010) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.ZoneLoadingScreenHeadingConfig
// 0x0038
struct FZoneLoadingScreenHeadingConfig
{
	class UTexture2D*                                  HeadingImage;                                             // 0x0000(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FText                                       Heading;                                                  // 0x0008(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FText                                       HeadingDescription;                                       // 0x0020(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.ZoneLoadingScreenConfig
// 0x0110
struct FZoneLoadingScreenConfig
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.ZoneLoadingScreenConfig.BackgroundImage
	struct FText                                       TitleDescription;                                         // 0x0028(0x0018) (Edit, DisableEditOnInstance)
	struct FText                                       Title;                                                    // 0x0040(0x0018) (Edit, DisableEditOnInstance)
	struct FZoneLoadingScreenHeadingConfig             Headings[0x3];                                            // 0x0058(0x0038) (Edit, DisableEditOnInstance)
	TArray<class UFortTips*>                           LoadingTips;                                              // 0x0100(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortAthenaLTMConfig
// 0x0058
struct FFortAthenaLTMConfig
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortAthenaLTMConfig.SplashImage
	struct FText                                       FrontEndDescription;                                      // 0x0028(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FText                                       DisabledMessage;                                          // 0x0040(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.MissionGenerationInfo
// 0x0050
struct FMissionGenerationInfo
{
	int                                                NumMissionsRequired;                                      // 0x0000(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FGameplayTagQuery                           MissionTagRequirements;                                   // 0x0008(0x0048) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.PerDifficultyMissionGenerationInfo
// 0x0020
struct FPerDifficultyMissionGenerationInfo
{
	struct FDataTableRowHandle                         MaxDifficulty;                                            // 0x0000(0x0010) (Edit, DisableEditOnInstance)
	TArray<struct FMissionGenerationInfo>              MissionGenerationInfos;                                   // 0x0010(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortPossibleMission
// 0x0038
struct FFortPossibleMission
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortPossibleMission.MissionInfo
	float                                              Weight;                                                   // 0x0028(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                MinAlwaysGenerated;                                       // 0x002C(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bIsPrototype;                                             // 0x0030(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortMissionInfoOption
// 0x0030
struct FFortMissionInfoOption
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortMissionInfoOption.MissionInfo
	float                                              MinDifficultyLevel;                                       // 0x0028(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortObjectiveEntry
// 0x0058
struct FFortObjectiveEntry
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.FortObjectiveEntry.ObjectiveRef
	class UFortBadgeItemDefinition*                    ObjectiveRewardBadge;                                     // 0x0028(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TEnumAsByte<EFortObjectiveRequirement>             MissionRequirement;                                       // 0x0030(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
	struct FGameplayTagContainer                       ObjectiveHandle;                                          // 0x0038(0x0020) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortObjectiveBlock
// 0x0010
struct FFortObjectiveBlock
{
	TArray<struct FFortObjectiveEntry>                 ObjectiveEntries;                                         // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortMissionPlacementFoundationItem
// 0x0078
struct FFortMissionPlacementFoundationItem
{
	struct FGameplayTagContainer                       ItemIdentifyingTags;                                      // 0x0000(0x0020) (Edit, DisableEditOnInstance)
	struct FGameplayTagContainer                       TagsToAddToChosenPlacementActorOrFoundationActor;         // 0x0020(0x0020) (Edit, DisableEditOnInstance)
	class UEnvQuery*                                   PlacementQuery;                                           // 0x0040(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0048(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.FortMissionPlacementFoundationItem.BuildingFoundationToPlace
	int                                                NumLocationsToFind;                                       // 0x0070(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bAdjustFoundationPlacementForFloors;                      // 0x0074(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0075(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortMissionPlacementActorItem
// 0x0080
struct FFortMissionPlacementActorItem
{
	struct FGameplayTagContainer                       ItemIdentifyingTags;                                      // 0x0000(0x0020) (Edit, DisableEditOnInstance)
	struct FGameplayTagContainer                       TagsToAddToChosenPlacementActor;                          // 0x0020(0x0020) (Edit, DisableEditOnInstance)
	class UEnvQuery*                                   PlacementQuery;                                           // 0x0040(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0048(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.FortMissionPlacementActorItem.ActorToPlace
	int                                                NumLocationsToFind;                                       // 0x0070(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bSpawnActorAutomatically;                                 // 0x0074(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bShouldReserveLocations;                                  // 0x0075(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bSnapToGrid;                                              // 0x0076(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bAdjustPlacementForFloors;                                // 0x0077(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bDontCreateSpawnRiftsNearby;                              // 0x0078(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0079(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortMissionPlacementItems
// 0x0040
struct FFortMissionPlacementItems
{
	struct FGameplayTagContainer                       TagsToAddToChosenPlacementActors;                         // 0x0000(0x0020) (Edit, DisableEditOnInstance)
	TArray<struct FFortMissionPlacementFoundationItem> AdditionalWorldFoundations;                               // 0x0020(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FFortMissionPlacementActorItem>      ActorsAndLocations;                                       // 0x0030(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortFinderProperty
// 0x0018
struct FFortFinderProperty
{
	class UProperty*                                   Property;                                                 // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FString                                     Value;                                                    // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortPlacementActorFinderEntry
// 0x00B8
struct FFortPlacementActorFinderEntry
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.FortPlacementActorFinderEntry.BuildingToSpawn
	class UClass*                                      BuildingClassToFind;                                      // 0x0028(0x0008) (ZeroConstructor, Deprecated, IsPlainOldData)
	TArray<class UClass*>                              BuildingClassesToFind;                                    // 0x0030(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	struct FGameplayTagContainer                       RequiredTags;                                             // 0x0040(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FGameplayTagContainer                       PreferredTags;                                            // 0x0060(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FGameplayTagContainer                       ExlusionTags;                                             // 0x0080(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	TArray<struct FFortFinderProperty>                 RequiredProperties;                                       // 0x00A0(0x0010) (ZeroConstructor)
	bool                                               bIgnoreCollisionCheck;                                    // 0x00B0(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bSnapToGrid;                                              // 0x00B1(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x00B2(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortPlacementActorFinderInfo
// 0x0018
struct FFortPlacementActorFinderInfo
{
	float                                              DistanceRangeMin;                                         // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              DistanceRangeMax;                                         // 0x0004(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TArray<struct FFortPlacementActorFinderEntry>      BuildingData;                                             // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortMissionPopupWidgetData
// 0x01A0
struct FFortMissionPopupWidgetData
{
	struct FText                                       DisplayName;                                              // 0x0000(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	bool                                               bShowDescription;                                         // 0x0018(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
	struct FText                                       Description;                                              // 0x0020(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FSlateBrush                                 DescriptionIcon;                                          // 0x0038(0x0078) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FSlateBrush                                 AvailableIcon;                                            // 0x00B0(0x0078) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FSlateBrush                                 UnavailableIcon;                                          // 0x0128(0x0078) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortEncounterProfile
// 0x0060
struct FFortEncounterProfile
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortEncounterProfile.EncounterOptions
	TArray<class UFortDifficultyOptionCategoryEncounter*> OverrideCategories;                                       // 0x0028(0x0010) (Edit, ExportObject, ZeroConstructor, DisableEditOnInstance)
	bool                                               bShouldReselectOptionsPerInstance;                        // 0x0038(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	struct FGameplayTagContainer                       EncounterTypeTags;                                        // 0x0040(0x0020) (Edit)
};

// ScriptStruct FortniteGame.FortEncounterSequenceSettings
// 0x0038
struct FFortEncounterSequenceSettings
{
	struct FFortEncounterTransitionSettings            TransitionSettings;                                       // 0x0000(0x0001) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<struct FFortEncounterProfile>               EncounterSequence;                                        // 0x0008(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FGameplayTagContainer                       SequenceTags;                                             // 0x0018(0x0020) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortMissionTaggedRewards
// 0x0018
struct FFortMissionTaggedRewards
{
	struct FGameplayTag                                Tag;                                                      // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0008(0x0010) UNKNOWN PROPERTY: ArrayProperty FortniteGame.FortMissionTaggedRewards.WorldItemDefinitions
};

// ScriptStruct FortniteGame.FortTimeOfDayTheme
// 0x0040
struct FFortTimeOfDayTheme
{
	TArray<class UFortTimeOfDayCollection*>            TimeOfDayCollections;                                     // 0x0000(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0010(0x0010) UNKNOWN PROPERTY: ArrayProperty FortniteGame.FortTimeOfDayTheme.AdditionalTimeOfDayManagers
	unsigned char                                      UnknownData01[0x10];                                      // 0x0020(0x0010) UNKNOWN PROPERTY: ArrayProperty FortniteGame.FortTimeOfDayTheme.ProhibitedTimeOfDayManagers
	unsigned char                                      UnknownData02[0x10];                                      // 0x0030(0x0010) UNKNOWN PROPERTY: ArrayProperty FortniteGame.FortTimeOfDayTheme.ValidTimeOfDayManagers
};

// ScriptStruct FortniteGame.FortWindIntensityAndDirection
// 0x0008
struct FFortWindIntensityAndDirection
{
	float                                              WindIntensity;                                            // 0x0000(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              WindHeading;                                              // 0x0004(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortGlobalWindInfo
// 0x0018
struct FFortGlobalWindInfo
{
	TArray<struct FFortWindIntensityAndDirection>      ValidWindInfos;                                           // 0x0000(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	int                                                WindIndex;                                                // 0x0010(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.MissionPerDifficultyProperties
// 0x0068
struct FMissionPerDifficultyProperties
{
	TArray<struct FDataTableRowHandle>                 ValidDifficulties;                                        // 0x0000(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FFortTimeOfDayTheme                         OverrideTimeOfDayTheme;                                   // 0x0010(0x0040) (Edit, DisableEditOnInstance)
	struct FFortGlobalWindInfo                         OverrideGlobalWindInfo;                                   // 0x0050(0x0018) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortMissionConfigDataBucket
// 0x0030
struct FFortMissionConfigDataBucket
{
	struct FGameplayTag                                Tag;                                                      // 0x0000(0x0008) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0008(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.FortMissionConfigDataBucket.ConfigDataClass
};

// ScriptStruct FortniteGame.FortMissionConfigDataParams
// 0x0010
struct FFortMissionConfigDataParams
{
	TArray<struct FFortMissionConfigDataBucket>        ConfigParams;                                             // 0x0000(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.TieredWaveSetCollectionData
// 0x0088
struct FTieredWaveSetCollectionData
{
	struct FText                                       DefenseText;                                              // 0x0000(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, EditConst)
	struct FText                                       LevelText;                                                // 0x0018(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, EditConst)
	struct FText                                       WaveText;                                                 // 0x0030(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, EditConst)
	struct FText                                       BreatherText;                                             // 0x0048(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, EditConst)
	int                                                MinLvl;                                                   // 0x0060(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                MaxLvl;                                                   // 0x0064(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	struct FName                                       BaseWaveLengthRowName;                                    // 0x0068(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       BaseNumOfKillsRowName;                                    // 0x0070(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       BaseNumOfKillPointsRowName;                               // 0x0078(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       WaveSet;                                                  // 0x0080(0x0008) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortMissionUIActorHandle
// 0x0030
struct FFortMissionUIActorHandle
{
	TWeakObjectPtr<class AActor>                       AttachedActor;                                            // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FVector                                     AttachmentOffset;                                         // 0x0008(0x000C) (IsPlainOldData)
	float                                              MaxVisibleDistance;                                       // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FGuid                                       MissionGuid;                                              // 0x0018(0x0010) (IsPlainOldData)
	TWeakObjectPtr<class UFortMissionInfoIndicator>    MissionUIIndicator;                                       // 0x0028(0x0008) (ZeroConstructor, Transient, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
};

// ScriptStruct FortniteGame.EarnedBadgePlayerData
// 0x0030
struct FEarnedBadgePlayerData
{
	struct FUniqueNetIdRepl                            PlayerID;                                                 // 0x0000(0x0028) (BlueprintVisible, BlueprintReadOnly, Transient)
	int                                                Count;                                                    // 0x0028(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.EarnedBadgeEntry
// 0x0024 (0x0030 - 0x000C)
struct FEarnedBadgeEntry : public FFastArraySerializerItem
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	class UFortBadgeItemDefinition*                    Badge;                                                    // 0x0010(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	TArray<struct FEarnedBadgePlayerData>              PlayerData;                                               // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient)
	TEnumAsByte<EFortRewardType>                       RewardType;                                               // 0x0028(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.EarnedBadgeEntryArray
// 0x0010 (0x00C0 - 0x00B0)
struct FEarnedBadgeEntryArray : public FFastArraySerializer
{
	TArray<struct FEarnedBadgeEntry>                   Items;                                                    // 0x00B0(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.MissionTimeDisplayData
// 0x002C
struct FMissionTimeDisplayData
{
	float                                              LessThanTimeValue;                                        // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bHideTimer;                                               // 0x0004(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0005(0x0003) MISSED OFFSET
	struct FLinearColor                                BaseColor;                                                // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance, IsPlainOldData)
	struct FLinearColor                                PulseColor;                                               // 0x0018(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance, IsPlainOldData)
	float                                              ColorPulsesPerSecond;                                     // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.MissionTimerData
// 0x0028
struct FMissionTimerData
{
	bool                                               bTimerIsPaused;                                           // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              OriginalTimePeriod;                                       // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              ReplicatedRemainingTime;                                  // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              ClientRemainingTime;                                      // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	unsigned char                                      UnknownData01[0x18];                                      // 0x0010(0x0018) MISSED OFFSET
};

// ScriptStruct FortniteGame.AthenaJumpPenalty
// 0x0008
struct FAthenaJumpPenalty
{
	float                                              JumpScalar;                                               // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MovementScalar;                                           // 0x0004(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.AirControlParams
// 0x00C8
struct FAirControlParams
{
	struct FScalableFloat                              MaxAcceleration;                                          // 0x0000(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FScalableFloat                              LateralFriction;                                          // 0x0028(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FScalableFloat                              MaxLateralSpeed;                                          // 0x0050(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FScalableFloat                              TerminalVelocity;                                         // 0x0078(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FScalableFloat                              GravityScalar;                                            // 0x00A0(0x0028) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.FortNavLinkPattern
// 0x0008
struct FFortNavLinkPattern
{
	int                                                PatternBits;                                              // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                WildcardBits;                                             // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.RestrictedCountry
// 0x0018
struct FRestrictedCountry
{
	struct FString                                     CountryCode;                                              // 0x0000(0x0010) (ZeroConstructor)
	bool                                               bHealthWarningsShown;                                     // 0x0010(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bRealMoneyStoreRestriction;                               // 0x0011(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0012(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.OutpostBuildingData
// 0x0028
struct FOutpostBuildingData
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.OutpostBuildingData.ItemDefinition
};

// ScriptStruct FortniteGame.CraftingTableBuildingData
// 0x0010 (0x0038 - 0x0028)
struct FCraftingTableBuildingData : public FOutpostBuildingData
{
	class UDataTable*                                  ActivationCostData;                                       // 0x0028(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UClass*                                      ActivationEffect;                                         // 0x0030(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.OutpostFabricatorPerTheaterData
// 0x0008
struct FOutpostFabricatorPerTheaterData
{
	int                                                TheaterSlot;                                              // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortItemTier>                         MaxAllowedTier;                                           // 0x0004(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0005(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.FabricatorBuildingData
// 0x0048 (0x0070 - 0x0028)
struct FFabricatorBuildingData : public FOutpostBuildingData
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0028(0x0010) UNKNOWN PROPERTY: ArrayProperty FortniteGame.FabricatorBuildingData.AlwaysAvailableFabricationItems
	class UDataTable*                                  DefaultIngredientDisintergrationData;                     // 0x0038(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TArray<struct FOutpostFabricatorPerTheaterData>    IngredientDisintergrationPerTheaterData;                  // 0x0040(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	float                                              FabricationDuration;                                      // 0x0050(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                DisintegrationToFabricationRatio;                         // 0x0054(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                QuantumGooProductionTime;                                 // 0x0058(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
	TArray<int>                                        QuantumGooCapacityPerLevel;                               // 0x0060(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.HarvestingOptimizerBuildingData
// 0x0000 (0x0028 - 0x0028)
struct FHarvestingOptimizerBuildingData : public FOutpostBuildingData
{

};

// ScriptStruct FortniteGame.StorageVaultBuildingData
// 0x0010 (0x0038 - 0x0028)
struct FStorageVaultBuildingData : public FOutpostBuildingData
{
	TArray<int>                                        ItemCapacityPerLevel;                                     // 0x0028(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.OutpostUpgradesPerTheaterData
// 0x0010
struct FOutpostUpgradesPerTheaterData
{
	int                                                TheaterSlot;                                              // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	class UDataTable*                                  OutpostUpgradesData;                                      // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.OutpostPrestigeEffects
// 0x0010
struct FOutpostPrestigeEffects
{
	TArray<class UClass*>                              EnemyPrestigeEffect;                                      // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.OutpostPrestigeEffectsPerTheater
// 0x0018
struct FOutpostPrestigeEffectsPerTheater
{
	int                                                TheaterSlot;                                              // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FOutpostPrestigeEffects                     PrestigeEffects;                                          // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.OutpostPOSTBoost
// 0x0010
struct FOutpostPOSTBoost
{
	struct FCurveTableRowHandle                        PlayerStructureHealthModPerPOSTLevel;                     // 0x0000(0x0010) (Edit, BlueprintVisible, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.OutpostPOSTPerTheaterData
// 0x0018
struct FOutpostPOSTPerTheaterData
{
	int                                                TheaterSlot;                                              // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FOutpostPOSTBoost                           POSTData;                                                 // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.OutpostUpgradeAndPrestigeBuildingData
// 0x0068 (0x0090 - 0x0028)
struct FOutpostUpgradeAndPrestigeBuildingData : public FOutpostBuildingData
{
	int                                                MaxPrestigeLevel;                                         // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	class UDataTable*                                  DefaultOutpostBuildingUpgradeData;                        // 0x0030(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TArray<struct FOutpostUpgradesPerTheaterData>      PerTheaterOutpostBuildingUpgradeData;                     // 0x0038(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FOutpostPrestigeEffects                     DefaultPrestigeData;                                      // 0x0048(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	TArray<struct FOutpostPrestigeEffectsPerTheater>   PrestigePerTheaterData;                                   // 0x0058(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FOutpostPOSTBoost                           DefaultPOSTData;                                          // 0x0068(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	TArray<struct FOutpostPOSTPerTheaterData>          POSTPerTheaterData;                                       // 0x0078(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	class UClass*                                      POSTBuildingGameplayEffectClass;                          // 0x0088(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.EmptyServerReservation
// 0x0058
struct FEmptyServerReservation
{
	int                                                PlaylistId;                                               // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     ZoneInstanceId;                                           // 0x0008(0x0010) (ZeroConstructor)
	struct FString                                     WUID;                                                     // 0x0018(0x0010) (ZeroConstructor)
	struct FUniqueNetIdRepl                            WorldDataOwner;                                           // 0x0028(0x0028)
	bool                                               bMakePrivate;                                             // 0x0050(0x0001) (ZeroConstructor, IsPlainOldData)
	EFortMatchmakingPool                               MatchmakingPool;                                          // 0x0051(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x0052(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortTeamMemberInfo
// 0x01A8
struct FFortTeamMemberInfo
{
	struct FUniqueNetIdRepl                            MemberUniqueId;                                           // 0x0000(0x0028) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FUniqueNetIdRepl                            PartyLeaderUniqueId;                                      // 0x0028(0x0028) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FUniqueNetIdRepl                            ConsoleUniqueId;                                          // 0x0050(0x0028) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FText                                       PlayerName;                                               // 0x0078(0x0018) (BlueprintVisible, BlueprintReadOnly)
	bool                                               bPartyLeader;                                             // 0x0090(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bIsInZone;                                                // 0x0091(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bHasBoostXp;                                              // 0x0092(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bHasRestXp;                                               // 0x0093(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                NumPlayersInParty;                                        // 0x0094(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                PlayerIndex;                                              // 0x0098(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortTeam>                             TeamAffiliation;                                          // 0x009C(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x009D(0x0003) MISSED OFFSET
	struct FText                                       HeroClass;                                                // 0x00A0(0x0018) (BlueprintVisible, BlueprintReadOnly)
	struct FText                                       HeroLevel;                                                // 0x00B8(0x0018) (BlueprintVisible, BlueprintReadOnly)
	int                                                HeroXP;                                                   // 0x00D0(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00D4(0x0004) MISSED OFFSET
	class UFortItem*                                   HeroItem;                                                 // 0x00D8(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TArray<class UFortItem*>                           SelectedGadgetItems;                                      // 0x00E0(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FSlateBrush                                 HeroIcon;                                                 // 0x00F0(0x0078) (BlueprintVisible, BlueprintReadOnly)
	struct FFortHomeBaseInfo                           HomeBaseInfo;                                             // 0x0168(0x0040) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.FortPartyRepState
// 0x0078 (0x0088 - 0x0010)
struct FFortPartyRepState : public FPartyState
{
	EFortPartyState                                    PartyProgression;                                         // 0x0010(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bLobbyConnectionStarted;                                  // 0x0011(0x0001) (ZeroConstructor, IsPlainOldData)
	EMatchmakingCompleteResult                         MatchmakingResult;                                        // 0x0012(0x0001) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EMatchmakingState>                     MatchmakingState;                                         // 0x0013(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     SessionId;                                                // 0x0018(0x0010) (ZeroConstructor)
	bool                                               bSessionIsCriticalMission;                                // 0x0028(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0029(0x0003) MISSED OFFSET
	int                                                ZoneTileIndex;                                            // 0x002C(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FString                                     ZoneInstanceId;                                           // 0x0030(0x0010) (ZeroConstructor)
	struct FString                                     TheaterId;                                                // 0x0040(0x0010) (ZeroConstructor)
	TArray<bool>                                       TileStates;                                               // 0x0050(0x0010) (ZeroConstructor)
	struct FString                                     BucketId;                                                 // 0x0060(0x0010) (ZeroConstructor)
	struct FString                                     CustomMatchKey;                                           // 0x0070(0x0010) (ZeroConstructor)
	EFortAthenaPlaylist                                PlaylistType;                                             // 0x0080(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bSquadFill;                                               // 0x0081(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x6];                                       // 0x0082(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortPartyMemberRepState
// 0x0078 (0x0080 - 0x0008)
struct FFortPartyMemberRepState : public FPartyMemberRepState
{
	EFortPartyMemberLocation                           Location;                                                 // 0x0008(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
	int                                                MatchmakingLevel;                                         // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FString                                     ZoneInstanceId;                                           // 0x0010(0x0010) (ZeroConstructor)
	int                                                CurrentCharXP;                                            // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FString                                     HeroId;                                                   // 0x0028(0x0010) (ZeroConstructor)
	struct FString                                     HeroTypeRefName;                                          // 0x0038(0x0010) (ZeroConstructor)
	TEnumAsByte<EFortCustomGender>                     CharacterGender;                                          // 0x0048(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
	int64_t                                            HomeBaseVersion;                                          // 0x0050(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FString                                     ConsoleOSSString;                                         // 0x0058(0x0010) (ZeroConstructor)
	struct FString                                     ConsoleUniqueNetIdString;                                 // 0x0068(0x0010) (ZeroConstructor)
	bool                                               bPreloadedAthena;                                         // 0x0078(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bReadyAthena;                                             // 0x0079(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bJoinedConsoleSession;                                    // 0x007A(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x5];                                       // 0x007B(0x0005) MISSED OFFSET
};

// ScriptStruct FortniteGame.BuildingHitTime
// 0x0018
struct FBuildingHitTime
{
	class ABuildingActor*                              HitBuilding;                                              // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0008(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortPlayerAttributeSets
// 0x0050
struct FFortPlayerAttributeSets
{
	class UFortRegenHealthSet*                         HealthSet;                                                // 0x0000(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference, IsPlainOldData)
	class UFortControlResistanceSet*                   ControlResistanceSet;                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference, IsPlainOldData)
	class UFortDamageSet*                              DamageSet;                                                // 0x0010(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference, IsPlainOldData)
	class UFortMovementSet*                            MovementSet;                                              // 0x0018(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference, IsPlainOldData)
	class UFortAdvancedMovementSet*                    AdvancedMovementSet;                                      // 0x0020(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference, IsPlainOldData)
	class UFortConstructionSet*                        ConstructionSet;                                          // 0x0028(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference, IsPlainOldData)
	class UFortPlayerAttrSet*                          PlayerAttrSet;                                            // 0x0030(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference, IsPlainOldData)
	class UFortCharacterAttrSet*                       CharacterAttrSet;                                         // 0x0038(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference, IsPlainOldData)
	class UFortWeaponAttrSet*                          WeaponAttrSet;                                            // 0x0040(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference, IsPlainOldData)
	class UFortHomebaseSet*                            HomebaseSet;                                              // 0x0048(0x0008) (Edit, BlueprintVisible, ExportObject, BlueprintReadOnly, ZeroConstructor, EditConst, InstancedReference, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortPlayerDeathReport
// 0x0050
struct FFortPlayerDeathReport
{
	float                                              ServerTimeForRespawn;                                     // 0x0000(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	float                                              ServerTimeForResurrect;                                   // 0x0004(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	float                                              LethalDamage;                                             // 0x0008(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	class AFortPlayerState*                            KillerPlayerState;                                        // 0x0010(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	class AFortPawn*                                   KillerPawn;                                               // 0x0018(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	class AActor*                                      DamageCauser;                                             // 0x0020(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      bDroppedBackpack : 1;                                     // 0x0028(0x0001) (BlueprintVisible, BlueprintReadOnly, Transient)
	unsigned char                                      bNotifyUI : 1;                                            // 0x0028(0x0001) (BlueprintVisible, BlueprintReadOnly, Transient)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
	struct FGameplayTagContainer                       Tags;                                                     // 0x0030(0x0020) (BlueprintVisible, BlueprintReadOnly, Transient)
};

// ScriptStruct FortniteGame.FortDepositedResources
// 0x0018
struct FFortDepositedResources
{
	struct FString                                     TemplateId;                                               // 0x0000(0x0010) (ZeroConstructor)
	int                                                Quantity;                                                 // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortInputActionGroupContext
// 0x0010
struct FFortInputActionGroupContext
{
	struct FName                                       ActionName;                                               // 0x0000(0x0008) (ZeroConstructor, Config, IsPlainOldData)
	EFortInputActionGroup                              InputActionGroup;                                         // 0x0008(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortInputActionKeyAlias
// 0x0028
struct FFortInputActionKeyAlias
{
	struct FName                                       ActionName;                                               // 0x0000(0x0008) (ZeroConstructor, Config, IsPlainOldData)
	struct FKey                                        KeyAlias;                                                 // 0x0008(0x0018) (Config)
	EFortInputActionType                               InputActionType;                                          // 0x0020(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.MorphValuePair
// 0x0010
struct FMorphValuePair
{
	struct FName                                       MorphName;                                                // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MorphValue;                                               // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortCharacterPartsRepMontageInfo
// 0x0020
struct FFortCharacterPartsRepMontageInfo
{
	TArray<struct FFortCharacterPartMontageInfo>       CharPartMontages;                                         // 0x0000(0x0010) (ZeroConstructor)
	class UAnimMontage*                                PawnMontage;                                              // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	bool                                               bPlayBit;                                                 // 0x0018(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.AthenaBatchedDamageGameplayCues
// 0x0058
struct FAthenaBatchedDamageGameplayCues
{
	class AActor*                                      HitActor;                                                 // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FVector_NetQuantize10                       Location;                                                 // 0x0008(0x000C)
	struct FVector_NetQuantizeNormal                   Normal;                                                   // 0x0014(0x000C)
	float                                              Magnitude;                                                // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bWeaponActivate;                                          // 0x0024(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bIsFatal;                                                 // 0x0025(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bIsCritical;                                              // 0x0026(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bIsShield;                                                // 0x0027(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bIsShieldDestroyed;                                       // 0x0028(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
	class AActor*                                      NonPlayerHitActor;                                        // 0x0030(0x0008) (ZeroConstructor, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	struct FVector_NetQuantize10                       NonPlayerLocation;                                        // 0x0038(0x000C) (RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	struct FVector_NetQuantizeNormal                   NonPlayerNormal;                                          // 0x0044(0x000C) (RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	float                                              NonPlayerMagnitude;                                       // 0x0050(0x0004) (ZeroConstructor, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	bool                                               NonPlayerbIsFatal;                                        // 0x0054(0x0001) (ZeroConstructor, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	bool                                               NonPlayerbIsCritical;                                     // 0x0055(0x0001) (ZeroConstructor, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	bool                                               bIsValid;                                                 // 0x0056(0x0001) (ZeroConstructor, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	unsigned char                                      UnknownData01[0x1];                                       // 0x0057(0x0001) MISSED OFFSET
};

// ScriptStruct FortniteGame.AccumulatedItemEntry
// 0x0010
struct FAccumulatedItemEntry
{
	class UFortWorldItemDefinition*                    ItemDefinition;                                           // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                Quantity;                                                 // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.DeathInfo
// 0x0010
struct FDeathInfo
{
	class AFortPlayerStateAthena*                      FinisherOrDowner;                                         // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	bool                                               bDBNO;                                                    // 0x0008(0x0001) (ZeroConstructor, IsPlainOldData)
	EDeathCause                                        DeathCause;                                               // 0x0009(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x000A(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.PlayerBannerInfo
// 0x0028
struct FPlayerBannerInfo
{
	struct FString                                     IconId;                                                   // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FString                                     ColorId;                                                  // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int                                                Level;                                                    // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.StrategicBuildingLevelCriteria
// 0x0020
struct FStrategicBuildingLevelCriteria
{
	struct FText                                       UnlockRequirementText;                                    // 0x0000(0x0018) (Edit, DisableEditOnInstance)
	EFortStrategicBuildingLevelCriteriaDisplayRepresentation RequirementDisplayRepresentation;                         // 0x0018(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0019(0x0003) MISSED OFFSET
	float                                              UnlockRequirementQuantity;                                // 0x001C(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.StrategicBuildingUpgradePathInfo
// 0x00B0
struct FStrategicBuildingUpgradePathInfo
{
	struct FText                                       UpgradeDesc;                                              // 0x0000(0x0018) (Edit, DisableEditOnInstance)
	struct FSlateBrush                                 UpgradeBrush;                                             // 0x0018(0x0078) (Edit, DisableEditOnInstance)
	struct FGameplayTagContainer                       UpgradeTags;                                              // 0x0090(0x0020) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.StrategicBuildingLevelUnlocks
// 0x0030
struct FStrategicBuildingLevelUnlocks
{
	TArray<struct FFortAbilitySetDeliveryInfo>         OwnerStrategicBuildingAbilitySetBuckets;                  // 0x0000(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FFortAbilitySetDeliveryInfo>         PawnPersistentAbilitySetBuckets;                          // 0x0010(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FProximityBasedGEDeliveryInfo>       ProximityBasedEffectBuckets;                              // 0x0020(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.StrategicBuildingLevelInformation
// 0x0068
struct FStrategicBuildingLevelInformation
{
	struct FStrategicBuildingLevelCriteria             UpgradeCriteria;                                          // 0x0000(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	TArray<struct FStrategicBuildingUpgradePathInfo>   UpgradePaths;                                             // 0x0020(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	struct FStrategicBuildingLevelUnlocks              LevelUnlocks;                                             // 0x0030(0x0030) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	float                                              ConstructionTime;                                         // 0x0060(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              DestructionRecoveryTime;                                  // 0x0064(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.TeamStrategicBuildingHandle
// 0x0004
struct FTeamStrategicBuildingHandle
{
	int                                                Handle;                                                   // 0x0000(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.StrategicBuildingActiveConstructionInfo
// 0x0010
struct FStrategicBuildingActiveConstructionInfo
{
	float                                              ConstructionStartTime;                                    // 0x0000(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              ConstructionEndTime;                                      // 0x0004(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                ConstructionLevel;                                        // 0x0008(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      bUnderConstruction : 1;                                   // 0x000C(0x0001) (Transient)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.StrategicBuildingLevelActiveCriteriaProgress
// 0x000C
struct FStrategicBuildingLevelActiveCriteriaProgress
{
	float                                              CurrentProgress;                                          // 0x0000(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              MaxProgress;                                              // 0x0004(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      bProgressAllowed : 1;                                     // 0x0008(0x0001) (Transient)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortPointOnCurveRange
// 0x0008
struct FFortPointOnCurveRange
{
	float                                              MinPercentage;                                            // 0x0000(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              MaxPercentage;                                            // 0x0004(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortPointsOnCurve
// 0x0038
struct FFortPointsOnCurve
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortPointsOnCurve.Curve
	TArray<struct FFortPointOnCurveRange>              RangesForPointsOnCurve;                                   // 0x0028(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortGameplayTagQueryPerDifficulty
// 0x0060
struct FFortGameplayTagQueryPerDifficulty
{
	struct FDataTableRowHandle                         DifficultyInfo;                                           // 0x0000(0x0010) (Edit, DisableEditOnInstance)
	struct FGameplayTagQuery                           TagQueryToMatch;                                          // 0x0010(0x0048) (Edit, DisableEditOnInstance)
	float                                              Difficulty;                                               // 0x0058(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.GoalDistanceData
// 0x0090
struct FGoalDistanceData
{
	bool                                               bIgnoreScreeningDistance;                                 // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FAIDataProviderFloatValue                   ScreeningTestMaxDistance;                                 // 0x0008(0x0030) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData01[0x28];                                      // 0x0038(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.GoalDistanceData.TestScoreCurve
	struct FAIDataProviderFloatValue                   CurveDistanceScale;                                       // 0x0060(0x0030) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortMcpQuestRewardInfo
// 0x0010
struct FFortMcpQuestRewardInfo
{
	TArray<struct FFortItemQuantityPair>               Rewards;                                                  // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortMcpQuestObjectiveInfo
// 0x0110
struct FFortMcpQuestObjectiveInfo
{
	struct FName                                       BackendName;                                              // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FDataTableRowHandle                         ObjectiveStatHandle;                                      // 0x0008(0x0010) (Edit)
	TArray<struct FDataTableRowHandle>                 AlternativeStatHandles;                                   // 0x0018(0x0010) (Edit, ZeroConstructor)
	EFortQuestObjectiveItemEvent                       ItemEvent;                                                // 0x0028(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0029(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0029(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortMcpQuestObjectiveInfo.ItemReference
	struct FString                                     ItemTemplateIdOverride;                                   // 0x0058(0x0010) (Edit, ZeroConstructor)
	struct FName                                       LinkSquadID;                                              // 0x0068(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                LinkSquadIndex;                                           // 0x0070(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	EFortInventoryFilter                               LinkVaultTab;                                             // 0x0074(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EFortFrontendInventoryFilter                       LinkToItemManagement;                                     // 0x0075(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x2];                                       // 0x0076(0x0002) MISSED OFFSET
	struct FText                                       Description;                                              // 0x0078(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FText                                       HudShortDescription;                                      // 0x0090(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData03[0x28];                                      // 0x00A8(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortMcpQuestObjectiveInfo.HudIcon
	int                                                Count;                                                    // 0x00D0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                Stage;                                                    // 0x00D4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bHidden;                                                  // 0x00D8(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bRequirePrimaryMissionCompletion;                         // 0x00D9(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bCanProgressInZone;                                       // 0x00DA(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bDisplayDynamicAnnouncementUpdate;                        // 0x00DB(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bDisplayDynamicStatusUpdate;                              // 0x00DC(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x3];                                       // 0x00DD(0x0003) MISSED OFFSET
	float                                              DynamicUpdateCompletionDelay;                             // 0x00E0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x4];                                       // 0x00E4(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData06[0x28];                                      // 0x00E4(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.FortMcpQuestObjectiveInfo.ScriptedAction
};

// ScriptStruct FortniteGame.FortQuestMissionCreationContext
// 0x0040
struct FFortQuestMissionCreationContext
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortQuestMissionCreationContext.MissionInfo
	TArray<struct FGameplayTagContainer>               MissionCreationContextTags;                               // 0x0028(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	bool                                               bSetQuestOwnerAsMissionOwner;                             // 0x0038(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0039(0x0003) MISSED OFFSET
	int                                                MaxNumberToSpawnInWorld;                                  // 0x003C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortCategoryTableRow
// 0x0020 (0x0028 - 0x0008)
struct FFortCategoryTableRow : public FTableRowBase
{
	struct FText                                       Name;                                                     // 0x0008(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	int                                                SortPriority;                                             // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortRarityItemData
// 0x0080
struct FFortRarityItemData
{
	struct FText                                       Name;                                                     // 0x0000(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FLinearColor                                Color1;                                                   // 0x0018(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FLinearColor                                Color2;                                                   // 0x0028(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FLinearColor                                Color3;                                                   // 0x0038(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FLinearColor                                Color4;                                                   // 0x0048(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	struct FLinearColor                                Color5;                                                   // 0x0058(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	float                                              Radius;                                                   // 0x0068(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Falloff;                                                  // 0x006C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Brightness;                                               // 0x0070(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Roughness;                                                // 0x0074(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Glow;                                                     // 0x0078(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x007C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.Recipe
// 0x0050 (0x0058 - 0x0008)
struct FRecipe : public FTableRowBase
{
	TArray<struct FFortItemQuantityPair>               RecipeResults;                                            // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	bool                                               bIsConsumed;                                              // 0x0018(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
	TArray<struct FFortItemQuantityPair>               RecipeCosts;                                              // 0x0020(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FGameplayTagContainer                       RequiredCatalysts;                                        // 0x0030(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	int                                                Score;                                                    // 0x0050(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0054(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortScoreStylingInfo
// 0x02F8
struct FFortScoreStylingInfo
{
	struct FText                                       Name;                                                     // 0x0000(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FFortMultiSizeBrush                         Icon;                                                     // 0x0018(0x02D0) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FLinearColor                                Color;                                                    // 0x02E8(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortScriptedActionParams
// 0x0030
struct FFortScriptedActionParams
{
	class AFortPlayerController*                       Player;                                                   // 0x0000(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EFortScriptedActionSource                          SourceType;                                               // 0x0008(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
	class UFortItem*                                   SourceItem;                                               // 0x0010(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FDataTableRowHandle                         SourceData;                                               // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly)
	struct FName                                       SourceName;                                               // 0x0028(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortAvailableScriptedAction
// 0x0038
struct FFortAvailableScriptedAction
{
	struct FFortScriptedActionParams                   Params;                                                   // 0x0000(0x0030)
	class AFortScriptedAction*                         ActionDefaults;                                           // 0x0030(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortSearchPassParams
// 0x0028
struct FFortSearchPassParams
{
	int                                                ControllerId;                                             // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FName                                       SessionName;                                              // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FString                                     BestDatacenterId;                                         // 0x0010(0x0010) (ZeroConstructor)
	int                                                MaxProcessedSearchResults;                                // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortSearchPassState
// 0x0018
struct FFortSearchPassState
{
	int                                                BestSessionIdx;                                           // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bWasCanceled;                                             // 0x0004(0x0001) (ZeroConstructor, IsPlainOldData)
	EFortSessionHelperJoinResult                       FailureType;                                              // 0x0005(0x0001) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EMatchmakingState>                     MatchmakingState;                                         // 0x0006(0x0001) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EPartyReservationResult>               LastBeaconResponse;                                       // 0x0007(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0008(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortGlobalMission
// 0x0178
struct FFortGlobalMission
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortGlobalMission.MissionInfo
	TArray<EFortTheaterType>                           AllowedTheaterTypes;                                      // 0x0028(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	struct FGameplayTagQuery                           TheaterTagQuery;                                          // 0x0038(0x0048) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FGameplayTagQuery                           RegionTagQuery;                                           // 0x0080(0x0048) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	TArray<EFortZoneType>                              AllowedZoneTypes;                                         // 0x00C8(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	struct FGameplayTagQuery                           ZoneTagQuery;                                             // 0x00D8(0x0048) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FGameplayTagQuery                           PrimaryMissionTagQuery;                                   // 0x0120(0x0048) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	float                                              MaxDifficultyLevel;                                       // 0x0168(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              MinDifficultyLevel;                                       // 0x016C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bIsPrototype;                                             // 0x0170(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bAllowInTestMaps;                                         // 0x0171(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x0172(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortQuestDrivenMission
// 0x0008 (0x0180 - 0x0178)
struct FFortQuestDrivenMission : public FFortGlobalMission
{
	class UFortQuestItemDefinition*                    RequiredQuest;                                            // 0x0178(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortSplineBase
// 0x0010
struct FFortSplineBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
	float                                              StartTime;                                                // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Duration;                                                 // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortCatmullRomSpline
// 0x0010 (0x0020 - 0x0010)
struct FFortCatmullRomSpline : public FFortSplineBase
{
	TArray<struct FVector>                             ControlPoints;                                            // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortEventConditional
// 0x0038
struct FFortEventConditional
{
	TEnumAsByte<EFortEventConditionType>               ConditionalType;                                          // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FName                                       StatToCompare;                                            // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	EStatRecordingPeriod                               RelevantPeriod;                                           // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortCompare>                          ComparisonType;                                           // 0x0011(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x0012(0x0002) MISSED OFFSET
	int                                                Value;                                                    // 0x0014(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UFortSchematicItemDefinition*                CraftingItem;                                             // 0x0018(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bCanCraft;                                                // 0x0020(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0021(0x0007) MISSED OFFSET
	class UStat*                                       Stat;                                                     // 0x0028(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	class AFortPlayerController*                       FPC;                                                      // 0x0030(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortStatEvent
// 0x0050
struct FFortStatEvent
{
	struct FName                                       StatEventName;                                            // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortEventRepeat>                      RepeatType;                                               // 0x0008(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
	TArray<struct FName>                               StatsToMonitor;                                           // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FFortEventConditional>               Conditions;                                               // 0x0020(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	class UClass*                                      AnnouncementToDisplay;                                    // 0x0030(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UObject*                                     NotificationParameter;                                    // 0x0038(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	class UStat*                                       AssociatedStat;                                           // 0x0040(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	class AFortPlayerController*                       FPC;                                                      // 0x0048(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortStatEventSequence
// 0x0050
struct FFortStatEventSequence
{
	struct FName                                       StatEventName;                                            // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortEventRepeat>                      RepeatType;                                               // 0x0008(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
	TArray<struct FFortStatEvent>                      EventSequence;                                            // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	class UStat*                                       AssociatedStat;                                           // 0x0020(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	class AFortPlayerController*                       FPC;                                                      // 0x0028(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TArray<struct FName>                               StatsToMonitor;                                           // 0x0030(0x0010) (ZeroConstructor)
	TArray<struct FFortEventConditional>               Conditions;                                               // 0x0040(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.TransformableNavLinkClass
// 0x0020
struct FTransformableNavLinkClass
{
	struct FVector                                     Translation;                                              // 0x0000(0x000C) (Edit, IsPlainOldData)
	struct FRotator                                    Rotation;                                                 // 0x000C(0x000C) (Edit, IsPlainOldData)
	class UClass*                                      NavigationLinksClass;                                     // 0x0018(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortTagUIData
// 0x0308
struct FFortTagUIData
{
	struct FGameplayTag                                Tag;                                                      // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FFortMultiSizeBrush                         Icon;                                                     // 0x0008(0x02D0) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FText                                       DisplayName;                                              // 0x02D8(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FText                                       Description;                                              // 0x02F0(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.TeamSpottedActorInfo
// 0x0014 (0x0020 - 0x000C)
struct FTeamSpottedActorInfo : public FFastArraySerializerItem
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	class AFortPlayerController*                       Spotter;                                                  // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	class AActor*                                      SpottedActor;                                             // 0x0018(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.TeamSpottedActorInfoArray
// 0x0018 (0x00C8 - 0x00B0)
struct FTeamSpottedActorInfoArray : public FFastArraySerializer
{
	TArray<struct FTeamSpottedActorInfo>               SpottedActorInfo;                                         // 0x00B0(0x0010) (ZeroConstructor)
	class AFortTeamInfo*                               OwningTeam;                                               // 0x00C0(0x0008) (ZeroConstructor, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
};

// ScriptStruct FortniteGame.TeamStrategicBuildingEntry
// 0x000C (0x0018 - 0x000C)
struct FTeamStrategicBuildingEntry : public FFastArraySerializerItem
{
	struct FTeamStrategicBuildingHandle                StrategicBuildingHandle;                                  // 0x000C(0x0004) (Transient)
	class AStrategicBuildingActor*                     StrategicBuilding;                                        // 0x0010(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.TeamStrategicBuildingEntryArray
// 0x0010 (0x00C0 - 0x00B0)
struct FTeamStrategicBuildingEntryArray : public FFastArraySerializer
{
	TArray<struct FTeamStrategicBuildingEntry>         Items;                                                    // 0x00B0(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.TeamFOBCoreBuildingEntry
// 0x002C (0x0038 - 0x000C)
struct FTeamFOBCoreBuildingEntry : public FFastArraySerializerItem
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	class ABuildingFOBCoreActor*                       FOB;                                                      // 0x0010(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	struct FGameplayTagContainer                       SpawnLocationTags;                                        // 0x0018(0x0020) (Transient)
};

// ScriptStruct FortniteGame.TeamFOBCoreBuildingEntryArray
// 0x0010 (0x00C0 - 0x00B0)
struct FTeamFOBCoreBuildingEntryArray : public FFastArraySerializer
{
	TArray<struct FTeamFOBCoreBuildingEntry>           Items;                                                    // 0x00B0(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.PrivateTeamDataItem
// 0x0034 (0x0040 - 0x000C)
struct FPrivateTeamDataItem : public FFastArraySerializerItem
{
	float                                              Value;                                                    // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FUniqueNetIdRepl                            PlayerID;                                                 // 0x0010(0x0028)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0038(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.PrivateTeamDataArray
// 0x0068 (0x0118 - 0x00B0)
struct FPrivateTeamDataArray : public FFastArraySerializer
{
	TArray<struct FPrivateTeamDataItem>                Items;                                                    // 0x00B0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x58];                                      // 0x00C0(0x0058) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortMissionAlertAvailableData
// 0x0008
struct FFortMissionAlertAvailableData
{
	EFortMissionAlertCategory                          MissionAlertCategory;                                     // 0x0000(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                NumMissionAlertsAvailable;                                // 0x0004(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortTheaterMapMissionAlertData
// 0x0020
struct FFortTheaterMapMissionAlertData
{
	int                                                NumMissionAlertsAvailable;                                // 0x0000(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	TArray<struct FFortMissionAlertAvailableData>      AvailabilityDataPerCategory;                              // 0x0008(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	float                                              MissionAlertChangeFrequency;                              // 0x0018(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortEditorTheaterMapRegionColor
// 0x0018
struct FFortEditorTheaterMapRegionColor
{
	class UFortRegionInfo*                             Region;                                                   // 0x0000(0x0008) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	struct FLinearColor                                RegionColor;                                              // 0x0008(0x0010) (Edit, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortTheaterTileEditorData
// 0x00C0
struct FFortTheaterTileEditorData
{
	int                                                XCoordinate;                                              // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                YCoordinate;                                              // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	class UClass*                                      ZoneTheme;                                                // 0x0008(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UFortRegionInfo*                             Region;                                                   // 0x0010(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FFortRequirementsInfo                       Requirements;                                             // 0x0018(0x0048) (Edit, DisableEditOnInstance)
	TArray<struct FFortLinkedQuest>                    LinkedQuests;                                             // 0x0060(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	EFortTheaterMapTileType                            TileType;                                                 // 0x0070(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0071(0x0007) MISSED OFFSET
	struct FGameplayTagContainer                       TileTags;                                                 // 0x0078(0x0020) (Edit, DisableEditOnInstance)
	TArray<struct FFortTheaterMissionWeight>           MissionWeightOverrides;                                   // 0x0098(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FFortTheaterDifficultyWeight>        DifficultyWeightOverrides;                                // 0x00A8(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	bool                                               bCanBeMissionAlert;                                       // 0x00B8(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x00B9(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortHexMapCoord
// 0x000C
struct FFortHexMapCoord
{
	int                                                Horizontal;                                               // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                Vertical;                                                 // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                Depth;                                                    // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.ThreatLocationInfo
// 0x0054 (0x0060 - 0x000C)
struct FThreatLocationInfo : public FFastArraySerializerItem
{
	struct FVector                                     CloudLocation;                                            // 0x000C(0x000C) (BlueprintVisible, BlueprintReadOnly, Transient, IsPlainOldData)
	struct FBox                                        ThreatVolume;                                             // 0x0018(0x001C) (BlueprintVisible, BlueprintReadOnly, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
	class AFortThreatVisualsManager*                   ThreatVisualsManager;                                     // 0x0038(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TWeakObjectPtr<class AThreatCloud>                 CloudActor;                                               // 0x0040(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	unsigned char                                      UnknownData01[0x1];                                       // 0x0048(0x0001) MISSED OFFSET
	bool                                               bThreatActivated;                                         // 0x0049(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	EFortThreatDeactivationType                        DeactivationType;                                         // 0x004A(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData02[0x15];                                      // 0x004B(0x0015) MISSED OFFSET
};

// ScriptStruct FortniteGame.ThreatLocationArray
// 0x0010 (0x00C0 - 0x00B0)
struct FThreatLocationArray : public FFastArraySerializer
{
	TArray<struct FThreatLocationInfo>                 Locations;                                                // 0x00B0(0x0010) (ZeroConstructor, Transient)
};

// ScriptStruct FortniteGame.FortWindImpulseHandle
// 0x0004
struct FFortWindImpulseHandle
{
	int                                                UID;                                                      // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.StormWind
// 0x0044 (0x0050 - 0x000C)
struct FStormWind : public FFastArraySerializerItem
{
	struct FVector                                     Location;                                                 // 0x000C(0x000C) (Transient, IsPlainOldData)
	struct FVector                                     Direction;                                                // 0x0018(0x000C) (Transient, IsPlainOldData)
	float                                              Radius;                                                   // 0x0024(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              Magnitude;                                                // 0x0028(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	class AFortThreatVisualsManager*                   ThreatVisualsManager;                                     // 0x0030(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TArray<class UFortAIEncounterInfo*>                Encounters;                                               // 0x0038(0x0010) (ZeroConstructor, Transient, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	struct FFortWindImpulseHandle                      WindHandle;                                               // 0x0048(0x0004) (Transient, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	unsigned char                                      UnknownData01[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.StormWindArray
// 0x0010 (0x00C0 - 0x00B0)
struct FStormWindArray : public FFastArraySerializer
{
	TArray<struct FStormWind>                          StormWinds;                                               // 0x00B0(0x0010) (ZeroConstructor, Transient)
};

// ScriptStruct FortniteGame.TieredCollectionProgressionDataBase
// 0x0001
struct FTieredCollectionProgressionDataBase
{
	ECollectionSelectionMethod                         SelectionMethod;                                          // 0x0000(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.TieredNamedCollectionProgressionData
// 0x0017 (0x0018 - 0x0001)
struct FTieredNamedCollectionProgressionData : public FTieredCollectionProgressionDataBase
{
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<struct FName>                               CollectionNames;                                          // 0x0008(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.DifficultyRowProgression
// 0x0030
struct FDifficultyRowProgression
{
	struct FName                                       DifficultyRowName;                                        // 0x0000(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FScalableFloat                              AdditiveDifficultyMod;                                    // 0x0008(0x0028) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.DifficultyCollectionProgressionData
// 0x0017 (0x0018 - 0x0001)
struct FDifficultyCollectionProgressionData : public FTieredCollectionProgressionDataBase
{
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<struct FDifficultyRowProgression>           DifficultyCollections;                                    // 0x0008(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.RewardBadgesProgression
// 0x0010
struct FRewardBadgesProgression
{
	TArray<class UFortBadgeItemDefinition*>            RewardBadges;                                             // 0x0000(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.RewardBadgesCollectionProgressionData
// 0x0017 (0x0018 - 0x0001)
struct FRewardBadgesCollectionProgressionData : public FTieredCollectionProgressionDataBase
{
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<struct FRewardBadgesProgression>            BadgeCollections;                                         // 0x0008(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.CollectionLootSetData
// 0x0017 (0x0018 - 0x0001)
struct FCollectionLootSetData : public FTieredCollectionProgressionDataBase
{
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<struct FName>                               LootSetNames;                                             // 0x0008(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.CameraAltitudeAdjustments
// 0x0010
struct FCameraAltitudeAdjustments
{
	float                                              Altitude;                                                 // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              FogHeightFalloff;                                         // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              HeightFogZOffset;                                         // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              FogDensity;                                               // 0x000C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.SkyLightValues
// 0x0028
struct FSkyLightValues
{
	struct FLinearColor                                SkyLightColor;                                            // 0x0000(0x0010) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FLinearColor                                SkyLightOcclusionTint;                                    // 0x0010(0x0010) (Edit, DisableEditOnInstance, IsPlainOldData)
	float                                              SkyLightMinOcclusion;                                     // 0x0020(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              VolumetricScatteringIntensity;                            // 0x0024(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.CloudColorState
// 0x0050
struct FCloudColorState
{
	struct FLinearColor                                BottomEmissive;                                           // 0x0000(0x0010) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FLinearColor                                TopEmissive;                                              // 0x0010(0x0010) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FLinearColor                                BottomLightning;                                          // 0x0020(0x0010) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FLinearColor                                TopLightning;                                             // 0x0030(0x0010) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FLinearColor                                InternalColor;                                            // 0x0040(0x0010) (Edit, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.ThreatCloudValues
// 0x00A0
struct FThreatCloudValues
{
	struct FCloudColorState                            CloudActivated;                                           // 0x0000(0x0050) (Edit, DisableEditOnInstance)
	struct FCloudColorState                            CloudDeactivated;                                         // 0x0050(0x0050) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.ElementalCharValues
// 0x0014
struct FElementalCharValues
{
	struct FLinearColor                                FireCharColor;                                            // 0x0000(0x0010) (Edit, DisableEditOnInstance, IsPlainOldData)
	float                                              ElectricalCharEmissive;                                   // 0x0010(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.DirectionalLightValues
// 0x000C
struct FDirectionalLightValues
{
	struct FColor                                      LightColor;                                               // 0x0000(0x0004) (Edit, IsPlainOldData)
	float                                              Brightness;                                               // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              VolumetricScatteringIntensity;                            // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.ExponentialHeightFogValues
// 0x0044
struct FExponentialHeightFogValues
{
	float                                              FogDensity;                                               // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              FogHeightFalloff;                                         // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              FogMaxOpacity;                                            // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              StartDistance;                                            // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              DirectionalInscatteringExponent;                          // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              DirectionalInscatteringStartDistance;                     // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                DirectionalInscatteringColor;                             // 0x0018(0x0010) (Edit, BlueprintVisible, IsPlainOldData)
	struct FLinearColor                                FogInscatteringColor;                                     // 0x0028(0x0010) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              VolumetricFogScatteringDistribution;                      // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              VolumetricFogExtinctionScale;                             // 0x003C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              VolumetricFogDistance;                                    // 0x0040(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.DayPhaseInfo
// 0x0170
struct FDayPhaseInfo
{
	struct FString                                     PhaseStartAnnouncement;                                   // 0x0000(0x0010) (ZeroConstructor)
	float                                              TimePhaseBegins;                                          // 0x0010(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              PhaseLengthInHours;                                       // 0x0014(0x0004) (Edit, ZeroConstructor, Transient, EditConst, IsPlainOldData)
	float                                              PercentageTransitionIn;                                   // 0x0018(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              TransitionInTimeInMinutes;                                // 0x001C(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              PercentageTransitionOut;                                  // 0x0020(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              TransitionOutTimeInMinutes;                               // 0x0024(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	struct FSkyLightValues                             SkyLightValues;                                           // 0x0028(0x0028) (Edit)
	struct FThreatCloudValues                          ThreatCloudValues;                                        // 0x0050(0x00A0) (Edit)
	struct FElementalCharValues                        ElementalCharValues;                                      // 0x00F0(0x0014) (Edit)
	struct FDirectionalLightValues                     DirectionalLightValues;                                   // 0x0104(0x000C) (Edit)
	struct FExponentialHeightFogValues                 ExpHeightFogValues;                                       // 0x0110(0x0044) (Edit)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0154(0x0004) MISSED OFFSET
	class UPostProcessComponent*                       LowPriPostProcessComponent;                               // 0x0158(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	class UMaterialInstance*                           SkyMaterialInstance;                                      // 0x0160(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UMaterialInstance*                           StarMapMaterialInstance;                                  // 0x0168(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortTokenContextInfo
// 0x0038
struct FFortTokenContextInfo
{
	struct FGameplayTagContainer                       RequiredContextTags;                                      // 0x0000(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FText                                       Text;                                                     // 0x0020(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.FortTooltipTokenInfo
// 0x0018
struct FFortTooltipTokenInfo
{
	struct FGameplayTag                                Token;                                                    // 0x0000(0x0008) (Edit)
	TArray<struct FFortTokenContextInfo>               ContextDetails;                                           // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortTooltipDisplayStatInfo
// 0x0050
struct FFortTooltipDisplayStatInfo
{
	struct FGameplayTag                                Token;                                                    // 0x0000(0x0008) (Edit, DisableEditOnInstance)
	struct FGameplayAttribute                          Attribute;                                                // 0x0008(0x0020) (Edit, DisableEditOnInstance)
	struct FGameplayTagContainer                       ContextTags;                                              // 0x0028(0x0020) (Edit, DisableEditOnInstance)
	bool                                               bLowerIsBetter;                                           // 0x0048(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortTooltipDisplayStatsCategory
// 0x0028
struct FFortTooltipDisplayStatsCategory
{
	struct FText                                       CategoryName;                                             // 0x0000(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	TArray<struct FFortTooltipDisplayStatInfo>         TooltipStats;                                             // 0x0018(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortTooltipDisplayInfo
// 0x0038
struct FFortTooltipDisplayInfo
{
	class UClass*                                      PrimaryObjectClass;                                       // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UClass*                                      SecondaryObjectClass;                                     // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FGameplayTagContainer                       DescriptionStatsTags;                                     // 0x0010(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	class UFortTooltipDisplayStatsList*                TooltipStatsList;                                         // 0x0030(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortTooltipMapEntry
// 0x0018
struct FFortTooltipMapEntry
{
	class UClass*                                      ObjectClass;                                              // 0x0000(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UClass*                                      SecondaryObjectClass;                                     // 0x0008(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UClass*                                      TooltipClass;                                             // 0x0010(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.TrackConnectorMeshConfig
// 0x0010
struct FTrackConnectorMeshConfig
{
	ETrackIncline                                      InclineSideA;                                             // 0x0000(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	ETrackIncline                                      InclineSideB;                                             // 0x0001(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0002(0x0006) MISSED OFFSET
	class UStaticMesh*                                 Mesh;                                                     // 0x0008(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.TrackMovement
// 0x0010
struct FTrackMovement
{
	class USplineComponent*                            CurrentSpline;                                            // 0x0000(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	float                                              DistanceAlongSpline;                                      // 0x0008(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bReverseDirectionAlongSpline;                             // 0x000C(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.RepTrackMovement
// 0x0008 (0x0018 - 0x0010)
struct FRepTrackMovement : public FTrackMovement
{
	float                                              Timestamp;                                                // 0x0010(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortUIFeedback
// 0x0020
struct FFortUIFeedback
{
	struct FName                                       Name;                                                     // 0x0000(0x0008) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	class USoundBase*                                  Audio;                                                    // 0x0008(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bLooping;                                                 // 0x0010(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	float                                              FadeIn;                                                   // 0x0014(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              FadeOut;                                                  // 0x0018(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortUIFeedbackBlueprintOnly
// 0x0008 (0x0028 - 0x0020)
struct FFortUIFeedbackBlueprintOnly : public FFortUIFeedback
{
	struct FName                                       EditableName;                                             // 0x0020(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortLevelStreamingInfo
// 0x0010
struct FFortLevelStreamingInfo
{
	struct FName                                       PackageName;                                              // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EFortLevelStreamingState>              LevelState;                                               // 0x0008(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bFailedToLoad;                                            // 0x0009(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x000A(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortLootQuotaData
// 0x0020 (0x0028 - 0x0008)
struct FFortLootQuotaData : public FTableRowBase
{
	struct FName                                       QuotaCategory;                                            // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ELootQuotaLevel>                       QuotaLevel;                                               // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	int                                                Min;                                                      // 0x0014(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Max;                                                      // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Quota;                                                    // 0x001C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MinWorldLevel;                                            // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaxWorldLevel;                                            // 0x0024(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortTileLootData
// 0x0318
struct FFortTileLootData
{
	struct FFortLootQuotaData                          LootQuotas[0x12];                                         // 0x0000(0x0028)
	int                                                LootDrops[0x12];                                          // 0x02D0(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.WorldTileSubArray
// 0x0010
struct FWorldTileSubArray
{
	TArray<class AWorldTileFoundation*>                X;                                                        // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortStartingMissionInfo
// 0x0018
struct FFortStartingMissionInfo
{
	TArray<class UFortMissionInfo*>                    StartingMissions;                                         // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	bool                                               bDisableSharedMissionLoading;                             // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortMissionPlacementItemLookupData
// 0x0078
struct FFortMissionPlacementItemLookupData
{
	struct FGameplayTagContainer                       ItemIdentifyingTags;                                      // 0x0000(0x0020) (Transient)
	struct FGameplayTagContainer                       TagsAddedToPlacementActors;                               // 0x0020(0x0020) (Transient)
	class UClass*                                      ActorToPlace;                                             // 0x0040(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	class AActor*                                      ActorToUseForSpawnLocation;                               // 0x0048(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	class AActor*                                      SpawnedActor;                                             // 0x0050(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	struct FVector                                     SpawnLocation;                                            // 0x0058(0x000C) (Transient, IsPlainOldData)
	struct FRotator                                    SpawnRotation;                                            // 0x0064(0x000C) (Transient, IsPlainOldData)
	unsigned char                                      bDontCreateSpawnRiftsNearby : 1;                          // 0x0070(0x0001) (Transient)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0071(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortMissionEntry
// 0x0088
struct FFortMissionEntry
{
	float                                              Weight;                                                   // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                WorldMinLevel;                                            // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                WorldMaxLevel;                                            // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FDataTableRowHandle                         MinDifficultyInfoRow;                                     // 0x0010(0x0010) (Edit)
	class UFortMissionGenerator*                       MissionGenerator;                                         // 0x0020(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UFortMissionInfo*                            MissionInfo;                                              // 0x0028(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EMissionGenerationCategory>            GenerationCategory;                                       // 0x0030(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
	struct FFortGeneratedDifficultyOptions             GeneratedDifficultyOptions;                               // 0x0038(0x0040)
	TArray<struct FFortMissionPlacementItemLookupData> BlueprintLookupData;                                      // 0x0078(0x0010) (ZeroConstructor, Transient)
};

// ScriptStruct FortniteGame.FortObjectiveRecord
// 0x0018
struct FFortObjectiveRecord
{
	class UClass*                                      ObjectiveClass;                                           // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	TArray<unsigned char>                              ObjectiveData;                                            // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortMissionRecord
// 0x0138
struct FFortMissionRecord
{
	struct FFortMissionEntry                           MissionEntry;                                             // 0x0000(0x0088)
	class UFortMissionGenerator*                       MissionGenerator;                                         // 0x0088(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	struct FFortGeneratedDifficultyOptions             GeneratedMissionOptions;                                  // 0x0090(0x0040) (Transient)
	int                                                DayGenerated;                                             // 0x00D0(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                UIIndex;                                                  // 0x00D4(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FUniqueNetIdRepl                            QuestOwnerAccount;                                        // 0x00D8(0x0028)
	EFortMissionStatus                                 MissionStatus;                                            // 0x0100(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0101(0x0007) MISSED OFFSET
	TArray<struct FFortObjectiveRecord>                ObjectiveRecords;                                         // 0x0108(0x0010) (ZeroConstructor)
	TArray<unsigned char>                              MissionData;                                              // 0x0118(0x0010) (ZeroConstructor)
	struct FGuid                                       MissionGuid;                                              // 0x0128(0x0010) (IsPlainOldData)
};

// ScriptStruct FortniteGame.FortMissionManagerRecord
// 0x0038
struct FFortMissionManagerRecord
{
	class UClass*                                      MissionManagerClass;                                      // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	TArray<struct FFortMissionRecord>                  MissionRecords;                                           // 0x0008(0x0010) (ZeroConstructor)
	int                                                NumRequiredMissionsOfType[0x4];                           // 0x0018(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	TArray<unsigned char>                              MissionManagerData;                                       // 0x0028(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortDeferredNewActorData
// 0x0010
struct FFortDeferredNewActorData
{
	class ABuildingActor*                              BuildingActor;                                            // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                SavedLevelIndex;                                          // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                ActorRecordIndex;                                         // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.VisibilityInfo
// 0x001C (0x0028 - 0x000C)
struct FVisibilityInfo : public FFastArraySerializerItem
{
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	class AActor*                                      Actor;                                                    // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	class UFortVisibilityComponent*                    VisibilityComponent;                                      // 0x0018(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	uint16_t                                           TeamVisibilityFlag;                                       // 0x0020(0x0002) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x0022(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.VisibiltyInfoArray
// 0x0010 (0x00C0 - 0x00B0)
struct FVisibiltyInfoArray : public FFastArraySerializer
{
	TArray<struct FVisibilityInfo>                     VisibilityInfoArray;                                      // 0x00B0(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortEffectDistanceQuality
// 0x0018
struct FFortEffectDistanceQuality
{
	float                                              MinDistanceCinematic;                                     // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MinDistanceEpic;                                          // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MinDistanceHigh;                                          // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MinDistanceMedium;                                        // 0x000C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              MinDistanceLow;                                           // 0x0010(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bAllowCinematic : 1;                                      // 0x0014(0x0001)
	unsigned char                                      bAllowEpic : 1;                                           // 0x0014(0x0001)
	unsigned char                                      bAllowHigh : 1;                                           // 0x0014(0x0001)
	unsigned char                                      bAllowMedium : 1;                                         // 0x0014(0x0001)
	unsigned char                                      bAllowLow : 1;                                            // 0x0014(0x0001)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortWindImpulseRadius
// 0x004C
struct FFortWindImpulseRadius
{
	struct FVector                                     Location;                                                 // 0x0000(0x000C) (Edit, IsPlainOldData)
	float                                              Radius;                                                   // 0x000C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              CurrentRadius;                                            // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              PreviousRadius;                                           // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Magnitude;                                                // 0x0018(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              CurrentMagnitude;                                         // 0x001C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              PreviousMagnitude;                                        // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              BlendTime;                                                // 0x0024(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              CurrentBlendTime;                                         // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FBox                                        WorldBounds;                                              // 0x002C(0x001C) (IsPlainOldData)
	struct FFortWindImpulseHandle                      Handle;                                                   // 0x0048(0x0004) (Transient)
};

// ScriptStruct FortniteGame.FortWindImpulseCylinderDelta
// 0x0090
struct FFortWindImpulseCylinderDelta
{
	struct FVector                                     DeltaCenter;                                              // 0x0000(0x000C) (Transient, IsPlainOldData)
	bool                                               bInitialized;                                             // 0x000C(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bRippleOutward;                                           // 0x000D(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x000E(0x0002) MISSED OFFSET
	float                                              SectionWidth;                                             // 0x0010(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              InnerSectionRadius;                                       // 0x0014(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              OuterSectionRadius;                                       // 0x0018(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              MaximumRadius;                                            // 0x001C(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              DesiredOverallBlendTime;                                  // 0x0020(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              SectionBlendTime;                                         // 0x0024(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              SectionCurrentBlendTime;                                  // 0x0028(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              PreviousMagnitude;                                        // 0x002C(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              SectionCurrentMagnitude;                                  // 0x0030(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float                                              DesiredMagnitude;                                         // 0x0034(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	struct FBox                                        OuterWorldBounds;                                         // 0x0038(0x001C) (Transient, IsPlainOldData)
	struct FBox                                        InnerWorldBounds;                                         // 0x0054(0x001C) (Transient, IsPlainOldData)
	struct FBox                                        WindImpulseBounds;                                        // 0x0070(0x001C) (Transient, IsPlainOldData)
	struct FFortWindImpulseHandle                      WindImpulseHandleToModify;                                // 0x008C(0x0004) (Transient)
};

// ScriptStruct FortniteGame.FortWindImpulseCylinderRadial
// 0x003C
struct FFortWindImpulseCylinderRadial
{
	struct FVector                                     Location;                                                 // 0x0000(0x000C) (Edit, IsPlainOldData)
	float                                              InnerRadius;                                              // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              OuterRadius;                                              // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              Magnitude;                                                // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FBox                                        WorldBounds;                                              // 0x0018(0x001C) (IsPlainOldData)
	bool                                               bIsChanging;                                              // 0x0034(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bIsChangePending;                                         // 0x0035(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0036(0x0002) MISSED OFFSET
	struct FFortWindImpulseHandle                      Handle;                                                   // 0x0038(0x0004) (Transient)
};

// ScriptStruct FortniteGame.FortWindImpulseCylinder
// 0x000C (0x0048 - 0x003C)
struct FFortWindImpulseCylinder : public FFortWindImpulseCylinderRadial
{
	struct FVector                                     WindDirection;                                            // 0x003C(0x000C) (Edit, IsPlainOldData)
};

// ScriptStruct FortniteGame.WindScalarMaterialInterpolationData
// 0x0018
struct FWindScalarMaterialInterpolationData
{
	struct FName                                       MaterialParameterName;                                    // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                MaterialParameterIndex;                                   // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              LerpFromValue;                                            // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              LerpToValue;                                              // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.WindVectorMaterialInterpolationData
// 0x0030
struct FWindVectorMaterialInterpolationData
{
	struct FName                                       MaterialParameterName;                                    // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                MaterialParameterIndex;                                   // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FLinearColor                                LerpFromValue;                                            // 0x000C(0x0010) (IsPlainOldData)
	struct FLinearColor                                LerpToValue;                                              // 0x001C(0x0010) (IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortMaterialParameterID
// 0x0010
struct FFortMaterialParameterID
{
	int                                                VariableIndex;                                            // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FName                                       VariableName;                                             // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortWindMaterialParameterPairID
// 0x0028
struct FFortWindMaterialParameterPairID
{
	int                                                PairIndex;                                                // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FFortMaterialParameterID                    SpeedParameter;                                           // 0x0008(0x0010)
	struct FFortMaterialParameterID                    OffsetParameter;                                          // 0x0018(0x0010)
};

// ScriptStruct FortniteGame.FortWindMaterialData
// 0x0048
struct FFortWindMaterialData
{
	class UMaterialInstanceDynamic*                    Mid;                                                      // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	class UMaterialInstanceDynamic*                    IntenseStateMID;                                          // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                MaterialParameterPairIndices;                             // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                WindVectorParameterIndex;                                 // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	TArray<struct FWindScalarMaterialInterpolationData> ScalarInterpolationData;                                  // 0x0018(0x0010) (ZeroConstructor)
	TArray<struct FWindVectorMaterialInterpolationData> VectorInterpolationData;                                  // 0x0028(0x0010) (ZeroConstructor)
	TArray<struct FFortWindMaterialParameterPairID>    ParametersToSet;                                          // 0x0038(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortWindResponderMaterialVariablePairData
// 0x0028
struct FFortWindResponderMaterialVariablePairData
{
	float                                              PreviousSpeed;                                            // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              PreviousOffset;                                           // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              MaterialsPreviousTime;                                    // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              DeltaTimeModifiedByMaterialSpeed;                         // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MaterialVariableIndex;                                    // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FName                                       SpeedVariableName;                                        // 0x0018(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FName                                       TimeOffsetVariableName;                                   // 0x0020(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortWindResponder
// 0x0098
struct FFortWindResponder
{
	class ABuildingSMActor*                            WindUpdatingBuildingSMActor;                              // 0x0000(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	class UCurveLinearColor*                           WindSpeedCurve;                                           // 0x0008(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	class UCurveLinearColor*                           WindPannerSpeedCurve;                                     // 0x0010(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	class USoundBase*                                  WindAudio;                                                // 0x0018(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TArray<class UMaterialInterface*>                  MildWindMaterialInstances;                                // 0x0020(0x0010) (ZeroConstructor, Transient)
	TArray<class UMaterialInterface*>                  IntenseWindMaterialInstances;                             // 0x0030(0x0010) (ZeroConstructor, Transient)
	TArray<struct FFortWindMaterialData>               MaterialsData;                                            // 0x0040(0x0010) (ZeroConstructor, Transient)
	int                                                MaterialParameterPairIndices;                             // 0x0050(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0054(0x0004) MISSED OFFSET
	TArray<struct FFortWindResponderMaterialVariablePairData> PairedVariablesData;                                      // 0x0058(0x0010) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x1C];                                      // 0x0068(0x001C) MISSED OFFSET
	float                                              WindSpeed;                                                // 0x0084(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData02[0xC];                                       // 0x0088(0x000C) MISSED OFFSET
	bool                                               bHasSetupAnimatingMaterials;                              // 0x0094(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x0095(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.PlayerStatsRecord
// 0x0088
struct FPlayerStatsRecord
{
	int                                                Stats[0x22];                                              // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.StatRecord
// 0x0010
struct FStatRecord
{
	struct FName                                       StatName;                                                 // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                StatValue;                                                // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.StatManagerPeriodRecord
// 0x0010
struct FStatManagerPeriodRecord
{
	TArray<struct FStatRecord>                         StatRecords;                                              // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.PinnedSchematicsRecord
// 0x0010
struct FPinnedSchematicsRecord
{
	TArray<struct FString>                             PinnedSchematicInstances;                                 // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortPlayerRecord
// 0x0200
struct FFortPlayerRecord
{
	struct FString                                     DisplayName;                                              // 0x0000(0x0010) (ZeroConstructor)
	struct FString                                     UniqueId;                                                 // 0x0010(0x0010) (ZeroConstructor)
	TArray<unsigned char>                              BackpackData;                                             // 0x0020(0x0010) (ZeroConstructor)
	bool                                               bPlayerIsNew;                                             // 0x0030(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0031(0x0003) MISSED OFFSET
	struct FPlayerStatsRecord                          PlayerStatsData;                                          // 0x0034(0x0088)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00BC(0x0004) MISSED OFFSET
	struct FStatManagerPeriodRecord                    CampaignPeriodRecord;                                     // 0x00C0(0x0010)
	struct FPinnedSchematicsRecord                     PinnedSchematicsRecord;                                   // 0x00D0(0x0010)
	struct FQuickBar                                   PrimaryQuickBarRecord;                                    // 0x00E0(0x0090)
	struct FQuickBar                                   SecondaryQuickBarRecord;                                  // 0x0170(0x0090)
};

// ScriptStruct FortniteGame.FortZoneInstanceInfo
// 0x0068
struct FFortZoneInstanceInfo
{
	struct FString                                     WorldId;                                                  // 0x0000(0x0010) (ZeroConstructor)
	struct FString                                     TheaterId;                                                // 0x0010(0x0010) (ZeroConstructor)
	struct FString                                     TheaterMissionId;                                         // 0x0020(0x0010) (ZeroConstructor)
	struct FString                                     TheaterMissionAlertId;                                    // 0x0030(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0040(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.FortZoneInstanceInfo.ZoneThemeClass
};

// ScriptStruct FortniteGame.FortZoneInstanceDetails
// 0x00B0 (0x0118 - 0x0068)
struct FFortZoneInstanceDetails : public FFortZoneInstanceInfo
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0068(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.FortZoneInstanceDetails.MissionGenerator
	struct FDataTableRowHandle                         ZoneDifficultyInfo;                                       // 0x0090(0x0010)
	struct FMcpLootResult                              MissionRewards;                                           // 0x00A0(0x0020)
	struct FMcpLootResult                              MissionAlertRewards;                                      // 0x00C0(0x0020)
	struct FMcpLootResult                              ZoneModifiers;                                            // 0x00E0(0x0020)
	struct FString                                     MissionAlertCategoryName;                                 // 0x0100(0x0010) (ZeroConstructor)
	int                                                TileIndex;                                                // 0x0110(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0114(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortLevelRecord
// 0x0040
struct FFortLevelRecord
{
	int                                                ParentLevelIndex;                                         // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FGuid                                       BoundActorGuid;                                           // 0x0004(0x0010) (IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FName                                       PackageName;                                              // 0x0018(0x0008) (ZeroConstructor, IsPlainOldData)
	TArray<struct FFortActorRecord>                    SavedActors;                                              // 0x0020(0x0010) (ZeroConstructor)
	int                                                X_Loc;                                                    // 0x0030(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                Y_Loc;                                                    // 0x0034(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      Rotation;                                                 // 0x0038(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.DeployableBaseSupportSettings
// 0x0098
struct FDeployableBaseSupportSettings
{
	bool                                               bUseDeployableBases;                                      // 0x0000(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	unsigned char                                      UnknownData01[0x28];                                      // 0x0001(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.DeployableBaseSupportSettings.DeployableBaseCloudSaveItemDef
	unsigned char                                      UnknownData02[0x28];                                      // 0x0030(0x0028) UNKNOWN PROPERTY: SoftClassProperty FortniteGame.DeployableBaseSupportSettings.DeployableBasePlot
	unsigned char                                      UnknownData03[0x28];                                      // 0x0058(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.DeployableBaseSupportSettings.SupportedUnlocks
	bool                                               bDeployableBasesReadOnly;                                 // 0x0080(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	EDeployableBaseUseType                             SupportedUseType;                                         // 0x0081(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData04[0x6];                                       // 0x0082(0x0006) MISSED OFFSET
	TArray<class UFortTieredCollectionLayout*>         TieredCollectionLayouts;                                  // 0x0088(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.ZoneThemeDifficultyProperties
// 0x0068
struct FZoneThemeDifficultyProperties
{
	TArray<struct FDataTableRowHandle>                 ValidDifficulties;                                        // 0x0000(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FFortTimeOfDayTheme                         TimeOfDayTheme;                                           // 0x0010(0x0040) (Edit, DisableEditOnInstance)
	struct FFortGlobalWindInfo                         GlobalWindInfo;                                           // 0x0050(0x0018) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.CameraPair
// 0x0010
struct FCameraPair
{
	EFrontEndCamera                                    Type;                                                     // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	class AFortCameraBase*                             Camera;                                                   // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.MyTownWorkerPortraitData
// 0x0030
struct FMyTownWorkerPortraitData
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.MyTownWorkerPortraitData.Portrait
	int                                                SelectionWeight;                                          // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.MyTownWorkerGenderData
// 0x0018
struct FMyTownWorkerGenderData
{
	TEnumAsByte<EFortCustomGender>                     Gender;                                                   // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                SelectionWeight;                                          // 0x0004(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TArray<struct FMyTownWorkerPortraitData>           PotraitData;                                              // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.MyTownWorkerPersonalityData
// 0x0050
struct FMyTownWorkerPersonalityData
{
	struct FGameplayTagContainer                       PersonalityTypeTag;                                       // 0x0000(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FText                                       PersonalityName;                                          // 0x0020(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	int                                                SelectionWeight;                                          // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	TArray<struct FMyTownWorkerGenderData>             GenderData;                                               // 0x0040(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.MyTownWorkerSetBonusData
// 0x0050
struct FMyTownWorkerSetBonusData
{
	struct FGameplayTagContainer                       SetBonusTypeTag;                                          // 0x0000(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FText                                       DisplayName;                                              // 0x0020(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	int                                                RequiredWorkersCount;                                     // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
	class UClass*                                      SetBonusEffect;                                           // 0x0040(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                SelectionWeight;                                          // 0x0048(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.TileGroupInfo
// 0x0018
struct FTileGroupInfo
{
	class UWorldTileGroup*                             TileGroup;                                                // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                Weight;                                                   // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                MinTiles;                                                 // 0x000C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int                                                MaxTiles;                                                 // 0x0010(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bPlaceAdjacent : 1;                                       // 0x0014(0x0001) (Edit)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.TileGroupSelection
// 0x0010
struct FTileGroupSelection
{
	TArray<struct FTileGroupInfo>                      TileGroupOptions;                                         // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct FortniteGame.TileGroupMapInfo
// 0x0038
struct FTileGroupMapInfo
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.TileGroupMapInfo.GroupWorld
	float                                              Weight;                                                   // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	struct FName                                       QuotaCategory;                                            // 0x0030(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.ProjectileEventData
// 0x0028
struct FProjectileEventData
{
	class AFortProjectileBase*                         SpawnedProjectile;                                        // 0x0000(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TArray<struct FHitResult>                          Hits;                                                     // 0x0008(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<class AActor*>                              ExplodedActors;                                           // 0x0018(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.MtxPackage
// 0x00A0
struct FMtxPackage
{
	struct FString                                     StorefrontName;                                           // 0x0000(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FString                                     OfferId;                                                  // 0x0010(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FText                                       Title;                                                    // 0x0020(0x0018) (BlueprintVisible, BlueprintReadOnly)
	struct FText                                       Description;                                              // 0x0038(0x0018) (BlueprintVisible, BlueprintReadOnly)
	int                                                TotalAmount;                                              // 0x0050(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                BonusAmount;                                              // 0x0054(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FText                                       Price;                                                    // 0x0058(0x0018) (BlueprintVisible, BlueprintReadOnly)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0070(0x0008) MISSED OFFSET
	struct FText                                       SaleBasePrice;                                            // 0x0078(0x0018) (BlueprintVisible, BlueprintReadOnly)
	struct FString                                     DisplayAssetPath;                                         // 0x0090(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortInputActionDetails
// 0x0020
struct FFortInputActionDetails
{
	EFortInputActionType                               InputActionType;                                          // 0x0000(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FKey                                        ActionKey;                                                // 0x0008(0x0018) (BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.GameSummaryInfo
// 0x0018
struct FGameSummaryInfo
{
	struct FString                                     GameSessionID;                                            // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	bool                                               Completed;                                                // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.ConfirmationDialogAction
// 0x00B8
struct FConfirmationDialogAction
{
	struct FText                                       DisplayName;                                              // 0x0000(0x0018) (BlueprintVisible)
	struct FText                                       HoverText;                                                // 0x0018(0x0018) (BlueprintVisible)
	struct FName                                       ResultName;                                               // 0x0030(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FSlateBrush                                 Icon;                                                     // 0x0038(0x0078) (BlueprintVisible)
	struct FName                                       ActionName;                                               // 0x00B0(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortDialogDescription_NUI
// 0x0170
struct FFortDialogDescription_NUI
{
	struct FSlateBrush                                 Icon;                                                     // 0x0000(0x0078) (BlueprintVisible)
	struct FText                                       MessageHeader;                                            // 0x0078(0x0018) (BlueprintVisible)
	struct FText                                       MessageBody;                                              // 0x0090(0x0018) (BlueprintVisible)
	TArray<struct FConfirmationDialogAction>           ConfirmButtonInputActions;                                // 0x00A8(0x0010) (BlueprintVisible, ZeroConstructor)
	struct FName                                       DeclineButtonInputAction;                                 // 0x00B8(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bMultipleConfirmButtons;                                  // 0x00C0(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x00C1(0x0007) MISSED OFFSET
	class UWidget*                                     AdditionalContent;                                        // 0x00C8(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	class UWidget*                                     LeftAdditionalContent;                                    // 0x00D0(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	float                                              DisplayTime;                                              // 0x00D8(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               Dismissable;                                              // 0x00DC(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bShouldWaitForLatentActionOnConfirmAction;                // 0x00DD(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x00DE(0x0002) MISSED OFFSET
	class UFortNotificationHandler*                    NotificationHandler;                                      // 0x00E0(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x88];                                      // 0x00E8(0x0088) MISSED OFFSET
};

// ScriptStruct FortniteGame.AthenaLevelUpData
// 0x0020 (0x0028 - 0x0008)
struct FAthenaLevelUpData : public FTableRowBase
{
	int                                                Level;                                                    // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                XpToNextLevel;                                            // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                XpTotal;                                                  // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                CurrencyReward;                                           // 0x0014(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FString                                     ChaseRewardTemplateId;                                    // 0x0018(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.AthenaSeasonalXPCurveEntry
// 0x0010 (0x0018 - 0x0008)
struct FAthenaSeasonalXPCurveEntry : public FTableRowBase
{
	int                                                Level;                                                    // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                XpToNextLevel;                                            // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                XpTotal;                                                  // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortWeakSpotPosition
// 0x001C
struct FFortWeakSpotPosition
{
	struct FVector                                     Position;                                                 // 0x0000(0x000C) (IsPlainOldData)
	struct FVector                                     Normal;                                                   // 0x000C(0x000C) (IsPlainOldData)
	bool                                               bValidSpot;                                               // 0x0018(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0019(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.BuildingValueRules
// 0x001C
struct FBuildingValueRules
{
	int                                                CellsAbove;                                               // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                CellsBelow;                                               // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                CellHorizontalRadius;                                     // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              DistanceFromObjectiveWeight;                              // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              AttackWeight;                                             // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              StructuralWeight;                                         // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              TrapWeight;                                               // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.VisibilityTestPoint
// 0x0018
struct FVisibilityTestPoint
{
	struct FVector                                     Location;                                                 // 0x0000(0x000C) (IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	class UPrimitiveComponent*                         Component;                                                // 0x0010(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortAbilityCanHitParameters
// 0x0018
struct FFortAbilityCanHitParameters
{
	unsigned char                                      UnknownData00[0x18];                                      // 0x0000(0x0018) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortGameplayAbilityTargetData_SingleTargetHit
// 0x0008 (0x0090 - 0x0088)
struct FFortGameplayAbilityTargetData_SingleTargetHit : public FGameplayAbilityTargetData_SingleTargetHit
{
	int                                                CartridgeID;                                              // 0x0088(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x008C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortGameplayEffectContext
// 0x0058 (0x00C8 - 0x0070)
struct FFortGameplayEffectContext : public FGameplayEffectContext
{
	bool                                               bIsFatalHit;                                              // 0x0070(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bIsCriticalHit;                                           // 0x0071(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bIsDiceCritical;                                          // 0x0072(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bIsFullBodyHit;                                           // 0x0073(0x0001) (ZeroConstructor, IsPlainOldData)
	float                                              KnockbackMagnitude;                                       // 0x0074(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              KnockbackZAngle;                                          // 0x0078(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              StunTime;                                                 // 0x007C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              ChargeMagnitude;                                          // 0x0080(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0084(0x0004) MISSED OFFSET
	struct FGameplayTagContainer                       TooltipTags;                                              // 0x0088(0x0020)
	int                                                CartridgeID;                                              // 0x00A8(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FGuid                                       ItemGuid;                                                 // 0x00AC(0x0010) (IsPlainOldData)
	TWeakObjectPtr<class UObject>                      DamageSourceObject;                                       // 0x00BC(0x0008) (ZeroConstructor, IsPlainOldData)
	float                                              SourceLevel;                                              // 0x00C4(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortEncounterAIDirectorFactor
// 0x000C
struct FFortEncounterAIDirectorFactor
{
	float                                              CurrentValue;                                             // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              AccumulatedPeriodValue;                                   // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              TotalPeriodTime;                                          // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.CurrentIntensityAnalyticsBucket
// 0x0038
struct FCurrentIntensityAnalyticsBucket
{
	unsigned char                                      UnknownData00[0x38];                                      // 0x0000(0x0038) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortIntensityCurve
// 0x0038 (0x0040 - 0x0008)
struct FFortIntensityCurve : public FTableRowBase
{
	class UCurveTable*                                 IntensityCurveTable;                                      // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       IntensityCurveTableRow;                                   // 0x0010(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              LowPlayerPerformancePeakIntensityThreshold;               // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              NormalPlayerPerformancePeakIntensityThreshold;            // 0x001C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              HighPlayerPerformancePeakIntensityThreshold;              // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaxRampTime;                                              // 0x0024(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              FadeEndIntensityThreshold;                                // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              StartIntensityOffsetFloor;                                // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              EndIntensityOffsetFloor;                                  // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              StartIntensityOffsetCeiling;                              // 0x0034(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              EndIntensityOffsetCeiling;                                // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortSpawnPointsPercentageCurve
// 0x0018 (0x0020 - 0x0008)
struct FFortSpawnPointsPercentageCurve : public FTableRowBase
{
	class UCurveTable*                                 SpawnPointsPercentageCurveTable;                          // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       SpawnPointsPercentageCurveTableRow;                       // 0x0010(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaxRampTime;                                              // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAIEncounterRiftManagerInitializationData
// 0x00C0
struct FFortAIEncounterRiftManagerInitializationData
{
	class UFortAIEncounterInfo*                        EncounterInfo;                                            // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FFortEncounterSettings                      EncounterSettings;                                        // 0x0008(0x0058)
	struct FEncounterEnvironmentQueryInfo              CurrentEnvironmentQueryInfo;                              // 0x0060(0x0028)
	struct FEncounterEnvironmentQueryInfo              FallbackEnvironmentQueryInfo;                             // 0x0088(0x0028)
	class UClass*                                      RiftClassTemplate;                                        // 0x00B0(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                NumRiftsToUse;                                            // 0x00B8(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MinRiftsToUse;                                            // 0x00BC(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.AIAssignmentInfo
// 0x0080
struct FAIAssignmentInfo
{
	TWeakObjectPtr<class UFortAIAssignment>            CurrentAssignment;                                        // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FFortAIGoalInfo                             CurrentGoal;                                              // 0x0008(0x0018)
	float                                              TimeCurrentGoalWasChosen;                                 // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              TimeExitedLastAssignmentOfType[0x4];                      // 0x0024(0x0004) (ZeroConstructor, IsPlainOldData)
	TWeakObjectPtr<class UFortAIAssignment>            PreviousAssignment;                                       // 0x0034(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FFortAIGoalInfo                             PreviousGoal;                                             // 0x003C(0x0018)
	bool                                               bWaitingForQueryResponse;                                 // 0x0054(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bSuppressGoalUpdates;                                     // 0x0055(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bReportEnemyGoalSelection;                                // 0x0056(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x29];                                      // 0x0057(0x0029) MISSED OFFSET
};

// ScriptStruct FortniteGame.AIDiscouragedGoalTimer
// 0x0028
struct FAIDiscouragedGoalTimer
{
	struct FFortAIGoalInfo                             DiscouragedGoalInfo;                                      // 0x0000(0x0018)
	double                                             ExpirationTime;                                           // 0x0018(0x0008) (ZeroConstructor, IsPlainOldData)
	uint32_t                                           NumberOfTimesMarkedForDiscouragement;                     // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.DamagerInfoAnalytics
// 0x0018
struct FDamagerInfoAnalytics
{
	struct FString                                     DamageCauser;                                             // 0x0000(0x0010) (ZeroConstructor)
	int                                                DamageAmount;                                             // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAIPawnStats
// 0x0058 (0x00E8 - 0x0090)
struct FFortAIPawnStats : public FFortPawnStats
{
	int                                                ScoreValue;                                               // 0x0090(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              DormantSightRadius;                                       // 0x0094(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              DormantHearingThreshold;                                  // 0x0098(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              DormantLOSHearingThreshold;                               // 0x009C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              DormantPeripheralVisionAngle;                             // 0x00A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AlertSightRadius;                                         // 0x00A4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AlertHearingThreshold;                                    // 0x00A8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AlertLOSHearingThreshold;                                 // 0x00AC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AlertPeripheralVisionAngle;                               // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AutoSuccessRangeFromLastSeenLocation;                     // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCurveTable*                                 HealthScalingTable;                                       // 0x00B8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       HealthScalingTableRow;                                    // 0x00C0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCurveTable*                                 ControlResistanceScalingTable;                            // 0x00C8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       ControlResistanceScalingTableRow;                         // 0x00D0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCurveTable*                                 DifficultyRatingTable;                                    // 0x00D8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName                                       DifficultyRatingTableRow;                                 // 0x00E0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.RunVariationData
// 0x000C
struct FRunVariationData
{
	TWeakObjectPtr<class AFortAIPawn>                  FortAIPawn;                                               // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	float                                              Distance;                                                 // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortVariantSpawnPoints
// 0x0008 (0x0010 - 0x0008)
struct FFortVariantSpawnPoints : public FTableRowBase
{
	int                                                BudgetPoints;                                             // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAnimNode_ScaleHuskBones
// 0x01B0 (0x01E0 - 0x0030)
struct FFortAnimNode_ScaleHuskBones : public FAnimNode_Base
{
	struct FPoseLink                                   PreScalePose;                                             // 0x0030(0x0018) (Edit)
	unsigned char                                      UnknownData00[0x198];                                     // 0x0048(0x0198) MISSED OFFSET
};

// ScriptStruct FortniteGame.SlopeWarpingFootDefinition
// 0x0050
struct FSlopeWarpingFootDefinition
{
	struct FBoneReference                              IKFootBone;                                               // 0x0000(0x0018) (Edit)
	struct FBoneReference                              FKFootBone;                                               // 0x0018(0x0018) (Edit)
	int                                                NumBonesInLimb;                                           // 0x0030(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
	struct FName                                       ToeSocketName;                                            // 0x0038(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FName                                       HeelSocketName;                                           // 0x0040(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              FootSize;                                                 // 0x0048(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.SlopeWarpingFootData
// 0x00E0
struct FSlopeWarpingFootData
{
	unsigned char                                      UnknownData00[0xE0];                                      // 0x0000(0x00E0) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAnimNode_SlopeWarping
// 0x0168 (0x01D8 - 0x0070)
struct FFortAnimNode_SlopeWarping : public FAnimNode_SkeletalControlBase
{
	unsigned char                                      UnknownData00[0x18];                                      // 0x0070(0x0018) MISSED OFFSET
	struct FBoneReference                              IKFootRootBone;                                           // 0x0088(0x0018) (Edit)
	struct FBoneReference                              PelvisBone;                                               // 0x00A0(0x0018) (Edit)
	TArray<struct FSlopeWarpingFootDefinition>         FeetDefinitions;                                          // 0x00B8(0x0010) (Edit, ZeroConstructor)
	TArray<struct FSlopeWarpingFootData>               FeetData;                                                 // 0x00C8(0x0010) (ZeroConstructor, Transient)
	struct FVectorRK4SpringInterpolator                PelvisOffsetInterpolator;                                 // 0x00D8(0x0008) (Edit)
	unsigned char                                      UnknownData01[0x34];                                      // 0x00E0(0x0034) MISSED OFFSET
	struct FVector                                     GravityDir;                                               // 0x0114(0x000C) (Edit, IsPlainOldData)
	float                                              CachedDeltaTime;                                          // 0x0120(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	struct FVector                                     TargetFloorNormalWorldSpace;                              // 0x0124(0x000C) (Transient, IsPlainOldData)
	struct FVectorRK4SpringInterpolator                FloorNormalInterpolator;                                  // 0x0130(0x0008) (Edit)
	unsigned char                                      UnknownData02[0x34];                                      // 0x0138(0x0034) MISSED OFFSET
	struct FVector                                     TargetFloorOffsetLocalSpace;                              // 0x016C(0x000C) (Transient, IsPlainOldData)
	struct FVectorRK4SpringInterpolator                FloorOffsetInterpolator;                                  // 0x0178(0x0008) (Edit)
	unsigned char                                      UnknownData03[0x34];                                      // 0x0180(0x0034) MISSED OFFSET
	float                                              MaxStepHeight;                                            // 0x01B4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      bUseCapsuleInfoInsteadOfFootTraces : 1;                   // 0x01B8(0x0001) (Edit)
	unsigned char                                      bWasOnGround : 1;                                         // 0x01B8(0x0001) (Transient)
	unsigned char                                      bShowDebug : 1;                                           // 0x01B8(0x0001) (Transient)
	unsigned char                                      bFloorSmoothingInitialized : 1;                           // 0x01B8(0x0001) (Transient)
	unsigned char                                      UnknownData04[0x3];                                       // 0x01B9(0x0003) MISSED OFFSET
	struct FVector                                     ActorLocation;                                            // 0x01BC(0x000C) (Transient, IsPlainOldData)
	struct FVector                                     GravityDirCompSpace;                                      // 0x01C8(0x000C) (Transient, IsPlainOldData)
	unsigned char                                      UnknownData05[0x4];                                       // 0x01D4(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.SpeedWarpingFootDefinition
// 0x0038
struct FSpeedWarpingFootDefinition
{
	struct FBoneReference                              IKFootBone;                                               // 0x0000(0x0018) (Edit)
	struct FBoneReference                              FKFootBone;                                               // 0x0018(0x0018) (Edit)
	int                                                NumBonesInLimb;                                           // 0x0030(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.SpeedWarpingFootData
// 0x0040
struct FSpeedWarpingFootData
{
	unsigned char                                      UnknownData00[0x40];                                      // 0x0000(0x0040) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAnimNode_SpeedWarping
// 0x00D0 (0x0140 - 0x0070)
struct FFortAnimNode_SpeedWarping : public FAnimNode_SkeletalControlBase
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0070(0x0008) MISSED OFFSET
	struct FBoneReference                              IKFootRootBone;                                           // 0x0078(0x0018) (Edit)
	TArray<struct FSpeedWarpingFootDefinition>         FeetDefinitions;                                          // 0x0090(0x0010) (Edit, ZeroConstructor)
	TArray<struct FSpeedWarpingFootData>               FeetData;                                                 // 0x00A0(0x0010) (ZeroConstructor, Transient)
	struct FBoneReference                              PelvisBone;                                               // 0x00B0(0x0018) (Edit)
	ESpeedWarpingAxisMode                              SpeedWarpingAxisMode;                                     // 0x00C8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ESpeedWarpingAxisMode                              FloorNormalAxisMode;                                      // 0x00C9(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ESpeedWarpingAxisMode                              GravityDirAxisMode;                                       // 0x00CA(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x1];                                       // 0x00CB(0x0001) MISSED OFFSET
	float                                              SpeedScaling;                                             // 0x00CC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     ManualSpeedWarpingDir;                                    // 0x00D0(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     ManualFloorNormalInput;                                   // 0x00DC(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     ManualGravityDirInput;                                    // 0x00E8(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              PelvisPostAdjustmentAlpha;                                // 0x00F4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                PelvisAdjustmentMaxIter;                                  // 0x00F8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVectorRK4SpringInterpolator                PelvisAdjustmentInterp;                                   // 0x00FC(0x0008) (Edit)
	unsigned char                                      UnknownData02[0x34];                                      // 0x0104(0x0034) MISSED OFFSET
	unsigned char                                      bAdjustThighBonesRotation : 1;                            // 0x0138(0x0001) (Edit)
	unsigned char                                      bClampIKUsingFKLeg : 1;                                   // 0x0138(0x0001) (Edit)
	unsigned char                                      bOrientSpeedWarpingAxisBasedOnFloorNormal : 1;            // 0x0138(0x0001) (Edit)
	unsigned char                                      UnknownData03[0x3];                                       // 0x0139(0x0003) MISSED OFFSET
	float                                              CachedDeltaTime;                                          // 0x013C(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortAthenaAimAssist
// 0x00E0
struct FFortAthenaAimAssist
{
	unsigned char                                      UnknownData00[0xE0];                                      // 0x0000(0x00E0) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAthenaAimAssistTarget
// 0x0048
struct FFortAthenaAimAssistTarget
{
	class AActor*                                      Actor;                                                    // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	class UCapsuleComponent*                           Capsule;                                                  // 0x0008(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	unsigned char                                      UnknownData00[0x38];                                      // 0x0010(0x0038) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAthenaAimAssistTargetAggregator
// 0x0028
struct FFortAthenaAimAssistTargetAggregator
{
	TArray<struct FFortAthenaAimAssistTarget>          TargetCache0;                                             // 0x0000(0x0010) (ZeroConstructor)
	TArray<struct FFortAthenaAimAssistTarget>          TargetCache1;                                             // 0x0010(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0020(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAthenaAimAssistOwnerInfo
// 0x00A0
struct FFortAthenaAimAssistOwnerInfo
{
	unsigned char                                      UnknownData00[0xA0];                                      // 0x0000(0x00A0) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAthenaAimAssistResults
// 0x0018
struct FFortAthenaAimAssistResults
{
	unsigned char                                      UnknownData00[0x18];                                      // 0x0000(0x0018) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAthenaAimAssistParams
// 0x0028
struct FFortAthenaAimAssistParams
{
	class AFortPawn*                                   OwningPawn;                                               // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x20];                                      // 0x0008(0x0020) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortBadgeScoringData
// 0x0010 (0x0018 - 0x0008)
struct FFortBadgeScoringData : public FTableRowBase
{
	int                                                ScoreAwarded;                                             // 0x0008(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                MissionPoints;                                            // 0x000C(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	EStatCategory                                      ScoreCategory;                                            // 0x0010(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0011(0x0003) MISSED OFFSET
	int                                                ScoreThreshold;                                           // 0x0014(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.DataTableRowHandleQuantityPair
// 0x0018
struct FDataTableRowHandleQuantityPair
{
	struct FDataTableRowHandle                         DataTableRowHandle;                                       // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	int                                                Quantity;                                                 // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortCalendarEventInventoryTransformData
// 0x0108 (0x0110 - 0x0008)
struct FFortCalendarEventInventoryTransformData : public FTableRowBase
{
	struct FName                                       CalendarChannelName;                                      // 0x0008(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FName                                       CalendarEventName;                                        // 0x0010(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	TArray<struct FName>                               AllowedProfileTypes;                                      // 0x0018(0x0010) (Edit, ZeroConstructor)
	struct FGameplayTagContainer                       PrerequisiteHomebaseProperties;                           // 0x0028(0x0020) (Edit)
	unsigned char                                      UnknownData00[0x28];                                      // 0x0048(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortCalendarEventInventoryTransformData.PrerequisiteQuest
	struct FDataTableRowHandle                         PrerequisiteObjective;                                    // 0x0070(0x0010) (Edit)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0080(0x0010) UNKNOWN PROPERTY: ArrayProperty FortniteGame.FortCalendarEventInventoryTransformData.PrerequisiteIncompleteOrUngrantedQuests
	unsigned char                                      UnknownData02[0x10];                                      // 0x0090(0x0010) UNKNOWN PROPERTY: ArrayProperty FortniteGame.FortCalendarEventInventoryTransformData.PrerequisiteUnownedItems
	unsigned char                                      UnknownData03[0x10];                                      // 0x00A0(0x0010) UNKNOWN PROPERTY: ArrayProperty FortniteGame.FortCalendarEventInventoryTransformData.QuestsOnlyActiveDuringEvent
	TArray<struct FFortItemQuantityPair>               ItemsToGrant;                                             // 0x00B0(0x0010) (Edit, ZeroConstructor, EditConst)
	TArray<struct FFortHiddenRewardQuantityPair>       ItemsToGrantByTemplate;                                   // 0x00C0(0x0010) (Edit, ZeroConstructor)
	TArray<struct FDataTableRowHandleQuantityPair>     ConversionRecipesToRunOnEventStart;                       // 0x00D0(0x0010) (Edit, ZeroConstructor)
	TArray<struct FDataTableRowHandleQuantityPair>     ConversionRecipesToRunAfterEvent;                         // 0x00E0(0x0010) (Edit, ZeroConstructor)
	TArray<struct FFortItemQuantityPair>               ItemsToRemoveAfterEvent;                                  // 0x00F0(0x0010) (Edit, ZeroConstructor, EditConst)
	TArray<struct FFortHiddenRewardQuantityPair>       ItemsToRemoveAfterEventByTemplate;                        // 0x0100(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct FortniteGame.RecipeQuantityPair
// 0x0010
struct FRecipeQuantityPair
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortProceduralCatalogCostPriceFactor
// 0x0008 (0x0010 - 0x0008)
struct FFortProceduralCatalogCostPriceFactor : public FTableRowBase
{
	float                                              PriceFactor;                                              // 0x0008(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortCollectionBookStat
// 0x0018
struct FFortCollectionBookStat
{
	TArray<struct FString>                             Pages;                                                    // 0x0000(0x0010) (ZeroConstructor)
	int                                                MaxBookXpLevelAchieved;                                   // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortCollectionBookPageCategoryTableRow
// 0x0020 (0x0028 - 0x0008)
struct FFortCollectionBookPageCategoryTableRow : public FTableRowBase
{
	struct FText                                       Name;                                                     // 0x0008(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	int                                                SortPriority;                                             // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortCollectionBookPageData
// 0x0070 (0x0078 - 0x0008)
struct FFortCollectionBookPageData : public FTableRowBase
{
	struct FText                                       Name;                                                     // 0x0008(0x0018) (Edit, EditConst)
	struct FName                                       CategoryId;                                               // 0x0020(0x0008) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                SortPriority;                                             // 0x0028(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	struct FName                                       ProfileId;                                                // 0x0030(0x0008) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	TArray<struct FName>                               SectionRowNames;                                          // 0x0038(0x0010) (Edit, ZeroConstructor, EditConst)
	struct FFortRewardInfo                             Rewards;                                                  // 0x0048(0x0030) (Edit, EditConst)
};

// ScriptStruct FortniteGame.FortCollectionBookSectionData
// 0x0058 (0x0060 - 0x0008)
struct FFortCollectionBookSectionData : public FTableRowBase
{
	struct FText                                       Name;                                                     // 0x0008(0x0018) (Edit, EditConst)
	TArray<struct FName>                               SlotRowNames;                                             // 0x0020(0x0010) (Edit, ZeroConstructor, EditConst)
	struct FFortRewardInfo                             Rewards;                                                  // 0x0030(0x0030) (Edit, EditConst)
};

// ScriptStruct FortniteGame.FortCollectionBookSlotData
// 0x0038 (0x0040 - 0x0008)
struct FFortCollectionBookSlotData : public FTableRowBase
{
	struct FName                                       SlotXpWeightName;                                         // 0x0008(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FName                                       SlotSourceId;                                             // 0x0010(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FName                                       SlotSourceId2;                                            // 0x0018(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x10];                                      // 0x0020(0x0010) UNKNOWN PROPERTY: ArrayProperty FortniteGame.FortCollectionBookSlotData.AllowedItems
	TArray<struct FGameplayTag>                        AllowedWorkerPersonalities;                               // 0x0030(0x0010) (Edit, ZeroConstructor, EditConst)
};

// ScriptStruct FortniteGame.FortCollectionBookSlotSourceData
// 0x0018 (0x0020 - 0x0008)
struct FFortCollectionBookSlotSourceData : public FTableRowBase
{
	struct FText                                       Description;                                              // 0x0008(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.FortCollectionBookSlotXPWeightData
// 0x0010 (0x0018 - 0x0008)
struct FFortCollectionBookSlotXPWeightData : public FTableRowBase
{
	float                                              ConstantWeight;                                           // 0x0008(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              RarityWeight;                                             // 0x000C(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              ItemLevelWeight;                                          // 0x0010(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              ItemRatingWeight;                                         // 0x0014(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortCollectionBookXPData
// 0x0040 (0x0048 - 0x0008)
struct FFortCollectionBookXPData : public FTableRowBase
{
	int                                                XpToNextLevel;                                            // 0x0008(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	int                                                TotalXpToGetToThisLevel;                                  // 0x000C(0x0004) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	struct FFortRewardInfo                             Rewards;                                                  // 0x0010(0x0030) (Edit, EditConst)
	bool                                               bIsMajorReward;                                           // 0x0040(0x0001) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	bool                                               bAutoOpenRewardCardPacks;                                 // 0x0041(0x0001) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0042(0x0006) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortSurfaceDamageRatioStats
// 0x0060 (0x0068 - 0x0008)
struct FFortSurfaceDamageRatioStats : public FTableRowBase
{
	struct FName                                       Default;                                                  // 0x0008(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       Wood;                                                     // 0x0010(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       Stone;                                                    // 0x0018(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       Metal;                                                    // 0x0020(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       HumanEntity;                                              // 0x0028(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       AIEntity;                                                 // 0x0030(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       Explosive;                                                // 0x0038(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       WeakSpot;                                                 // 0x0040(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       Objective;                                                // 0x0048(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       WeakSpot_Wood;                                            // 0x0050(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       WeakSpot_Stone;                                           // 0x0058(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       WeakSpot_Metal;                                           // 0x0060(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortSurfaceDamageRatioByAffiliationStats
// 0x0010 (0x0018 - 0x0008)
struct FFortSurfaceDamageRatioByAffiliationStats : public FTableRowBase
{
	float                                              Friendly;                                                 // 0x0008(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              Neutral;                                                  // 0x000C(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              Hostile;                                                  // 0x0010(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortConversionTierData
// 0x0008
struct FFortConversionTierData
{
	int                                                TierCost;                                                 // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                RequiredItemQuantity;                                     // 0x0004(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortConversionControlKeyCosts
// 0x0098 (0x00A0 - 0x0008)
struct FFortConversionControlKeyCosts : public FTableRowBase
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0008(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortConversionControlKeyCosts.RequiredItem
	struct FFortConversionTierData                     Handmade;                                                 // 0x0030(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FFortConversionTierData                     Ordinary;                                                 // 0x0038(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FFortConversionTierData                     Sturdy;                                                   // 0x0040(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FFortConversionTierData                     Quality;                                                  // 0x0048(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FFortConversionTierData                     Fine;                                                     // 0x0050(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FFortConversionTierData                     Elegant;                                                  // 0x0058(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FFortConversionTierData                     Masterwork;                                               // 0x0060(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FFortConversionTierData                     Epic;                                                     // 0x0068(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FFortConversionTierData                     Badass;                                                   // 0x0070(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FFortConversionTierData                     Legendary;                                                // 0x0078(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FGameplayTagContainer                       RequiredCatalysts;                                        // 0x0080(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.FortDailyLoginRewardStat_ScheduleClaimed
// 0x0008
struct FFortDailyLoginRewardStat_ScheduleClaimed
{
	int                                                RewardsClaimed;                                           // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               ClaimedToday;                                             // 0x0004(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0005(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortDailyLoginRewardStat
// 0x0060
struct FFortDailyLoginRewardStat
{
	int                                                NextDefaultReward;                                        // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                TotalDaysLoggedIn;                                        // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FDateTime                                   LastClaimDate;                                            // 0x0008(0x0008)
	TMap<struct FName, struct FFortDailyLoginRewardStat_ScheduleClaimed> AdditionalSchedules;                                      // 0x0010(0x0050) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortDailyRewardsNotification
// 0x0018
struct FFortDailyRewardsNotification
{
	int                                                DaysLoggedIn;                                             // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	TArray<struct FMcpLootEntry>                       Items;                                                    // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortMissionGenerationElementCostAndAvailabilityRow
// 0x0018 (0x0020 - 0x0008)
struct FFortMissionGenerationElementCostAndAvailabilityRow : public FTableRowBase
{
	class UCurveTable*                                 AvailabilityCurveTable;                                   // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       AvailabilityCurveTableRow;                                // 0x0010(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MinCost;                                                  // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaxCost;                                                  // 0x001C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortFeedbackEvent
// 0x0030
struct FFortFeedbackEvent
{
	class AFortPawn*                                   Instigator;                                               // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	class AFortPawn*                                   Recipient;                                                // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FFortFeedbackHandle                         Handle;                                                   // 0x0010(0x0018) (Edit)
	float                                              Delay;                                                    // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bOverriddenQueuing;                                       // 0x002C(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x002D(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.TieredWaveCollectionLootSetData
// 0x0020
struct FTieredWaveCollectionLootSetData
{
	TArray<struct FName>                               StartOfCollectionItemTierGroups;                          // 0x0000(0x0010) (Edit, ZeroConstructor, EditConst)
	TArray<struct FName>                               SuccessfulWaveItemTierGroups;                             // 0x0010(0x0010) (Edit, ZeroConstructor, EditConst)
};

// ScriptStruct FortniteGame.TieredWaveCollectionLootSet
// 0x0010 (0x0018 - 0x0008)
struct FTieredWaveCollectionLootSet : public FTableRowBase
{
	TArray<struct FTieredWaveCollectionLootSetData>    LootSetData;                                              // 0x0008(0x0010) (Edit, ZeroConstructor, EditConst)
};

// ScriptStruct FortniteGame.TieredModifierSet
// 0x0010 (0x0018 - 0x0008)
struct FTieredModifierSet : public FTableRowBase
{
	TArray<struct FTieredModifierSetData>              ModifierData;                                             // 0x0008(0x0010) (Edit, ZeroConstructor, EditConst)
};

// ScriptStruct FortniteGame.TieredWaveSet
// 0x0010 (0x0018 - 0x0008)
struct FTieredWaveSet : public FTableRowBase
{
	TArray<struct FTieredWaveSetData>                  WaveData;                                                 // 0x0008(0x0010) (Edit, ZeroConstructor, EditConst)
};

// ScriptStruct FortniteGame.TieredWaveSetCollection
// 0x0010 (0x0018 - 0x0008)
struct FTieredWaveSetCollection : public FTableRowBase
{
	TArray<struct FTieredWaveSetCollectionData>        CollectionData;                                           // 0x0008(0x0010) (Edit, ZeroConstructor, EditConst)
};

// ScriptStruct FortniteGame.ScoreMultiplierRow
// 0x0080 (0x0088 - 0x0008)
struct FScoreMultiplierRow : public FTableRowBase
{
	float                                              CombatMultiplier;                                         // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              BuildingMultiplier;                                       // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              UtilityMultiplier;                                        // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              BadgeMultiplier;                                          // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MonsterKills;                                             // 0x0018(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MonsterDamagePoints;                                      // 0x001C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                PlayerKills;                                              // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                WoodGathered;                                             // 0x0024(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                StoneGathered;                                            // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MetalGathered;                                            // 0x002C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                Deaths;                                                   // 0x0030(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BuildingsBuilt;                                           // 0x0034(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BuildingsBuilt_Wood;                                      // 0x0038(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BuildingsBuilt_Stone;                                     // 0x003C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BuildingsBuilt_Metal;                                     // 0x0040(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BuildingsUpgraded_Wood2;                                  // 0x0044(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BuildingsUpgraded_Wood3;                                  // 0x0048(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BuildingsUpgraded_Stone2;                                 // 0x004C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BuildingsUpgraded_Stone3;                                 // 0x0050(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BuildingsUpgraded_Metal2;                                 // 0x0054(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BuildingsUpgraded_Metal3;                                 // 0x0058(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BuildingsDestroyed;                                       // 0x005C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                Repair_Wood;                                              // 0x0060(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                Repair_Stone;                                             // 0x0064(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                Repair_Metal;                                             // 0x0068(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                FlagsCaptured;                                            // 0x006C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                FlagsReturned;                                            // 0x0070(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                ContainersLooted;                                         // 0x0074(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                CraftingPoints;                                           // 0x0078(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                TrapPlacementPoints;                                      // 0x007C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                TrapActivationPoints;                                     // 0x0080(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0084(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.WorldItemAndMinMaxCount
// 0x0028
struct FWorldItemAndMinMaxCount
{
	struct FCurveTableRowHandle                        MinCurveTable;                                            // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FCurveTableRowHandle                        MaxCurveTable;                                            // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	class UFortWorldItemDefinition*                    Item;                                                     // 0x0020(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortLevelUpData
// 0x0028 (0x0030 - 0x0008)
struct FFortLevelUpData : public FTableRowBase
{
	int                                                Xp;                                                       // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FString                                     ItemRewardsText;                                          // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	float                                              XPDisplayMultiplier;                                      // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                RestXPCap;                                                // 0x0024(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                RestXPRechargeRate;                                       // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                BoostXPPerConsumable;                                     // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.AttributeClamp
// 0x0028
struct FAttributeClamp
{
	struct FGameplayAttribute                          Attribute;                                                // 0x0000(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly)
	EClampType                                         ClampType;                                                // 0x0020(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0021(0x0003) MISSED OFFSET
	float                                              ClampValue;                                               // 0x0024(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.PlayerClampInfo
// 0x0010 (0x0018 - 0x0008)
struct FPlayerClampInfo : public FTableRowBase
{
	TArray<struct FAttributeClamp>                     AttributeClamps;                                          // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.BCActionInfo
// 0x0008
struct FBCActionInfo
{
	int                                                Type;                                                     // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                Action;                                                   // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortBanHammerStrike
// 0x0060
struct FFortBanHammerStrike
{
	struct FUniqueNetIdRepl                            AccountId;                                                // 0x0000(0x0028)
	struct FString                                     Reason;                                                   // 0x0028(0x0010) (ZeroConstructor)
	EFortBanHammerNotificationAction                   Action;                                                   // 0x0038(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	struct FString                                     Source;                                                   // 0x0040(0x0010) (ZeroConstructor)
	struct FString                                     Offense;                                                  // 0x0050(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.PlayerBuildableClassFilter
// 0x0010
struct FPlayerBuildableClassFilter
{
	TEnumAsByte<EFortResourceType>                     ResourceType;                                             // 0x0000(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	TEnumAsByte<EFortBuildingType>                     BuildingType;                                             // 0x0001(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0002(0x0002) MISSED OFFSET
	int                                                Level;                                                    // 0x0004(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	class UBuildingEditModeMetadata*                   EditModeMetadata;                                         // 0x0008(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortHealthBarComponentData
// 0x0018
struct FFortHealthBarComponentData
{
	struct FText                                       DisplayText;                                              // 0x0000(0x0018)
};

// ScriptStruct FortniteGame.FortZoneEvent
// 0x0020
struct FFortZoneEvent
{
	struct FName                                       EventType;                                                // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UObject*                                     EventFocus;                                               // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UDataAsset*                                  EventContent;                                             // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class AActor*                                      EventInstigator;                                          // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.HomebaseNodeState
// 0x0008
struct FHomebaseNodeState
{
	bool                                               bIsOwned;                                                 // 0x0000(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bArePrereqsMet;                                           // 0x0001(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bArePrereqQuestsCompleted;                                // 0x0002(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bAreCostsPayable;                                         // 0x0003(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              PurchasePercent;                                          // 0x0004(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.ExpeditionSlot
// 0x0018 (0x0020 - 0x0008)
struct FExpeditionSlot : public FTableRowBase
{
	struct FGameplayTag                                SlotTag;                                                  // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FString                                     LootTierGroup;                                            // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.HomebaseNodeGameplayEffectDataTableRow
// 0x00D0 (0x00D8 - 0x0008)
struct FHomebaseNodeGameplayEffectDataTableRow : public FTableRowBase
{
	struct FGameplayAttribute                          Attribute;                                                // 0x0008(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	TEnumAsByte<EGameplayModOp>                        Operation;                                                // 0x0028(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0029(0x0003) MISSED OFFSET
	float                                              Magnitude;                                                // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FGameplayTagContainer                       ApplicationRequiredTagsContainer;                         // 0x0030(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FGameplayTagContainer                       RequiredSourceTagsContainer;                              // 0x0050(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FGameplayTagContainer                       RequiredTargetTagsContainer;                              // 0x0070(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FGameplayTagContainer                       GrantedTagsContainer;                                     // 0x0090(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	struct FGameplayTagContainer                       IgnoreSourceTagsContainer;                                // 0x00B0(0x0020) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance)
	int                                                AssociatedGEIdx;                                          // 0x00D0(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int                                                AssociatedModifierIdx;                                    // 0x00D4(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.HomebaseBannerColorData
// 0x0010 (0x0018 - 0x0008)
struct FHomebaseBannerColorData : public FTableRowBase
{
	struct FName                                       ColorKeyName;                                             // 0x0008(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       CategoryRowName;                                          // 0x0010(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.HomebaseBannerIconData
// 0x0088 (0x0090 - 0x0008)
struct FHomebaseBannerIconData : public FTableRowBase
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0008(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.HomebaseBannerIconData.SmallImage
	unsigned char                                      UnknownData01[0x28];                                      // 0x0030(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.HomebaseBannerIconData.LargeImage
	struct FName                                       CategoryRowName;                                          // 0x0058(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FText                                       DisplayName;                                              // 0x0060(0x0018) (Edit, DisableEditOnInstance)
	struct FText                                       DisplayDescription;                                       // 0x0078(0x0018) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.HomebaseBannerCategoryData
// 0x0020 (0x0028 - 0x0008)
struct FHomebaseBannerCategoryData : public FTableRowBase
{
	struct FText                                       CategoryDisplayName;                                      // 0x0008(0x0018) (Edit, DisableEditOnInstance)
	int                                                SortPriority;                                             // 0x0020(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortGiftGiver
// 0x0008 (0x0030 - 0x0028)
struct FFortGiftGiver : public FFortGiftingInfo
{
	int                                                NumItemsGiven;                                            // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortLootLevelData
// 0x0018 (0x0020 - 0x0008)
struct FFortLootLevelData : public FTableRowBase
{
	struct FName                                       Category;                                                 // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                LootLevel;                                                // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MinItemLevel;                                             // 0x0014(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaxItemLevel;                                             // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortLootPackageData
// 0x0088 (0x0090 - 0x0008)
struct FFortLootPackageData : public FTableRowBase
{
	struct FName                                       LootPackageID;                                            // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Weight;                                                   // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Count;                                                    // 0x0014(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                LootPackageCategory;                                      // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FName                                       RequiredTag;                                              // 0x0020(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FString                                     LootPackageCall;                                          // 0x0028(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	unsigned char                                      UnknownData01[0x28];                                      // 0x0038(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortLootPackageData.ItemDefinition
	struct FString                                     PersistentLevel;                                          // 0x0060(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int                                                MinWorldLevel;                                            // 0x0070(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaxWorldLevel;                                            // 0x0074(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bAllowBonusDrops;                                         // 0x0078(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0079(0x0007) MISSED OFFSET
	struct FString                                     Annotation;                                               // 0x0080(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortLootTierData
// 0x00A8 (0x00B0 - 0x0008)
struct FFortLootTierData : public FTableRowBase
{
	struct FName                                       TierGroup;                                                // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              Weight;                                                   // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ELootQuotaLevel>                       QuotaLevel;                                               // 0x0014(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
	int                                                LootTier;                                                 // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MinWorldLevel;                                            // 0x001C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaxWorldLevel;                                            // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FString                                     StreakBreakerCurrency;                                    // 0x0028(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int                                                StreakBreakerPointsMin;                                   // 0x0038(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                StreakBreakerPointsMax;                                   // 0x003C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                StreakBreakerPointsSpend;                                 // 0x0040(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	struct FName                                       LootPackage;                                              // 0x0048(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       LootPreviewPackage;                                       // 0x0050(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              NumLootPackageDrops;                                      // 0x0058(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
	TArray<int>                                        LootPackageCategoryWeightArray;                           // 0x0060(0x0010) (Edit, EditFixedSize, ZeroConstructor)
	TArray<int>                                        LootPackageCategoryMinArray;                              // 0x0070(0x0010) (Edit, EditFixedSize, ZeroConstructor)
	TArray<int>                                        LootPackageCategoryMaxArray;                              // 0x0080(0x0010) (Edit, EditFixedSize, ZeroConstructor)
	struct FGameplayTag                                RequiredGameplayTag;                                      // 0x0090(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly)
	bool                                               bAllowBonusLootDrops;                                     // 0x0098(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x7];                                       // 0x0099(0x0007) MISSED OFFSET
	struct FString                                     Annotation;                                               // 0x00A0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortEventFlagsNotification
// 0x0018
struct FFortEventFlagsNotification
{
	TArray<struct FString>                             EventFlags;                                               // 0x0000(0x0010) (ZeroConstructor)
	struct FDateTime                                   RefreshTime;                                              // 0x0010(0x0008)
};

// ScriptStruct FortniteGame.FriendCodeIssuedNotification
// 0x0020
struct FFriendCodeIssuedNotification
{
	struct FString                                     Code;                                                     // 0x0000(0x0010) (ZeroConstructor)
	struct FString                                     CodeType;                                                 // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortMissionAlertClaimData
// 0x0020
struct FFortMissionAlertClaimData
{
	TArray<struct FString>                             MissionAlertGUIDs;                                        // 0x0000(0x0010) (ZeroConstructor)
	TArray<struct FDateTime>                           LastClaimedTimes;                                         // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortMissionAlertRecord
// 0x0080
struct FFortMissionAlertRecord
{
	TMap<EFortMissionAlertCategory, struct FFortMissionAlertClaimData> LastClaimTimesMap;                                        // 0x0000(0x0050) (ZeroConstructor)
	TArray<int>                                        OldestClaimIndexForCategory;                              // 0x0050(0x0010) (ZeroConstructor)
	struct FMcpLootResult                              PendingMissionAlertRewards;                               // 0x0060(0x0020)
};

// ScriptStruct FortniteGame.FortCollectionBookClaimRewardNotification
// 0x0040
struct FFortCollectionBookClaimRewardNotification
{
	struct FMcpLootResult                              Loot;                                                     // 0x0000(0x0020)
	struct FString                                     Page;                                                     // 0x0020(0x0010) (ZeroConstructor)
	struct FString                                     Section;                                                  // 0x0030(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortCollectionBookSlotItemNotification
// 0x0010
struct FFortCollectionBookSlotItemNotification
{
	struct FString                                     SlottedItemId;                                            // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortMissionAlertCompleteNotification
// 0x0020
struct FFortMissionAlertCompleteNotification
{
	struct FMcpLootResult                              LootGranted;                                              // 0x0000(0x0020)
};

// ScriptStruct FortniteGame.FortTransmogResultNotification
// 0x0020
struct FFortTransmogResultNotification
{
	TArray<struct FMcpLootEntry>                       TransmoggedItems;                                         // 0x0000(0x0010) (ZeroConstructor)
	TArray<struct FMcpLootEntry>                       RecycledItems;                                            // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortUpgradeItemRarityNotification
// 0x0010
struct FFortUpgradeItemRarityNotification
{
	TArray<struct FMcpLootEntry>                       ItemsGranted;                                             // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortConversionResultNotification
// 0x0010
struct FFortConversionResultNotification
{
	TArray<struct FMcpLootEntry>                       ItemsGranted;                                             // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortCollectedResourceNotification
// 0x0020
struct FFortCollectedResourceNotification
{
	struct FMcpLootResult                              Loot;                                                     // 0x0000(0x0020)
};

// ScriptStruct FortniteGame.FortReceivedGiftedBoostXpNotification
// 0x0018
struct FFortReceivedGiftedBoostXpNotification
{
	int                                                AmountBoostXpGifted;                                      // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     GifterAccountId;                                          // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortEarnScoreNotification
// 0x0018
struct FFortEarnScoreNotification
{
	int                                                BaseXPEarned;                                             // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BonusXPEarned;                                            // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BoostXPEarned;                                            // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BoostXPMissed;                                            // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                RestXPEarned;                                             // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                GroupBoostXPEarned;                                       // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortDailyQuestRerollNotification
// 0x0010
struct FFortDailyQuestRerollNotification
{
	struct FString                                     NewQuestId;                                               // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortQuestRewardNotification
// 0x0030
struct FFortQuestRewardNotification
{
	struct FString                                     QuestId;                                                  // 0x0000(0x0010) (ZeroConstructor)
	struct FMcpLootResult                              Loot;                                                     // 0x0010(0x0020)
};

// ScriptStruct FortniteGame.FortExpeditionResultNotification
// 0x0018
struct FFortExpeditionResultNotification
{
	bool                                               bExpeditionSucceeded;                                     // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	TArray<struct FMcpLootEntry>                       ExpeditionRewards;                                        // 0x0008(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortGetMcpTimeForPlayerNotification
// 0x0008
struct FFortGetMcpTimeForPlayerNotification
{
	struct FDateTime                                   McpTime;                                                  // 0x0000(0x0008)
};

// ScriptStruct FortniteGame.CardPackResultNotification
// 0x0028
struct FCardPackResultNotification
{
	struct FMcpLootResult                              LootGranted;                                              // 0x0000(0x0020)
	int                                                DisplayLevel;                                             // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortLootNotification
// 0x0040
struct FFortLootNotification
{
	struct FString                                     LootSource;                                               // 0x0000(0x0010) (ZeroConstructor)
	struct FString                                     LootSourceInstance;                                       // 0x0010(0x0010) (ZeroConstructor)
	struct FMcpLootResult                              LootGranted;                                              // 0x0020(0x0020)
};

// ScriptStruct FortniteGame.FortNotificationLevelUp
// 0x0058
struct FFortNotificationLevelUp
{
	int                                                Level;                                                    // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     HeroId;                                                   // 0x0008(0x0010) (ZeroConstructor)
	struct FFortLootNotification                       Loot;                                                     // 0x0018(0x0040)
};

// ScriptStruct FortniteGame.FortCraftingResultNotification
// 0x0010
struct FFortCraftingResultNotification
{
	TArray<struct FMcpLootEntry>                       ItemsCrafted;                                             // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortMissionCompletionNotification
// 0x0038
struct FFortMissionCompletionNotification
{
	bool                                               bWasCritical;                                             // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FString                                     MissionName;                                              // 0x0008(0x0010) (ZeroConstructor)
	struct FMcpLootResult                              LootGranted;                                              // 0x0018(0x0020)
};

// ScriptStruct FortniteGame.FortHomebaseView
// 0x0040
struct FFortHomebaseView
{
	struct FString                                     TownName;                                                 // 0x0000(0x0010) (ZeroConstructor)
	struct FString                                     BannerIconId;                                             // 0x0010(0x0010) (ZeroConstructor)
	struct FString                                     BannerColorId;                                            // 0x0020(0x0010) (ZeroConstructor)
	int                                                FlagPattern;                                              // 0x0030(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              FlagColor;                                                // 0x0034(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                PlayerXP;                                                 // 0x0038(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x003C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortAthenaSeasonStats
// 0x000C
struct FFortAthenaSeasonStats
{
	int                                                NumWins;                                                  // 0x0000(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                NumHighBracket;                                           // 0x0004(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                NumLowBracket;                                            // 0x0008(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortAthenaConsumableRecord
// 0x0010
struct FFortAthenaConsumableRecord
{
	class UFortAccountItemDefinition*                  ItemType;                                                 // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                TotalQuantity;                                            // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortProfileAndQuestSaveIdPair
// 0x0020
struct FFortProfileAndQuestSaveIdPair
{
	unsigned char                                      UnknownData00[0x20];                                      // 0x0000(0x0020) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortTwitchPendingQuestNotification
// 0x0010
struct FFortTwitchPendingQuestNotification
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortTwitchViewerNameAndAccountId
// 0x0020
struct FFortTwitchViewerNameAndAccountId
{
	struct FString                                     TwitchViewerName;                                         // 0x0000(0x0010) (ZeroConstructor)
	struct FString                                     AccountId;                                                // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortTwitchViewerCompletedQuestNotification
// 0x0010
struct FFortTwitchViewerCompletedQuestNotification
{
	TArray<struct FFortTwitchViewerNameAndAccountId>   ViewerIds;                                                // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortTwitchViewerGrantedQuestNotification
// 0x0020
struct FFortTwitchViewerGrantedQuestNotification
{
	struct FString                                     QuestTemplateId;                                          // 0x0000(0x0010) (ZeroConstructor)
	TArray<struct FFortTwitchViewerNameAndAccountId>   ViewerIds;                                                // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.McpLeaderboardResultRow
// 0x0030
struct FMcpLeaderboardResultRow
{
	struct FUniqueNetIdRepl                            PlayerUniqueNetId;                                        // 0x0000(0x0028) (BlueprintVisible, BlueprintReadOnly)
	int                                                Rank;                                                     // 0x0028(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Value;                                                    // 0x002C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.McpLeaderboardResult
// 0x0030
struct FMcpLeaderboardResult
{
	struct FString                                     StatName;                                                 // 0x0000(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	EMcpLeaderboardTimeWindow                          TimeWindow;                                               // 0x0010(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
	struct FTimespan                                   RequestTime;                                              // 0x0018(0x0008)
	TArray<struct FMcpLeaderboardResultRow>            LeaderboardData;                                          // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.McpPlayerStatsResult
// 0x0080
struct FMcpPlayerStatsResult
{
	struct FUniqueNetIdRepl                            PlayerUniqueNetId;                                        // 0x0000(0x0028) (BlueprintVisible, BlueprintReadOnly)
	TMap<struct FString, int>                          StatData;                                                 // 0x0028(0x0050) (ZeroConstructor)
	struct FTimespan                                   RequestTime;                                              // 0x0078(0x0008)
};

// ScriptStruct FortniteGame.QueryXboxUserXUIDParams
// 0x0010
struct FQueryXboxUserXUIDParams
{
	struct FString                                     UserXSTSToken;                                            // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.IssuedFriendCode
// 0x0028
struct FIssuedFriendCode
{
	struct FString                                     CodeId;                                                   // 0x0000(0x0010) (ZeroConstructor)
	struct FString                                     CodeType;                                                 // 0x0010(0x0010) (ZeroConstructor)
	struct FDateTime                                   DateCreated;                                              // 0x0020(0x0008)
};

// ScriptStruct FortniteGame.XboxDedicatedServerSessionCreationParams
// 0x0030
struct FXboxDedicatedServerSessionCreationParams
{
	struct FString                                     TitleId;                                                  // 0x0000(0x0010) (ZeroConstructor)
	struct FString                                     SandboxId;                                                // 0x0010(0x0010) (ZeroConstructor)
	TArray<struct FString>                             XboxUserIds;                                              // 0x0020(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortMigrationDataTableRow
// 0x0020 (0x0028 - 0x0008)
struct FFortMigrationDataTableRow : public FTableRowBase
{
	struct FString                                     OldItemTemplate;                                          // 0x0008(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	struct FString                                     NewItemTemplate;                                          // 0x0018(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortMissionAlertData
// 0x0060 (0x0068 - 0x0008)
struct FFortMissionAlertData : public FTableRowBase
{
	struct FName                                       CategoryRowName;                                          // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       SpreadRowName;                                            // 0x0010(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FString                                     RequiredEventFlag;                                        // 0x0018(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	bool                                               bOnlyUsedForSpreading;                                    // 0x0028(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0029(0x0003) MISSED OFFSET
	int                                                MinimumTileDifficulty;                                    // 0x002C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaximumTileDifficulty;                                    // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData02[0x10];                                      // 0x0034(0x0010) UNKNOWN PROPERTY: ArrayProperty FortniteGame.FortMissionAlertData.RestrictedMissionGens
	struct FString                                     LootTierGroup;                                            // 0x0048(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FString                                     ModifierTierGroup;                                        // 0x0058(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortMissionAlertSpreadData
// 0x0018 (0x0020 - 0x0008)
struct FFortMissionAlertSpreadData : public FTableRowBase
{
	float                                              ChanceToSpread;                                           // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                TotalChancesToSpread;                                     // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaxNumTilesToSpreadTo;                                    // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                SpreadInterval;                                           // 0x0014(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FName                                       MissionAlertRowName;                                      // 0x0018(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortMissionAlertCategoryData
// 0x0030 (0x0038 - 0x0008)
struct FFortMissionAlertCategoryData : public FTableRowBase
{
	EFortMissionAlertCategory                          Category;                                                 // 0x0008(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
	int                                                Priority;                                                 // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Quota;                                                    // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               MissionAlertRepeatable;                                   // 0x0014(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0015(0x0003) MISSED OFFSET
	struct FGameplayTagContainer                       CategoryTagsContainer;                                    // 0x0018(0x0020) (Edit, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.QueuedMusic
// 0x0010
struct FQueuedMusic
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.GeneralChatRoom
// 0x0028
struct FGeneralChatRoom
{
	struct FString                                     RoomName;                                                 // 0x0000(0x0010) (ZeroConstructor)
	int                                                CurrentMembersCount;                                      // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MaxMembersCount;                                          // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FString                                     PublicFacingShardName;                                    // 0x0018(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.GeneralChatRecommendations
// 0x0028
struct FGeneralChatRecommendations
{
	TArray<struct FGeneralChatRoom>                    GlobalChatRooms;                                          // 0x0000(0x0010) (ZeroConstructor)
	TArray<struct FGeneralChatRoom>                    FounderChatRooms;                                         // 0x0010(0x0010) (ZeroConstructor)
	bool                                               bNeedsPaidAccessForGlobalChat;                            // 0x0020(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bNeedsPaidAccessForFounderChat;                           // 0x0021(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bIsGlobalChatDisabled;                                    // 0x0022(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bIsFounderChatDisabled;                                   // 0x0023(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bIsSubGameGlobalChatDisabled;                             // 0x0024(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0025(0x0003) MISSED OFFSET
};

// ScriptStruct FortniteGame.OutpostCraftingTableData
// 0x0018 (0x0020 - 0x0008)
struct FOutpostCraftingTableData : public FTableRowBase
{
	int                                                Level;                                                    // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                ItemCount;                                                // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FString                                     RequiredItems;                                            // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.OutpostDisintegrationData
// 0x0030 (0x0038 - 0x0008)
struct FOutpostDisintegrationData : public FTableRowBase
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0008(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.OutpostDisintegrationData.ItemDefinition
	int                                                DisintegrationValue;                                      // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.OutpostItemUpgradeData
// 0x0050 (0x0058 - 0x0008)
struct FOutpostItemUpgradeData : public FTableRowBase
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0008(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.OutpostItemUpgradeData.ItemDefinition
	int                                                ItemLevel;                                                // 0x0030(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
	struct FString                                     RequiredItems;                                            // 0x0038(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FString                                     RequiredAccountItems;                                     // 0x0048(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct FortniteGame.FortOutpostFabricatorInfo
// 0x0018
struct FFortOutpostFabricatorInfo
{
	struct FString                                     DisintegrationStartTime;                                  // 0x0000(0x0010) (ZeroConstructor)
	int                                                QuantumGooCompleted;                                      // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                QuantumGooStillToProcess;                                 // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortOutpostPOSTInfo
// 0x0010
struct FFortOutpostPOSTInfo
{
	TArray<struct FFortDepositedResources>             DepositedPostItems;                                       // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortPresenceBasicInfo
// 0x0004
struct FFortPresenceBasicInfo
{
	int                                                HomeBaseRating;                                           // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortNamedCounterStat
// 0x0010
struct FFortNamedCounterStat
{
	int                                                CurrentCount;                                             // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FDateTime                                   LastIncrementedTime;                                      // 0x0008(0x0008)
};

// ScriptStruct FortniteGame.CraftingQueueInfo
// 0x0008
struct FCraftingQueueInfo
{
	unsigned char                                      UnknownData00[0x8];                                       // 0x0000(0x0008) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortPlayerPawnStats
// 0x0020 (0x00B0 - 0x0090)
struct FFortPlayerPawnStats : public FFortPawnStats
{
	float                                              MaxJumpTime;                                              // 0x0090(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              MaxStamina;                                               // 0x0094(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              StaminaRegenRate;                                         // 0x0098(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              StaminaRegenDelay;                                        // 0x009C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SprintingStaminaExpenditureRate;                          // 0x00A0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00A4(0x0004) MISSED OFFSET
	struct FName                                       HoverboardFallingDamageTableRow;                          // 0x00A8(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortQuestAchievementTableRow
// 0x0010 (0x0018 - 0x0008)
struct FFortQuestAchievementTableRow : public FTableRowBase
{
	EFortQuestState                                    QuestState;                                               // 0x0008(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0009(0x0003) MISSED OFFSET
	int                                                XboxAchievementID;                                        // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                PS4TrophyID;                                              // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortQuestObjectiveStatTableRow
// 0x00D0 (0x00D8 - 0x0008)
struct FFortQuestObjectiveStatTableRow : public FTableRowBase
{
	EFortQuestObjectiveStatEvent                       Type;                                                     // 0x0008(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0009(0x0007) MISSED OFFSET
	struct FString                                     TargetTags;                                               // 0x0010(0x0010) (Edit, ZeroConstructor)
	struct FString                                     SourceTags;                                               // 0x0020(0x0010) (Edit, ZeroConstructor)
	struct FString                                     ContextTags;                                              // 0x0030(0x0010) (Edit, ZeroConstructor)
	struct FString                                     Condition;                                                // 0x0040(0x0010) (Edit, ZeroConstructor)
	struct FString                                     TemplateId;                                               // 0x0050(0x0010) (Edit, ZeroConstructor)
	struct FGameplayTagContainer                       TargetTagContainer;                                       // 0x0060(0x0020) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FGameplayTagContainer                       SourceTagContainer;                                       // 0x0080(0x0020) (BlueprintVisible, BlueprintReadOnly, Transient)
	struct FGameplayTagContainer                       ContextTagContainer;                                      // 0x00A0(0x0020) (BlueprintVisible, BlueprintReadOnly, Transient)
	bool                                               bIsCached;                                                // 0x00C0(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData01[0x17];                                      // 0x00C1(0x0017) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortQuestManagerAttributes
// 0x0010
struct FFortQuestManagerAttributes
{
	struct FDateTime                                   DailyLoginInterval;                                       // 0x0000(0x0008)
	int                                                DailyQuestRerolls;                                        // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.QuickBarAndSlot
// 0x0008
struct FQuickBarAndSlot
{
	EFortQuickBars                                     QuickBarType;                                             // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	int                                                QuickBarSlot;                                             // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.ReflectedEngineVersion
// 0x0020
struct FReflectedEngineVersion
{
	int                                                Major;                                                    // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                Minor;                                                    // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                Patch;                                                    // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                Changelist;                                               // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FString                                     Branch;                                                   // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortRecordVersion
// 0x0040
struct FFortRecordVersion
{
	int                                                DataVersion;                                              // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                PackageFileVersion;                                       // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FReflectedEngineVersion                     EngineVersion;                                            // 0x0008(0x0020)
	unsigned char                                      UnknownData00[0x18];                                      // 0x0028(0x0018) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortDestroyedActorRecord
// 0x0050
struct FFortDestroyedActorRecord
{
	struct FGuid                                       ActorGuid;                                                // 0x0000(0x0010) (IsPlainOldData)
	class UClass*                                      ActorClass;                                               // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0018(0x0008) MISSED OFFSET
	struct FTransform                                  ActorTransform;                                           // 0x0020(0x0030) (IsPlainOldData)
};

// ScriptStruct FortniteGame.FortBuildingActorArray
// 0x0010
struct FFortBuildingActorArray
{
	TArray<struct FFortDestroyedActorRecord>           ActorRecords;                                             // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.MMAttemptState
// 0x000C
struct FMMAttemptState
{
	int                                                BestSessionIdx;                                           // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                NumSearchResults;                                         // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EMatchmakingState>                     State;                                                    // 0x0008(0x0001) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EPartyReservationResult>               LastBeaconResponse;                                       // 0x0009(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x000A(0x0002) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortMatchmakingRegionState
// 0x00A8
struct FFortMatchmakingRegionState
{
	bool                                               bDuosEnabled;                                             // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bFiftyFiftyEnabled;                                       // 0x0001(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0002(0x0006) MISSED OFFSET
	unsigned char                                      UnknownData01[0x50];                                      // 0x0002(0x0050) UNKNOWN PROPERTY: SetProperty FortniteGame.FortMatchmakingRegionState.EventFlagsForcedOn
	unsigned char                                      UnknownData02[0x50];                                      // 0x0058(0x0050) UNKNOWN PROPERTY: SetProperty FortniteGame.FortMatchmakingRegionState.EventFlagsForcedOff
};

// ScriptStruct FortniteGame.FortMatchmakingEventsState
// 0x0050
struct FFortMatchmakingEventsState
{
	TMap<struct FString, struct FFortMatchmakingRegionState> Region;                                                   // 0x0000(0x0050) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortRotationalContentEventsState
// 0x0140
struct FFortRotationalContentEventsState
{
	unsigned char                                      UnknownData00[0x50];                                      // 0x0000(0x0050) UNKNOWN PROPERTY: SetProperty FortniteGame.FortRotationalContentEventsState.ActiveStorefronts
	unsigned char                                      UnknownData01[0x50];                                      // 0x0050(0x0050) UNKNOWN PROPERTY: SetProperty FortniteGame.FortRotationalContentEventsState.ActiveEventFlags
	TMap<struct FName, double>                         EventNamedWeights;                                        // 0x00A0(0x0050) (ZeroConstructor)
	unsigned char                                      UnknownData02[0x50];                                      // 0x00F0(0x0050) UNKNOWN PROPERTY: SetProperty FortniteGame.FortRotationalContentEventsState.ExpirationTimes
};

// ScriptStruct FortniteGame.FortClientEventsState
// 0x0038 (0x0178 - 0x0140)
struct FFortClientEventsState : public FFortRotationalContentEventsState
{
	int                                                SeasonNumber;                                             // 0x0140(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0144(0x0004) MISSED OFFSET
	struct FString                                     SeasonTemplateId;                                         // 0x0148(0x0010) (ZeroConstructor)
	struct FDateTime                                   SeasonEnd;                                                // 0x0158(0x0008)
	struct FDateTime                                   WeeklyStoreEnd;                                           // 0x0160(0x0008)
	struct FDateTime                                   StwEventStoreEnd;                                         // 0x0168(0x0008)
	struct FDateTime                                   StwWeeklyStoreEnd;                                        // 0x0170(0x0008)
};

// ScriptStruct FortniteGame.FortSocialItemBasicData
// 0x0004
struct FFortSocialItemBasicData
{
	int                                                Rating;                                                   // 0x0000(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortLinearSpline
// 0x0001
struct FFortLinearSpline
{
	unsigned char                                      UnknownData00[0x1];                                       // 0x0000(0x0001) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortSurvivorNameData
// 0x0018 (0x0020 - 0x0008)
struct FFortSurvivorNameData : public FTableRowBase
{
	struct FText                                       Name;                                                     // 0x0008(0x0018) (Edit, EditConst)
};

// ScriptStruct FortniteGame.FortTaggedActorOctreeFilter
// 0x0068
struct FFortTaggedActorOctreeFilter
{
	struct FBoxSphereBounds                            Bounds;                                                   // 0x0000(0x001C) (IsPlainOldData)
	float                                              MinDistanceFromBoundsCenter;                              // 0x001C(0x0004) (ZeroConstructor, IsPlainOldData)
	TArray<class UClass*>                              OptionalSubclasses;                                       // 0x0020(0x0010) (ZeroConstructor)
	TArray<struct FFortFinderProperty>                 RequiredProperties;                                       // 0x0030(0x0010) (ZeroConstructor)
	struct FGameplayTagContainer                       TagsToLookFor;                                            // 0x0040(0x0020)
	bool                                               bHasAllTags;                                              // 0x0060(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0061(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortFoundQuestMissions
// 0x0048
struct FFortFoundQuestMissions
{
	struct FString                                     TheaterId;                                                // 0x0000(0x0010) (ZeroConstructor)
	bool                                               bIsValidForAllPlayableMissions;                           // 0x0010(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0011(0x0007) MISSED OFFSET
	TArray<struct FFortAvailableMissionData>           LinkedMissions;                                           // 0x0018(0x0010) (ZeroConstructor)
	TArray<struct FFortAvailableMissionData>           TagMatchingMissions;                                      // 0x0028(0x0010) (ZeroConstructor)
	TArray<struct FFortAvailableMissionData>           FallbackMatchingMissions;                                 // 0x0038(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.ThreatGridIndex
// 0x0008
struct FThreatGridIndex
{
	int                                                X;                                                        // 0x0000(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	int                                                Y;                                                        // 0x0004(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct FortniteGame.TimeOfDayEditorViewSettings
// 0x0001
struct FTimeOfDayEditorViewSettings
{
	unsigned char                                      UnknownData00[0x1];                                       // 0x0000(0x0001) MISSED OFFSET
};

// ScriptStruct FortniteGame.TrackPieceConfig
// 0x001C
struct FTrackPieceConfig
{
	ETrackPieceType                                    Type;                                                     // 0x0000(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	struct FRotator                                    Rotation;                                                 // 0x0004(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FVector                                     Scale;                                                    // 0x0010(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.TrackSplineConfig
// 0x0003
struct FTrackSplineConfig
{
	bool                                               bUseSpline;                                               // 0x0000(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	ETrackDirection                                    Start;                                                    // 0x0001(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	ETrackDirection                                    End;                                                      // 0x0002(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.TrackSwitchStateConfig
// 0x0024
struct FTrackSwitchStateConfig
{
	struct FTrackPieceConfig                           TrackPiece;                                               // 0x0000(0x001C) (Edit, DisableEditOnInstance)
	struct FTrackSplineConfig                          SplineConfig1;                                            // 0x001C(0x0003) (Edit, DisableEditOnInstance)
	struct FTrackSplineConfig                          SplineConfig2;                                            // 0x001F(0x0003) (Edit, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0022(0x0002) MISSED OFFSET
};

// ScriptStruct FortniteGame.TrackConfiguration
// 0x0038
struct FTrackConfiguration
{
	TArray<bool>                                       NeighborsByDirection;                                     // 0x0000(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FTrackSwitchStateConfig>             SwitchStates;                                             // 0x0010(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FRotator                                    SwitchRotation;                                           // 0x0020(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FVector                                     SwitchOffset;                                             // 0x002C(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortCatalogMetaPreload
// 0x0038
struct FFortCatalogMetaPreload
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) UNKNOWN PROPERTY: ArrayProperty FortniteGame.FortCatalogMetaPreload.ChaseItems
	unsigned char                                      UnknownData01[0x28];                                      // 0x0010(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortCatalogMetaPreload.PackDefinition
};

// ScriptStruct FortniteGame.FortCatalogMeta
// 0x0018
struct FFortCatalogMeta
{
	TArray<class UFortAccountItemDefinition*>          ChaseItems;                                               // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	class UFortCardPackItemDefinition*                 PackDefinition;                                           // 0x0010(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct FortniteGame.FortNamedWeightRow
// 0x0050 (0x0058 - 0x0008)
struct FFortNamedWeightRow : public FTableRowBase
{
	TMap<struct FString, float>                        NamedWeightMap;                                           // 0x0008(0x0050) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct FortniteGame.FortLoginReward
// 0x0050 (0x0058 - 0x0008)
struct FFortLoginReward : public FTableRowBase
{
	unsigned char                                      UnknownData00[0x28];                                      // 0x0008(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortLoginReward.ItemDefinition
	int                                                ItemCount;                                                // 0x0030(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
	struct FText                                       Description;                                              // 0x0038(0x0018) (Edit)
	bool                                               bIsMajorReward;                                           // 0x0050(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x0051(0x0007) MISSED OFFSET
};

// ScriptStruct FortniteGame.TransmogSacrifice
// 0x0008 (0x0010 - 0x0008)
struct FTransmogSacrifice : public FTableRowBase
{
	int                                                TransmogSacrificePoints;                                  // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortDayPhaseCallbackHandle
// 0x0010
struct FFortDayPhaseCallbackHandle
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortMultiSizeMargin
// 0x0060
struct FFortMultiSizeMargin
{
	struct FMargin                                     Margin_XXS;                                               // 0x0000(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FMargin                                     Margin_XS;                                                // 0x0010(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FMargin                                     Margin_S;                                                 // 0x0020(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FMargin                                     Margin_M;                                                 // 0x0030(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FMargin                                     Margin_L;                                                 // 0x0040(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FMargin                                     Margin_XL;                                                // 0x0050(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.FortMultiSizeFont
// 0x0210
struct FFortMultiSizeFont
{
	struct FSlateFontInfo                              Font_XXS;                                                 // 0x0000(0x0058) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSlateFontInfo                              Font_XS;                                                  // 0x0058(0x0058) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSlateFontInfo                              Font_S;                                                   // 0x00B0(0x0058) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSlateFontInfo                              Font_M;                                                   // 0x0108(0x0058) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSlateFontInfo                              Font_L;                                                   // 0x0160(0x0058) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSlateFontInfo                              Font_XL;                                                  // 0x01B8(0x0058) (Edit, BlueprintVisible, BlueprintReadOnly)
};

// ScriptStruct FortniteGame.FortUserCloudRequestPayload
// 0x0058
struct FFortUserCloudRequestPayload
{
	struct FFortUserCloudRequestHandle                 RequestHandle;                                            // 0x0000(0x0008)
	struct FUniqueNetIdRepl                            UserNetID;                                                // 0x0008(0x0028)
	struct FString                                     Filename;                                                 // 0x0030(0x0010) (ZeroConstructor)
	EFortUserCloudRequestType                          RequestType;                                              // 0x0040(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0041(0x0007) MISSED OFFSET
	TArray<unsigned char>                              DataBuffer;                                               // 0x0048(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortUserCloudRequest
// 0x00A0
struct FFortUserCloudRequest
{
	struct FFortUserCloudRequestPayload                RequestPayload;                                           // 0x0000(0x0058)
	unsigned char                                      bNeedsFileEnumeration : 1;                                // 0x0058(0x0001)
	unsigned char                                      bStartedProcessing : 1;                                   // 0x0058(0x0001)
	unsigned char                                      UnknownData00[0x47];                                      // 0x0059(0x0047) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortUserCloudRequestQueue
// 0x0028
struct FFortUserCloudRequestQueue
{
	unsigned char                                      bFreezeIncomingRequests : 1;                              // 0x0000(0x0001)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0001(0x0007) MISSED OFFSET
	struct FFortUserCloudRequestHandle                 FirstFrozenHandle;                                        // 0x0008(0x0008)
	struct FTimerHandle                                ProcessingTimerHandle;                                    // 0x0010(0x0008)
	TArray<struct FFortUserCloudRequest>               RequestQueue;                                             // 0x0018(0x0010) (ZeroConstructor)
};

// ScriptStruct FortniteGame.FortZoneStats
// 0x0190
struct FFortZoneStats
{
	unsigned char                                      UnknownData00[0x190];                                     // 0x0000(0x0190) MISSED OFFSET
};

// ScriptStruct FortniteGame.ContainerStatInfo
// 0x000C
struct FContainerStatInfo
{
	unsigned char                                      UnknownData00[0xC];                                       // 0x0000(0x000C) MISSED OFFSET
};

// ScriptStruct FortniteGame.EnemyNpcStatInfo
// 0x0010
struct FEnemyNpcStatInfo
{
	unsigned char                                      UnknownData00[0x10];                                      // 0x0000(0x0010) MISSED OFFSET
};

// ScriptStruct FortniteGame.DefenderNPCStatInfo
// 0x000C
struct FDefenderNPCStatInfo
{
	unsigned char                                      UnknownData00[0xC];                                       // 0x0000(0x000C) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortKeepAmmoStash
// 0x0028 (0x0030 - 0x0008)
struct FFortKeepAmmoStash : public FTableRowBase
{
	int                                                Max1;                                                     // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Cooldown1;                                                // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Max2;                                                     // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Cooldown2;                                                // 0x0014(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Max3;                                                     // 0x0018(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Cooldown3;                                                // 0x001C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Max4;                                                     // 0x0020(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                Cooldown4;                                                // 0x0024(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                PickupTier;                                               // 0x0028(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortKeepItemGroup
// 0x0010 (0x0018 - 0x0008)
struct FFortKeepItemGroup : public FTableRowBase
{
	int                                                Items;                                                    // 0x0008(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                MaxTier;                                                  // 0x000C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                BaseLevel;                                                // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct FortniteGame.FortKeepResourceGroup
// 0x0048 (0x0050 - 0x0008)
struct FFortKeepResourceGroup : public FTableRowBase
{
	struct FName                                       Container;                                                // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	int                                                ItemCount;                                                // 0x0010(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     ResourceName;                                             // 0x0018(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	unsigned char                                      UnknownData01[0x28];                                      // 0x0028(0x0028) UNKNOWN PROPERTY: SoftObjectProperty FortniteGame.FortKeepResourceGroup.FullPath
};

// ScriptStruct FortniteGame.FortPlacementDistanceRequirements
// 0x0008
struct FFortPlacementDistanceRequirements
{
	float                                              DistanceRangeMin;                                         // 0x0000(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              DistanceRangeMax;                                         // 0x0004(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
