#pragma once

// Fortnite (1.11) SDK

// Generated with <3 by Jacobb626

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function NetUI.NetDebugWidget.StopTimer
struct UNetDebugWidget_StopTimer_Params
{
};

// Function NetUI.NetDebugWidget.StartTimer
struct UNetDebugWidget_StartTimer_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
