// Fortnite (1.11) SDK

// Generated with <3 by Jacobb626

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
TUObjectArray* UObject::GObjects = nullptr;
//---------------------------------------------------------------------------
bool FWeakObjectPtr::IsValid() const
{
	return false;
}
//---------------------------------------------------------------------------
UObject* FWeakObjectPtr::Get() const
{
	return nullptr;
}
//---------------------------------------------------------------------------
void InitSDK()
{
	UObject::GObjects = decltype(UObject::GObjects)(FindPattern("48 8B 05 ? ? ? ? 48 8D 1C C8 81 4B ? ? ? ? ? 49 63 76 30", true, 3));
	FNameToString = decltype(FNameToString)(FindPattern("40 53 48 83 EC 40 83 79 04 00 48 8B DA 75 19 E8 ? ? ? ? 48 8B C8 48 8B D3"));
	FreeMemory = decltype(FreeMemory)(FindPattern("48 85 C9 74 1D 4C 8B 05 ? ? ? ? 4D 85 C0"));
	Engine = UObject::FindObject<class UFortEngine>("FortEngine_");
}
//---------------------------------------------------------------------------
}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
